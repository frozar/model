#ifndef POISONING_H
#include <pcap.h>
#include "config.h"
#define POISONING_H

/******************/
/* Send functions */
/******************/
int send_false_entry(const u_char *packet, u_char fake_ip[4], char *hostname, char *host_ip);

/**********************/
/* Callback functions */
/**********************/
/* Send packets to the host who made the request (hope the first will be received before
 * the answser of the legitimate server) */
void callback_poisoning(u_char *args, const struct pcap_pkthdr* pkthdr, const u_char *packet);

/******************/
/* Grab functions */
/******************/
/* Grab dns queries on "device" from "hostsrc" and run the callback function (spoofing) for "destination" IP
 * If device == NULL, then use pcap_lookupdev
 * if srchost == NULL, then grab EVERY UDP DNS PAQUETS (promisc needed)
 */
int grab_server_queries(char *device, char *srchost, char *fakeip, char *domain, char *hostname, char *host_ip);

#endif
