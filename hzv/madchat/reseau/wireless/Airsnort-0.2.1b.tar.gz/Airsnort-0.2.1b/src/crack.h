/*
    This file is part of AirSnort.

    AirSnort is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    AirSnort is distributed in the hope that it will be useful,
      but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with AirSnort; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/


#ifndef __CRACKER_H
#define __CRACKER_H

#include <gtk/gtk.h>
#include <semaphore.h>
#include "RC4.h"
#include "Packet.h"

struct BssidList_t;

typedef struct CrackNode_t {
   int cracked;
   unsigned char ssid[6];
   int csamples[13];
   int ksamples;
   int tries;
   int die;

   Sample *samples[13];
   unsigned char curGuess[16]; //handle both key sizes
   Packet *queue;
   Packet *pkts;

   sem_t pktSem;
   struct BssidList_t *data;
} CrackNode;

CrackNode *newCrackNode(struct BssidList_t *owner);
void destroyCrackNode(CrackNode *ap);
int addCrackPacket(CrackNode *ap, Packet *p);

int classify(unsigned char *p);
int freq_compare(const void *a,const void *b);
int tryByte(CrackNode *this, int which, int breadth, int keySize);
int addSample(CrackNode *this, unsigned char *iv, unsigned char byte);
int tryCrack40(CrackNode *this, unsigned char *result);
int tryCrack128(CrackNode *this, unsigned char *result);
int checkKey(Packet *this, unsigned char *key, int len);
void destroyPacketList(Packet *p);
void destroySampleList(Sample *s);

void *cracker(void *);

#endif
