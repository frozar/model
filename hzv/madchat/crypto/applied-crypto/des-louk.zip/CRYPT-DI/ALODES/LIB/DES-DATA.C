#include	"des-private.h"

const C_Block		des_zero_block;

const des_u_long	des_spe_table[] = {
#include "spe-table.h"
};
