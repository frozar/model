#define STATIC_INLINE
#include "des-fun.h"
