README File

Use the SETUP Program on the CD-ROM to install this title.


For best results, we recommend configuring your Window system to run at 800x600 
resolution (or higher) and to set the amount of colors to 256 (anything higher
is also fine, but 256 colors is recommended as a minimum setting).

If you are not running Windows in a high resolution mode then you may find 
that some of the images are scaled down to fit your screen and they will 
not appear as sharp as they would on a higher resolution system.



