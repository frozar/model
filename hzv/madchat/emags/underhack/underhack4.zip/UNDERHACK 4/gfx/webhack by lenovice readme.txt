En fait c'est le logo qui m'a ete envoy� par lenovice, et je l'ai vraiment aim�, ne pouvant le
mettre sur le site de WEBHACK http://webhack2000.cjb.net je le join avec le zine underhack #4 en
remerciant lenovice bien sur :o)))