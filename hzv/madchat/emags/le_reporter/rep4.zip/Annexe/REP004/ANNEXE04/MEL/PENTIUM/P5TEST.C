/****************************************************************************

Auteur          : Pierre Larbier
D�velopp� le    : 3.12.1994
Derni�re MAJ    : 3.12.1994


Ce petit programme de test v�rifie que votre Pentium ne fait pas partie de
la s�rie d�fectueuse.
Si �a peut vous consoler, mon propre P5-90 achet� en aout 1994 ne passe pas
ce test ....

***************************************************************************/

#include <stdio.h>
#include <math.h>

#define OK 	0
#define ERREUR	1

int main(void)
{
double x , y;
char test = OK;

	printf("Petit programme de test qui v�rifie si votre Pentium fait partie\n");
	printf("de la s�rie defectueuse... \n");
	printf("P.S : ce programme ne v�rifie pas que vous avez effectivement un Pentium\n");
	printf("      dans votre machine\n\n");

	/* Test qui doit normalement passer sur tous les Pentiums */
	x = 5505001.;
	y = x/294912.;
	y *= 294912.;
	x = x - y;
	if (fabs(x) > 0.1) {
		printf("Votre CPU a de tr�s s�rieuses difficult�s l� :(5505001/294912)*294912 - 5505001 = %f ???\n",x);
		printf("Le test s'arr�te ici pour vous ...\n");
		return 0;
	}

	/* Un couple de nbres qui ne doit pas passer sur les Pentiums
	   defectueux */
	x = 5505001.;
	y = x/294911.;
	y *= 294911.;
	x = x - y;
	if (fabs(x) > 0.1) {
		printf("Dommage : (5505001/294911)*294911 - 5505001 = %f\n",x);
		test = ERREUR;
	}

	/* Un autre couple de nbres qui ne doit pas passer sur les Pentiums
	   defectueux */
	x = 5244795.;
	y = x/3932159.;
	y *= 3932159.;
	x = x - y;
	if (fabs(x) > 0.1) {
		printf("Ooops : (5244795/3932159)*3932159 - 5244795 = %f\n",x);
		test = ERREUR;
	}

	/* Un autre couple de nbres qui ne doit pas passer sur les Pentiums
	   defectueux */
	x = 4195835.;
	y = x/3145727.;
	y *= 3145727.;
	x = x - y;
	if (fabs(x) > 0.1) {
		printf("Arghhh : (4195835/3145727)*3145727 - 4195835 = %f\n",x);
		test = ERREUR;
	}

	/* Un autre couple de nbres qui ne doit pas passer sur les Pentiums
	   defectueux */
	x = 4195835.;
	y = x/12582908.;
	y *= 12582908.;
	x = x - y;
	if (fabs(x) > 0.1) {
		printf("Pffff : (4195835/12582908)*12582908 - 4195835 = %f\n",x);
		test = ERREUR;
	}


	/* Un autre couple de nbres qui ne doit pas passer sur les Pentiums
	   defectueux */
	x = 20709356.;
	y = x/12582900.;
	y *= 12582900.;
	x = x - y;
	if (fabs(x) > 0.1) {
		printf("Ouille : (20709356/12582900)*12582900 - 20709356 = %f\n",x);
		test = ERREUR;
	}

	/* R�capitulatif des r�sultats */
	if (test == OK) {
		printf("Vous avez de la chance... la division flottante de votre Pentium\n");
		printf("semble fonctionner correctement");
	}
	else {
		printf("\nBon, � l'�vidence il y a un probl�me sur la division flottante de\n");
		printf("votre Pentium. Rassurez vous, Intel assure que le d�faut n'est pr�sent\n");
		printf("que pour 50 � 2000 couples de nombres ...\n");
	}
	printf("\nEt c'est fini ...\n");

	return 0;
}
