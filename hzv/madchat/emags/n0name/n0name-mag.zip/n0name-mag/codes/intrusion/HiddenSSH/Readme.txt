Un mini readme est inclus dans le programme en lui m�me, en anglais, mais facilement compr�hensible. 

Petit bug : Il faut le lancer a partir de la console, sinon, le programme ne marchera pas ( oui, je ne sais pas trop pourquoi, et, l'ayant programm� relativement rapidement, je n'ai pas tellement le courage de chercher pourquoi ... ) Il faut donc le lancer a partir d'un shell, son execution "normale", en doublecliquant, aura pour effet de bel et bien creer le premier dossier, mais h�las, tout le reste ne marchera pas.

Bonne chance, la source se nomme HiddenSSH.asm :]

Amusez vous bien :]

Ice'