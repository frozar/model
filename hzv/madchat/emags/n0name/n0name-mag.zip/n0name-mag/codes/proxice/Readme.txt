ProxIce 2.0 by Icingtaupe

Tout d'abord, merci d'utiliser ce programme :) 

Ecrit 100% pur ASM, avec MASM & WinASM.

Fonctions :
- Injection d'un thread qui lui m�me charge une DLL infectieuse
- Cryptage des donn�es a l'interieur du serveur
- Mot de passe non d�crypt� en m�moire
- Notification par mail
- EditServer
- Installation dans une cl�e de la BDR pour autorun
- Test de la connexion
- Backdoor sur le port de  votre choix
- Commentaire total des sources :)

Ce programme a �t� concu et programm� pour le mag #1 de n0name, merci a Aphex pour le type d'injection, et .. c'est tout. Merci a bleyme pour avoir jet� un oeil sur mes sources, merci en fait a toute la team n0name d'�tre ce qu'elle est ... cette backdoor est la preuve que l'on peut rapidement faire une backdoor simple, efficace, et un tant soit peu furtive de tr�s petite taille ... les sources sont la a titre educatif et permettront a ceux qui le d�sirent d'apprendre un peu en comprenant pourquoi et ce qui se fait.

Vous aurez besoin de NetCat pour vous connecter au serveur, livr� avec le pack. Au fait, cette backdoor est concue pour XP / NT.

Amusez vous bien :)

Icingtaupe.