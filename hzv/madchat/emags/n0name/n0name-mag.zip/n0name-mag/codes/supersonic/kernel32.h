int WINAPI hook_kernel32 ();
int WINAPI free_kernel32 ();