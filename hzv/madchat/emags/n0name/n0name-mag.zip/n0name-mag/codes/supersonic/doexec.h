BOOL doexec(int  ClientSocket);
