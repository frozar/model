int main(void)
{
setuid(0);
}