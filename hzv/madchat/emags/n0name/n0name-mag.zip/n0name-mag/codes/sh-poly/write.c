#include <stdio.h>

int main()
{
  write(1, "miaou le chat\n", 10);
}