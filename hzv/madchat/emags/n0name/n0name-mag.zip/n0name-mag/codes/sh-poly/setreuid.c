main() 
{ 
   setreuid(0,0); 
} 