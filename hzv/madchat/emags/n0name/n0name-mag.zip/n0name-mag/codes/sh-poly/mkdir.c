#include <stdio.h> 
int main() 
{ 
	mkdir("kuul", 0755); 
	return 0; 
}