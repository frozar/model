/**************************************************************************/
/*                                                                        */
/*   ECRAN_C.C                                                            */
/*   Auteur Olivier Pecheux                                               */
/*   opecheux@multimania.com                                              */
/*   http://www.multimania.com/opecheux                                   */
/*                                                                        */
/*   Ce programme donne quelques implantations possibles pour ecrire      */
/*   directement dans la memoire ecran                                    */
/*                                                                        */
/**************************************************************************/
#include <stdio.h>
#include <dos.h> /* pour MK_FP et pokeb */

/* Pour la premiere implantation */
#define ecran1 0xA000

/* Pour la deuxieme implantation */
char far*ecran2=(char far*)MK_FP(0x0000,0x0000);

/* Pour la troisieme implantation */
char far*ecran3=(char far*)0xA0000000l;

unsigned int offset;
unsigned char couleur;

void main(void)
{
 offset=1000; couleur=12;
 pokeb(ecran1,offset,couleur); /* premiere implantation */
 ecran2[offset]=couleur; /* deuxieme implantation */
 ecran3[offset]=couleur;  /* troisieme implantation */
}