/**************************************************************************/
/*                                                                        */
/*   MODIF_C.C                                                            */
/*   Auteur Olivier Pecheux                                               */
/*   opecheux@multimania.com                                              */
/*   http://www.multimania.com/opecheux                                   */
/*                                                                        */
/*   Ce programme montre une implantation d'un procedure qui s'auto-      */
/*   modifie.                                                             */
/*                                                                        */
/**************************************************************************/


#include <stdio.h>
#include <conio.h>
#include <dos.h>

#define false 0
#define true 1

typedef unsigned char boolean;
typedef unsigned short word;

void auto_modifie(word *i, boolean condition)
{
  word far*p,far*q;
  volatile word locale; /* volatile empeche le compilateur d'utiliser
	 un registre */

  locale=*i;
  if (condition)
  { /* remplacement de inc par dec */
	 /* mise en place des pointeurs p et q */
	 p=(word far*)MK_FP(_CS,FP_OFF(auto_modifie)+0x42);
	 q=(word far*)MK_FP(_CS,FP_OFF(auto_modifie)+0x4c);
	 /* remplacement */
	 *p=*q;
  }

  /* vide la queue de prelecture */
  if (condition) condition=true; else condition=false;

  /* la ligne suivante peut incrementer ou decrementer */
  locale++;
  *i=locale;

  /* code pour le remplacement */
  return;
  locale--;
 }



word i;
int main(void)
{
  /* initialisation */
  i=0; printf("Initialisation :%u",i);

  /* avant de faire tourner cette partie, il est necessaire de modifier les
		valeurs 51 et 5F de la procedure par les bonnes valeurs */
  auto_modifie(&i,false);
  printf("\nApres auto_modifie_1, condition fausse :%u\n",i);
  auto_modifie(&i,false);
  printf("Apres auto_modifie_1, condition fausse :%u\n",i);
  auto_modifie(&i,true);
  printf("Apres auto_modifie_1, condition vraie :%u\n",i);


  getch();
  return(0);
}