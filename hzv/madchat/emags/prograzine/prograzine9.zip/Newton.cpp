//Newton.cpp by Loubail loubail@club-internet.fr
// bailsite@hotmail.com http://www.multimania.com/loubail
// http://www.geocities.com/SiliconValley/Chip/8195

//Les fichiers en-tete

#include <conio.h>
#include <dos.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <complex.h>


//La fonction principale

void main(void)
{
unsigned char far *screen; //screen pointera vers 0xA000
//variables diverses
char num;
float x,y,x2,y2,x4,y4,minx,maxx,miny,maxy,stepx,stepy;
float x5,y5;
float qx=-1.5;
float qy=1.4;
float temp;
int h,j;
int tab=0;
union REGS regs;
complex z,z2;
int a;
int p;

//on va utiliser la methode de Newton appliquee sur z^3 -1 = 0 ;)
p=3;

//On initialise le mode VGA !
  regs.x.ax=0x0013;
  int86(0x10,&regs,&regs);

//screen va pointer vers 0xA000
screen = (unsigned char far *) MK_FP(0xA000, 0);



for(y=-2;y<=2;y+=0.02) // 4 /200
{
for(x=-2;x<=2;x+=0.0125) // 4 /320
{
x4=x;
y4=y;
num=0;
x2=0;
y2=0;

a=0;
for(num=0;a!=1;num++)
{
if((x4*x4+y4*y4)<=1.0000001) if((x4*x4+y4*y4)>=0.9999999) a=1;

//on arrete si on appuie sur une touche !
if(kbhit())
{
  regs.x.ax=0x0003;
  int86(0x10,&regs,&regs);
exit(1);
}


//on applique l'algorithme
z=complex(x4,y4);
z=((p-1)*pow(z,p)+1)/(p*pow(z,p-1));
x4=real(z);
y4=imag(z);
}

//on affiche le point
screen[tab]=num+20;
tab++;

}
}

//On attend que l'utilisateur appuie sur une touche
getch();

//On restaure le mode TXT !
  regs.x.ax=0x0003;
  int86(0x10,&regs,&regs);

}

