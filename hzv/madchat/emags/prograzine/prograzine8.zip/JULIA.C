#include <conio.h>
#include <dos.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>


//Fonction Principale
void main(void)
{
// *screen est un pointeur qui pointera vers la m�moire �cran
unsigned char far *screen;
int num;
//On pose z2=x2+i*y2 et z4=x4+i*y4
float x,y,x2,y2,x4,y4;
//On pose C = Cx + i*Cy
float Cx;
float Cy;
  union REGS regs;
int a;

//On assigne des valeurs � Cx et Cy
Cx=.3;
Cy=.6;


//On initialise le mode vid�o VGA 320*200 256 couleurs
  regs.x.ax=0x0013;
  int86(0x10,&regs,&regs);

//J'aurai tr�s bien pu utiliser :
//asm{ mov ax,13h
//     int 10h
//   }


//On fait en sorte que screen pointe vers la m�moire vid�o VGA
screen = (unsigned char far *) MK_FP(0xA000, 0);


//	c=complex(Cx,Cy);
//On met en place deux boucles : avec x et y on assignera � Z(0) x + i*y
for(y=-2;y<=2;y+=0.02)
{
for(x=-2;x<=2;x+=0.0125)
{
//On initialise des valeurs;
//z4=x+i*y
//z2=0;
x4=x;
y4=y;
x2=0;
y2=0;
a=0;


//Maintenant on met en place la boucle associ�e � la suite Z(n+1)=Z(n)�+C
// num contiendra le nombre de cycles effectu�es dans la boucle suivante
// a est un indicateur : si a=0 alors la boucle peut continuer
//                       si a=1 alors on a d�passer sans probl�me la valeur
//fix�e. On arr�te alors la boucle.
//                       si a=2 alors on arrive pas � d�passer la valeur
//fix�e. On arr�te alors la boucle.
for(num=0;a==0;num++)
{
//Si on d�passe un certain nombre de cycles on assigne � a la valeur 2
if(num>=200) a=2;
if((x2*x2+y2*y2)>=560) a=1; //si |z2|�>=560 a=1


//	z2=z4�+C;  avec C=Cx+i*Cy
//	z4=z2;
x2=(x4*x4)-(y4*y4)+Cx;
y2=2*x4*y4+Cy;
x4=x2;
y4=y2;

//Si on appuie sur une touche arr�te le programme ( tr�s pratique si le
//programme plante ou si le calcul est trop long ! )
/*	if(kbhit())
	{
	 regs.x.ax=0x0003;
	 int86(0x10,&regs,&regs);
	 exit(1);
	}*/

}

//On affiche le r�sultat sous la forme d'un point
*(screen)=num+20;
if(a==2) *(screen)=0;
screen++;

}
}

//On r�tablit le mode Texte
getch();
regs.x.ax=0x0003;
int86(0x10,&regs,&regs);


}