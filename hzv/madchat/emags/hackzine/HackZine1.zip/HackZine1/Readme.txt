----------------------------------------------------------------------------------------------

Dans ce dossier :
- HackZine 1.1 , version worpad de hackzine1
- HackZine 1.2 , version notepad de hackzine1
- stress_reducer , un jeu ultra d�lirant arf, thanks Userknown au passage ;)
- readme.txt , un fichier texte que vous �tes b�tement en train de lire, en ce moment m�me :p

----------------------------------------------------------------------------------------------
 *********************************************************************************************
               [Kefka], nickairmax@caramail.com  //  irc.jeuxvideo.com (@hack)