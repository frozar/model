Note de l'auteur // Ce zip inclue :
- HackZine3.txt , le zine en lui m�me
- listedesports.txt , une liste des ports 'bonus' � HackZine3
- readme.txt , le fichier que vous �tes b�tement en train de lire
----------------------------------------------------------------------
[Kefka] , nickairmax@caramail.com  //  irc.jeuxvideo.com  (@#hack)
----------------------------------------------------------------------

NB : Suite � des critiques r�centes, j'ai d�cid� de vous livrer le zine uniquement
dans sa version NotePad, z'inquietez pas ca reste lisible :p

***********************************************************************

__________________________________________________________________________________

