FILE* init_debug_file (char* filename);
void end_debug_file (void);
void send_debug (char* contenu);

int demande_autorisation (char* message);

