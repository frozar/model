int WINAPI hook_wininet ();
int WINAPI free_wininet ();