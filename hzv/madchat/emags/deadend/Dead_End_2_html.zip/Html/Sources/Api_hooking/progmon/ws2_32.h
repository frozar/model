int WINAPI hook_ws2_32 ();
int WINAPI free_ws2_32 ();