/-==--==--==--==--==--==--==--==--==--==--==--==--==--==--==--==--==--==--==-\
|                               RtCm4g issue#5                               |
\-==--==--==--==--==--==--==--==--==--==--==--==--==--==--==--==--==--==--==-/

Voil�, c'est le nouveau mag, et en version graphique je vous prie.
L'ex�cutable est rtcmag.exe

ATTENTION !!! Si vous �tes �pileptiques, passer la d�mo en appuyant sur une
touche. (ou du moins, avant l'�cran final avec marqu� RtC Mag).

Pour ceux qui ne voudrait pas lancer l'ex�cutable (�a serait dommage) ou ceux
qui ne peuvent pas (Vive les UNIXs) voil� le sommaire avec les fichiers
correspondants :

edito/
  discla   : Disclaimer
  edito    : Edito                                                  Androgyne
  distrib  : Noms des personnes ayant particip� au mag
  greetz   : Nos Greets
  news     : Des news sur l'underground
  viewer   : Les infos concernant le viewer et la d�mo

hack/
  paralyse : DoS Paralyse (sources dans src/paralyse)                     Sly
  smurf    : Distributed Denial Of Service (sources dans src/smurf)     S/ash
  hackrezo : L'intrusion r�seau                                      Par4noID
  sniffer  : Programmation d'un Sniffer sous Linux                     RaPass
                    (sources dans src/sniffer)
  netbios  : L'enregistrement et la r�solution des noms NetBIOS       Sneakie
  portscan : Stealth Scanning                                           S/ash
  p49-14   : Traduction Phrack 49-14 : Smashing The Stack For Fun And Profit
                                                AlephOne (Traducteur : S/ash)
  p54-08   : Traduction Phrack 54-08 : NT Technologies Vulnerabilities
                                       rain.forest.puppy (Traducteur : S/ash)

virus/
  nuxvirus : Linux virus writing tutorial                          mandragore
  bomb     : Une bombe graphique de Spanska                         Androgyne
             (executable : cosmos.com)
  infect01 : Infection WIN32 part I                                 Doxtor L.
  optim    : Optimisation du code d'un virus                        Androgyne
  deepins  : BATCHED Again, Deep Inside...                            Sneakie
  vds      : La Charte de VDS                                       Androgyne

prog/
  codart   : Coding Art                                                 S/ash
  rtcword2 : RtC Word II (source dans src/rtcword2)                 Androgyne
  crypto2  : La cryptographie part II                                   S/ash
  ircbot3  : IRC Bot part III                                           S/ash

divers/
  kosak    : Kosak le Koboyz                                        Androgyne
  hackvoic : Correspondance avec Hackerz Voice                          S/ash
  profs    : La r�ponse de l'auteur de la section Profs de HV           S/ash
  dst      : La DST et la SEFTI : mythe et r�alit�                      S/ash
  eng      : Du c�t� de chez nos amis les anglais                       S/ash
  softcrk2 : SoftCracking part II                                       S/ash
  ms       : Un texte sur la firme de redmond                           S/ash