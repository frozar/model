<?php
$x=0;
$open=fopen("$fichier","r");
while(feof($open)!=1)
{
$edit[$x]=fgetss($open,10000);
$x++;
}

echo"
<div align='center'>
<form method='post' action='past.php'>
<textarea name='past' cols='80' rows='20'>
";

$x=0;
while($x<count($edit)){
echo $edit[$x];
$x++;
}
echo "
</textarea><P>
<INPUT TYPE='text' NAME='fichier' SIZE=40 MAXLENGTH=40 value='$fichier'><P>
<input type='submit' value=Modifier>
</form>
</div>
";

fclose($open);
?>
<HR WIDTH=50%><BR>
<DIV ALIGN="center">By <A HREF="mailto:Fatal@tipiak.net">Fatal</A> for Counter-Strike (<A HREF="http://www.tipiak.net" TARGET="_blank">www.tipiak.net</A>)</DIV>
