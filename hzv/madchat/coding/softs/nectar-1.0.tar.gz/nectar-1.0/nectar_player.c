#include "nectar.h"

typedef struct		s_nectar
{
  char			*input;

#ifndef NECTAR_WITHOUT_KLCPRS
  char			*input_;
#endif

  int			fd;

#ifndef NECTAR_WITHOUT_KLCPRS
  char			compression;
#endif

  char			quiet;
  struct termios	term;
  struct termios	save;
}			t_nectar;

t_nectar		nectar;

void			nectar_finish()
{
  if (tcsetattr(0, 0, &nectar.save) == -1)
    {
      if (!nectar.quiet)
	perror("tcsetattr");
      exit(EXIT_FAILURE);
    }

#ifndef NECTAR_WITHOUT_KLCPRS
  if (nectar.compression)
    unlink(nectar.input_);

  free(nectar.input_);
#endif

  close(nectar.fd);

  if (!nectar.quiet)
    printf("_ klc [www.klc-research.com] mycure\n");

  exit(EXIT_SUCCESS);
}

void			nectar_dump()
{
  char			buffer[BUFSIZ];
  t_entry		entry;

  while (read(nectar.fd, &entry, sizeof(t_entry)))
    {
      if (read(nectar.fd, buffer, entry.size) == -1)
	{
	  if (!nectar.quiet)
	    perror("read");
	  exit(EXIT_FAILURE);
	}
      buffer[entry.size] = 0;

#ifdef NECTAR_DEBUG
      printf("{ [entry] tv_sec=%u tv_usec=%u size=%u }\n",
	     entry.relative.tv_sec, entry.relative.tv_usec, entry.size);
#endif

      sleep(entry.relative.tv_sec);
      usleep(entry.relative.tv_usec);

      printf("%s", buffer);
      fflush(stdout);
    }
}

void			nectar_usage(int argc, char **argv)
{
  fprintf(stderr, "_ %s -[cqh] -d [filename] [input]\n", argv[0]);

#ifndef NECTAR_WITHOUT_KLCPRS
  fprintf(stderr, "     -c:   decompress input file\n");
  fprintf(stderr, "     -d:   decompress input file but use filename "
	  "as decompress filename\n");
#endif

  fprintf(stderr, "     -q:   quiet\n");
  fprintf(stderr, "     -h:   help\n");
}

void			nectar_options(int argc, char **argv)
{
  char			*fmt;
  char			c;

#ifndef NECTAR_WITHOUT_KLCPRS
  fmt = "cd:qh";
#else
  fmt = "qh";
#endif

  memset(&nectar, 0x0, sizeof(t_nectar));

  while ((c = getopt(argc, argv, fmt)) != EOF)
    {
      switch (c)
	{

#ifndef NECTAR_WITHOUT_KLCPRS
	case 'c':
	  nectar.compression = 1;
	  break;
	case 'd':
	  nectar.input_ = strdup(optarg);
	  nectar.compression = 1;
	  break;
#endif

	case 'q':
	  nectar.quiet = 1;
	  break;
	case 'h':
	  nectar_usage(argc, argv);
	  exit(EXIT_SUCCESS);
	}
    }

  if (argv[optind] == NULL)
    nectar.input = NECTAR_DEFAULT_FILE;
  else
    nectar.input = argv[optind];

#ifndef NECTAR_WITHOUT_KLCPRS
  if (!nectar.input_)
    {
      if (nectar.compression)
	{
	  nectar.input_ = malloc((strlen(nectar.input) + 2 + 1) *
				 sizeof(char));
	  sprintf(nectar.input_, "%s_", nectar.input);
	}
      else
	{
	  nectar.input_ = malloc((strlen(nectar.input) + 1) * sizeof(char));
	  sprintf(nectar.input_, "%s", nectar.input);
	}
    }
#endif

}

int			main(int argc, char **argv)
{
  struct termios	term;

  nectar_options(argc, argv);

  signal(SIGINT, nectar_finish);
  signal(SIGQUIT, nectar_finish);

#ifndef NECTAR_WITHOUT_KLCPRS
  if (nectar.compression)
    {
      klcprs_lzw_decompress(nectar.input);

      if ((nectar.fd = open(nectar.input_, O_RDONLY)) == -1)
	{
	  if (!nectar.quiet)
	    perror("open");
	  nectar_usage(argc, argv);
	  exit(EXIT_FAILURE);
	}
    }
  else
#endif
    {
      if ((nectar.fd = open(nectar.input, O_RDONLY)) == -1)
	{
	  if (!nectar.quiet)
	    perror("open");
	  nectar_usage(argc, argv);
	  exit(EXIT_FAILURE);
	}
    }

  if (tcgetattr(0, &nectar.term) < 0)
    {
      if (!nectar.quiet)
	perror("tcgetattr");
      exit(EXIT_FAILURE);
    }

  memcpy(&nectar.save, &nectar.term, sizeof(struct termios));

  nectar.term.c_lflag &= ~ECHO;
  if (tcsetattr(0, 0, &nectar.term) == -1)
    {
      if (!nectar.quiet)
	perror("tcsetattr");
      exit(EXIT_FAILURE);
    }

  nectar_dump();

  nectar_finish();
}
