#include "nectar.h"

typedef struct		s_nectar
{
  pid_t			pid;
  struct termios        term;
  struct termios	save;
  int			master;
  char			*output;

#ifndef NECTAR_WITHOUT_KLCPRS
  char			*output_;
#endif

  int			fd;

#ifndef NECTAR_WITHOUT_KLCPRS
  char			compression;
#endif

  int			append;
  char			quiet;

#ifndef NECTAR_WITHOUT_KLCPRS
  char			remove;
#endif

  int			canonic;
}			t_nectar;

t_nectar		nectar;

void			nectar_finish()
{
  if (tcsetattr(0, 0, &nectar.save) == -1)
    {
      if (!nectar.quiet)
	perror("tcsetattr");
      exit(EXIT_FAILURE);
    }

  close(nectar.fd);

#ifndef NECTAR_WITHOUT_KLCPRS
  /*
   * compression
   */

  if (!nectar.compression)
    {
      if (!nectar.quiet)
	printf("_ klc [www.klc-research.com] mycure\n");
      free(nectar.output_);
      exit(EXIT_SUCCESS);
    }

  if (!nectar.quiet)
    printf("_ compressing output file %s to %s\n", nectar.output_,
	   nectar.output);

  klcprs_lzw_compress(nectar.output_, nectar.output);

  if (nectar.remove)
    unlink(nectar.output_);

  free(nectar.output_);
#endif

  /*
   * exit
   */

  if (!nectar.quiet)
    printf("_ klc [www.klc-research.com] mycure\n");

  exit(EXIT_SUCCESS);
}

void			nectar_sig(int signum)
{
  kill(nectar.pid, signum);
}

char			**nectar_cut(char *line, char c)
{
  char			**data;
  int			nb;
  int			n;
  int			i;
  int			s;

  for (nb = 0, i = 0; line[i]; i++)
    if (line[i] == c)
      nb++;

  data = malloc((nb + 3) * sizeof(char *));
  for (n = 0, s = 0, i = 0; line[i]; i++)
    if (line[i] == c)
      {
        if (i - s)
          {
            data[n] = malloc((i - s + 1) * sizeof(char));
            bzero(data[n], i - s + 1);
            strncpy(data[n], line + s, i - s);
            data[n++][i - s] = 0;
          }
        else
          {
            data[n] = malloc(2);
            data[n++][0] = 0;
          }

        s = i + 1;
      }

  if (i - s)
    {
      data[n] = malloc((i - s + 1) * sizeof(char));
      bzero(data[n], i - s + 1);
      strncpy(data[n], line + s, i - s);
      data[n++][i - s] = 0;
    }
  else
    {
      data[n] = malloc(2);
      data[n++][0] = 0;
    }

  data[n] = 0;

  return (data);
}

void			nectar_events()
{
  t_entry		entry;
  fd_set		readf;
  struct timeval	cur;
  struct timeval	ref;

  if (gettimeofday(&ref, NULL) == -1)
    {
      if (!nectar.quiet)
	perror("gettimeofday");
      exit(EXIT_FAILURE);
    }

  while (1)
    {
    _retry:
      FD_ZERO(&readf);
      FD_SET(0, &readf);
      FD_SET(nectar.master, &readf);

      if (select(nectar.master + 1, &readf, NULL, NULL, NULL) < 0)
        {
          if (errno == EINTR)
            goto _retry;

	  if (!nectar.quiet)
	    perror("select");
	  exit(EXIT_FAILURE);
        }

      if (FD_ISSET(0, &readf))
        {
          char		buf[BUFSIZ];
          int		r;

          if ((r = read(0, buf, sizeof (buf))) < 0)
	    {
	      if (!nectar.quiet)
		perror("read");
	      exit(EXIT_FAILURE);
	    }

          if (r == 0)
            exit(EXIT_FAILURE);

          write(nectar.master, buf, r);
        }

      if (FD_ISSET(nectar.master, &readf))
        {
          char		buf[BUFSIZ];
          int		r;

          if ((r = read(nectar.master, buf, sizeof (buf))) < 0)
	    {
	      if (!nectar.quiet)
		perror("read");
	      exit(EXIT_FAILURE);
	    }

          if (r == 0)
            exit(EXIT_FAILURE);

          write(1, buf, r);

	  /*
	   * create a new entry a save current state in output file
	   */

	  gettimeofday(&cur, NULL);
	  timersub(&cur, &ref, &entry.relative);
	  entry.size = r;

	  ref.tv_sec = cur.tv_sec;
	  ref.tv_usec = cur.tv_usec;

	  write(nectar.fd, &entry, sizeof(t_entry));
	  write(nectar.fd, buf, r);
        }
    }
}

void			nectar_usage(int argc, char **argv)
{
  fprintf(stderr, "_ %s -[caqhr] [output]\n", argv[0]);

#ifndef NECTAR_WITHOUT_KLCPRS
  fprintf(stderr, "     -c:   compress output file\n");
#endif

  fprintf(stderr, "     -a:   append output file\n");
  fprintf(stderr, "     -q:   quiet\n");

#ifndef NECTAR_WITHOUT_KLCPRS
  fprintf(stderr, "     -r:   not remove uncompressed output file\n");
#endif

  fprintf(stderr, "     -n:   canonical mode. not in real mode. the output "
	  "file should have a smaller size (not default)\n");
  fprintf(stderr, "     -h:   help\n");
}

void			nectar_options(int argc, char **argv)
{
  char			*fmt;
  char			c;

#ifndef NECTAR_WITHOUT_KLCPRS
  fmt = "caqrnh";
#else
  fmt = "aqnh";
#endif

  memset(&nectar, 0x0, sizeof(t_nectar));

#ifndef NECTAR_WITHOUT_KLCPRS
  nectar.remove = 1;
#endif

  nectar.canonic = 0;

  while ((c = getopt(argc, argv, fmt)) != EOF)
    {
      switch (c)
	{

#ifndef NECTAR_WITHOUT_KLCPRS
	case 'c':
	  nectar.compression = 1;
	  break;
#endif

	case 'a':
	  nectar.append = 1;
	  break;
	case 'q':
	  nectar.quiet = 1;
	  break;

#ifndef NECTAR_WITHOUT_KLCPRS
	case 'r':
	  nectar.remove = 0;
	  break;
#endif

	case 'n':
	  nectar.canonic = 1;
	  break;
	case 'h':
	  nectar_usage(argc, argv);
	  exit(EXIT_SUCCESS);
	}
    }

  if (argv[optind] == NULL)
    nectar.output = NECTAR_DEFAULT_FILE;
  else
    nectar.output = argv[optind];

#ifndef NECTAR_WITHOUT_KLCPRS
  if (nectar.compression)
    {
      nectar.output_ = malloc((strlen(nectar.output) + 2 + 1) *
			      sizeof(char));
      sprintf(nectar.output_, "%s_", nectar.output);
    }
  else
    {
      nectar.output_ = malloc((strlen(nectar.output) + 1) * sizeof(char));
      sprintf(nectar.output_, "%s", nectar.output);
    }
#endif

}

int			main(int argc, char **argv, char **env)
{
  char			*file;

  nectar_options(argc, argv);

#ifndef NECTAR_WITHOUT_KLCPRS
  file = nectar.output_;
#else
  file = nectar.output;
#endif

  if (nectar.append)
    {
      if ((nectar.fd = open(file, O_WRONLY | O_APPEND)) == -1)
	{
	  if (!nectar.quiet)
	    perror("open");
	  nectar_usage(argc, argv);
	  exit(EXIT_FAILURE);
	}
    }
  else
    {
      if ((nectar.fd = open(file, O_WRONLY | O_CREAT |
			    O_TRUNC, 0700)) == -1)
	{
	  if (!nectar.quiet)
	    perror("open");
	  nectar_usage(argc, argv);
	  exit(EXIT_FAILURE);
	}
    }

  signal(SIGCHLD, nectar_finish);
  signal(SIGINT, nectar_sig);
  signal(SIGQUIT, nectar_sig);
  signal(SIGTSTP, nectar_sig);

  if ((nectar.pid = forkpty(&nectar.master, NULL, NULL, NULL)) < 0)
    {
      if (!nectar.quiet)
	perror("forkpty");
      exit(EXIT_FAILURE);
    }
  if (nectar.pid == 0)
    {
      char		**args;
      int		i;

      if (!nectar.quiet)
	printf("_ nectar started, output file is \"%s\"\n", nectar.output);

      args = nectar_cut(getenv("SHELL"), ' ');

      execve(args[0], args, env);

      if (!nectar.quiet)
	perror("execve");
    }

  if (tcgetattr(0, &nectar.term) < 0)
    {
      if (!nectar.quiet)
	perror("tcgetattr");
      exit(EXIT_FAILURE);
    }

  memcpy(&nectar.save, &nectar.term, sizeof(struct termios));

  if (!nectar.canonic)
    nectar.term.c_lflag &= ~(ICANON | ECHO);

  if (tcsetattr(0, 0, &nectar.term) == -1)
    {
      if (!nectar.quiet)
	perror("tcsetattr");
      exit(EXIT_FAILURE);
    }

  nectar_events();

  nectar_finish();
}
