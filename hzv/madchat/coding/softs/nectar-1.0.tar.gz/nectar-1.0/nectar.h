#include <unistd.h>
#include <stdlib.h>
#include <fcntl.h>
#include <signal.h>
#include <errno.h>
#include <termios.h>
#include <fcntl.h>
#include <string.h>
#include <stdio.h>
#include <sys/time.h>
#include <time.h>

#ifdef linux
#include <pty.h>
#include <utmp.h>
#endif

#ifdef NetBSD
#include <util.h>
#endif

#undef NECTAR_DEBUG

#define NECTAR_DEFAULT_FILE	"klc.ntr"

typedef struct		s_entry
{
  struct timeval	relative;
  unsigned int		size;
}			t_entry;
