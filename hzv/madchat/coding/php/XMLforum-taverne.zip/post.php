<?php
/*
 * ####################################################################
 * --------------------------------------------------------------------
 *                            XML Phorum 0.1
 *                    (Forum de discussion PHP en XML)
 *                       copyleft tobozo et leonard
 *         - tobozo@madchat.org
 *         - leonard@madchat.org
 *         - http://madchat.org/phorum/
 * --------------------------------------------------------------------
 *  Ce forum a �t� r�alis� sur la base du code
 *       de fouletexte 1.5 copyright (c) 2000 Thierry Arsicaud
 *             (http://www.echodelta.net/scriptsphp/).
 * --------------------------------------------------------------------
 * ####################################################################
 */

include("config.php");

$NombreMsgParPage=200;     // Nombre maximum de messages � afficher par page
$NombreMaxPages=100;      // Nombre maximum de pages de messages susceptibles d'�tre affich�es

// ###########################################################################


echo do_header();


if($refer) {
  $nomfichiermsg=$msg_dir."msg".$refer.".xml";

  // ======== Lecture du fichier msg__.dat et stockage des donn�es ========
  // ========               dans le tableau "$message"             ========
  $tabmessage=recuperer_message($nomfichiermsg);
  $nlignes=count($tabmessage)-1;

  // Rappel : le sujet est stock� dans la 4�me ligne
  $sujetMsgRef=$tabmessage[4];

  // Rappel : les lignes de texte du message proprement dit sont stock�es dans
  // les valeurs $tabmessage[5], $tabmessage[6]... jusqu'� $tabmessage[$nlignes]
  $texteMsgRef="--- Message d'origine --- ";

  for($compt=5;$compt<=$nlignes;$compt++) {
    $texteMsgRef=$texteMsgRef."~ ".$tabmessage[$compt];
    }

  // Note : le texte du message r�f�rant est stock� dans la variable $texteMsgRef
  }

$tpl->set_var(array(
//  TEXT     => stripslashes(strip_tags($sujetMsgRef))."<br>".stripslashes(strip_tags($texteMsgRef)),
  TEXT     => stripslashes(strip_tags($texteMsgRef)),
  ACTION   => "confirmpost.php",
  SUJET    => "Re: ".stripslashes(strip_tags($sujetMsgRef)),
  MSG      => "",
  REFER    => $refer
  ));

$form = $tpl->parse(OUT,"form");

echo $form;

echo do_footer();