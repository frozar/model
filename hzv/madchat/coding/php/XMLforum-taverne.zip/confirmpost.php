<?php
/*
 * ####################################################################
 * --------------------------------------------------------------------
 *                            XML Phorum 0.1
 *                    (Forum de discussion PHP en XML)
 *                       copyleft tobozo et leonard
 *         - tobozo@madchat.org
 *         - leonard@madchat.org
 *         - http://madchat.org/phorum/
 * --------------------------------------------------------------------
 *  Ce forum a �t� r�alis� sur la base du code
 *       de fouletexte 1.5 copyright (c) 2000 Thierry Arsicaud
 *             (http://www.echodelta.net/scriptsphp/).
 * --------------------------------------------------------------------
 * ####################################################################
 */

include("config.php");

echo do_header();

// #############################################################################
// *****************************************************************************
// Cr�ation du fichier "index.xml" s'il n'existe pas encore
// *****************************************************************************
if (!file_exists("index.xml")) {
   die("Error ! No index is set, please contact administrator");
   }

// *****************************************************************************
// Lecture du fichier index.dat et stockage des donn�es
// dans le tableau "$index"
// *****************************************************************************
$index=recuperer_index("index.xml");
$nombremsgs=count($index);

// #############################################################################
// *********************************************************************
// Test : cas de figure o� le message ne comprend pas de sujet,
// ou ne contient pas de texte
// *********************************************************************
if ((!$nom) and (!$adel) and (!$sujet) and (!$texte)) {
  print("<b>Erreur</b> : cette page ne peut �tre appel�e<br> que si un message a �t� pr�alablement <a href=\"post.php\">post�</a>.<br>Peut etre avez vous essaye de poster un message vide.<br> \n");
  }

elseif (!$texte) {
  print("<b>Erreur</b> : votre message ne comporte aucun texte.<br> \n");
  print("(Cliquez sur le bouton \"pr�c�dent\" pour revenir au formulaire)<br> \n");
  }
elseif (!$sujet) {
  print("<b>Erreur</b> : votre message ne comporte pas de sujet<br> \n");
  print("Entrez un sujet qui decrit bien votre message s'il vous plait.<br>(Cliquez sur le bouton \"pr�c�dent\" pour revenir au formulaire)<br> \n");
  }
#elseif (!$nom) {
  #  print("<b>Erreur</b> : vous avez oubli� d'indiquer votre nom.<br> \n");
  #  print("(Cliquez sur le bouton \"pr�c�dent\" pour revenir au formulaire)<br> \n");
  #}
// *********************************************************************
// Enregistrement du message
// *********************************************************************
else {
  // *********************************************************************
  // D�termination de l'identifiant du nouveau message (stock� dans
  // la variable "$IDnouvM"
  // *********************************************************************
  // cr�ation du tableau $tabidents, destin� � reccueillir les diff�rentes
  // valeurs des identifiants des messages

  //echo "Creating tabidents on $nombremsgs basis \n<br>"; // debug
  for($compt=1;$compt<=$nombremsgs;$compt++) {
    $tabidents[$compt]=intval($index[$compt][1]);
    //echo "Entry $compt : $tabidents[$compt] <br>\n"; // debug
    }

  if(!isset($tabidents)) {
    $IDnouvM=1;
    }
  else {
    $IDnouvM=max($tabidents)+1;   // Identifiant du nouveau message
    }

  // echo "nouvel ID : $IDnouvM\n<br>"; // debug

  // suppression du tableau $tabidents
  unset($tabidents);

  // =============================================================
  // Application de la fonction et r�cup�ration du rang et du
  // niveau du nouveau message
  // =============================================================
  if(!isset($refer)) $refer="0";

  $res=determin($refer); // determiner les infos du referent

  $RANGnouvM=$res[1];        // Rang du nouveau message
  $NIVEAUnouvM=$res[2];      // Niveau du nouveau message

  //echo "Rang du nouveau message (refer $refer)  : $RANGnouvM \n<br>";// debug
  //echo "Niveau du nouveau message : $NIVEAUnouvM \n<br>";// debug

  // ***************************************************************
  // d�finition d'�l�ments � int�grer dans les fichiers msgxx.dat
  //  et index.dat : date, champs vides, cha�ne date+nom+sujet
  // ***************************************************************
  // ==== D�finition de la date de r�daction du message ====
  $tdate=getdate();
  $jour=sprintf("%02.2d",$tdate["mday"])."/".sprintf("%02.2d",$tdate["mon"])."/".$tdate["year"];
  $heure=sprintf("%02.2d",$tdate["hours"])."H".sprintf("%02.2d",$tdate["minutes"]);
  $date=$jour.", ".$heure;

  // ===== Remplacement des champs vides par des ======
  // ===== informations du type "Pas de sujet"   ======
  if(!$refer) {
    $refer="n";
    }

  if(!$nom) {
    $nom="Pas de nom";
    }

  if ((!$adel) or (!ereg("^[^ ,;]+@[^ ,;]+[.][^ ,;]+$",$adel))) {
    $adel="noemail";
    }

  if (!$sujet) {
    $sujet="Pas de sujet";
    }


  // ===== Suppression des caract�res # et | et des tags html =====
  $nom=trim(stripslashes(stripSpeCar($nom)));
  $adel=trim(stripslashes(stripSpeCar($adel)));
  $sujet=trim(stripslashes(stripSpeCar($sujet)));
  $texte=trim(stripslashes(stripSpeCar($texte)));

  // *********************************************************************
  // Cr�ation du nouveau fichier "msgxx.dat"
  // *********************************************************************
  // et �criture des donn�es suivantes : identifiant message r�f�rant,
  // date, nom, adresse �lectronique, sujet, texte
  // *********************************************************************
  // ===== D�finition du nom du fichier =====
  $nomfichier=$msg_dir."msg".($IDnouvM).".xml";  // $IDnouvM

  // ========== Ecriture du fichier ==========
  if(file_exists($nomfichier)) die("File $nomfichier Already Exists, exiting ....");
  $fic=fopen($nomfichier,"w+") or die ("Erreur ! Votre message n'a pas pu �tre post�. <br> \n");

  $tpl->set_var(array(
      ID        => $refer,
      DATE      => $date,
      NOM       => $nom,
      EMAIL     => $adel,
      TITRE     => $sujet,
      MESSAGE   => htmlentities($texte)
      ));

  $content = $tpl->parse(OUT,"msg");

  //echo "<pre>".htmlentities($content)."\n\n</pre>";// debug

  if(!fputs($fic,$content)) die("Failed creating $nomfichier xml file \n<br>");
  fclose($fic);

  // *********************************************************************
  // Mise � jour du fichier index.xml
  // Reproduction du fichier d'origine avec insertion
  // des informations relatives au nouveau message
  // *********************************************************************
  // ====== insertion des informations relatives au nouveau ======
  // ====== message : identifiant ($idnm), niveau ($niveau) ======
  $ary=array();
  $ary[1] =$IDnouvM;     // identifiant du message
  $ary[2] =$NIVEAUnouvM; // niveau du message
  $ary[3] =$date;        // date
  $ary[4] =$nom;         // nom
  $ary[5] =$sujet;       // sujet

  if(insert_data($ary, $RANGnouvM)) {
    //echo "Index UPDATED !!!";
    print("Votre message a �t� post� correctement.<br>Merci de votre contribution.<br><br> \n");
    print("<a href=\"index.php\"><b>Retour sur le forum</b></a><br> \n");
    }
  else {
    //echo "Index NOT UPDATED !!!";
    print("Votre message n'a PAS �t� post� correctement.".
          "<br>Problemes de droits en �criture dans ce forum?.<br><br> \n");
    print("<a href=\"index.php\"><b>Retour sur le forum</b></a><br> \n");

    }
  }
// #####################################################################
echo do_footer();
?>
