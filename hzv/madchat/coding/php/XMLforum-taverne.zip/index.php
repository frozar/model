<?php
/*
 * ####################################################################
 * --------------------------------------------------------------------
 *                            XML Phorum 0.1
 *                    (Forum de discussion PHP en XML)
 *                       copyleft tobozo et leonard
 *         - tobozo@madchat.org
 *         - leonard@madchat.org
 *         - http://madchat.org/phorum/
 * --------------------------------------------------------------------
 *  Ce forum a �t� r�alis� sur la base du code
 *       de fouletexte 1.5 copyright (c) 2000 Thierry Arsicaud
 *             (http://www.echodelta.net/scriptsphp/).
 * --------------------------------------------------------------------
 * ####################################################################
 */

include("config.php");

$allowhtml        = 1;
$NombreMsgParPage = 200;              // Nombre maximum de messages � afficher par page
$NombreMaxPages   = 100;                // Nombre maximum de pages de messages susceptibles d'�tre affich�es

// ###########################################################################


echo do_header();


// #############################################################################
// *****************************************************************************
// Cr�ation du fichier "index.xml" s'il n'existe pas encore
// *****************************************************************************

if (!file_exists("index.xml")) {
   die("Error ! No index is set, please contact administrator");
   }

$index = recuperer_index("index.xml");
$nombremsgs=count($index);

// ###########################################################################
// **************************************************************************
// Cas de figure o� des messages ont �t� post�s dans le forum de discussion :
// Affichage des intitul�s des messages dans un tableau (utilisant les
// param�tres pr�cis�s plus haut)
// **************************************************************************


// ===================================================================
// D�termination de l'identifiant du dernier message post�

// cr�ation du tableau $tabidents, destin� � reccueillir les diff�rentes
// valeurs des identifiants des messages
for($compt=1;$compt<=$nombremsgs;$compt++) {
   $tabidents[$compt]=intval($index[$compt][1]);
   }

// Tri du tableau dans l'ordre inverse des valeurs
rsort($tabidents);

// D�termination des valeurs minimum et maximum des identifiants � signaler
@ $limMaxDerMessa=$tabidents[0];

if($nombremsgs<=$nombreNouveauxMessagesSignales) {
   @ $limMinDerMessa=$tabidents[$nombremsgs-1];
    }
else {
   $limMinDerMessa=$tabidents[$nombreNouveauxMessagesSignales-1];
   }

if($nombremsgs==1) {  // Cas de figure o� un seul message a �t� post�
   $limMaxDerMessa=1;
   $limMinDerMessa=1;
   }

// suppression du tableau $tabidents
unset($tabidents);

// **************************************************************************
// Prise en compte de la valeur $p, sens�e indiquer le num�ro de la page
// � afficher - D�termination des rangs min. et max. des messages � afficher
// dans la page
// **************************************************************************

if(@ !$p) $p=1;
$rangPMax=$nombremsgs-(($p-1)*$NombreMsgParPage);
$rangPMin=max($nombremsgs-($p*$NombreMsgParPage)+1,1);

// **************************************************************************
// Note : l'option "chrono" des versions pr�c�dentes de FouleTexte n'est
// d�sormais plus disponible : les messages sont maintenant automatiquement
// affich�s des plus r�cents aux plus anciens
// **************************************************************************

for($rangC=$rangPMax;$rangC>=$rangPMin;$rangC--) {    //  *** D�finition du premier curseur ($rangC), progressant par incr�mentation n�gative ***
   if($index[$rangC][2]==1) {                   // Cas de figure o� le rang du message rencontr� vaut 1
      $msg = $index[$rangC][1];

        if(!isset($msg)) $msg="";
        if(!$msg) {
          if(isset($index)) $msg=$index[$compt][1]; // identifiant du premier message post� dans le forum
          }

        // *****************************************************************************
        // R�cup�ration du nom du fichier correspondant au message � afficher
        // *****************************************************************************

        $nomfichiermsg=$msg_dir."msg".$msg.".xml";

        // ============================================================================
        // Cas de figure o� le message appel� n'existe pas ou n'existe plus
        // (suppression par l'administrateur du forum)
        // ============================================================================

        if(!file_exists($nomfichiermsg)) {
           if($nombremsgs<1) {
              print("Aucun message n'a �t� post� dans ce forum de discussion. <br> \n");
              print("Vous pouvez <a href=\"post.php\">poster</a> un premier message si vous le souhaitez.<br> \n");
              }
           else {
              print("Le message $msg n'existe pas ou a �t� supprim� par l'administrateur du forum de discussion.<br> \n");
              print("<a href=\"index.php\">Retour � la liste des messages post�s</a> \n");
              }
           }
        else {

           // *****************************************************************************
           // Affichage du message, et des intitul�s des �ventuels messages pr�c�dent et suivants
           // *****************************************************************************

           // *****************************************************************************
           // Lecture du fichier msg__.dat et stockage des donn�es
           // dans le tableau "$message"
           // *****************************************************************************

           $tabmessage=recuperer_message($nomfichiermsg);
           $nlignes=count($tabmessage)-1;

           // ============================================================================
           // Stockage des donn�es dans le tableau "$message"
           // ============================================================================

           $message[1]=$tabmessage[1];      // date
           $message[2]=$tabmessage[2];      // nom de l'auteur
           $message[3]=$tabmessage[3];      // adresse �lectronique de l'auteur
           $message[4]=$tabmessage[4];      // sujet

           // Note : les lignes de texte du message proprement dit sont stock�es dans les
           // les valeurs $tabmessage[5], $tabmessage[6]... jusqu'� $tabmessage[$nlignes]


           // *****************************************************************************
           // Affichage du sujet du message,
           // du nom de son auteur, de son adresse �lectronique,
           // de la date de r�daction et du texte du message proprement dit.
           // Les donn�es sont affich�es dans un tableau.
           // *****************************************************************************

           // ==== Affichage du sujet ====

           $tpl->set_var(array(
              PRE    =>"",
              ACTION =>"threadXML.php",
              NAME   =>"",
              ID     =>$msg,
              SUJET  =>stripslashes(htmlentities(strip_tags($message[4]))),
              DATE   =>ltrim(chop($message[1]))
              ));
           $msglink = $tpl->parse(OUT,"msglink");

           $tmp_msg = "";

           for($compt=5;$compt<=$nlignes;$compt++) {
              $tmp_msg .=$tabmessage[$compt];
              }

           $tpl->set_var(array(
              MSGLINK =>$msglink,
              MESSAGE =>tagster_format($tmp_msg, "_self", "link"),
              ACTION  =>"post.php",
              REFER   =>$msg
              ));
           $mess = $tpl->parse(OUT,"msglist");

           // ========= Affichage du lien permettant de poster une r�ponse =========
           echo $mess;
           // *****************************************************************************
           // Affichage du message pr�c�dent (s'il existe) dans un tableau
           // *****************************************************************************
           // =============================================================================
           // D�termination du rang du message affich� (identifiant $msg)
           // en vue de l'affichage des messages suivants et pr�c�dents �ventuels
           // =============================================================================

           $testrangmsg=1;

           while($index[$testrangmsg][1]!=$msg) {
              $testrangmsg++;
              }

           $rangmsg=$testrangmsg;

           // Note : le rang (dans l'index) du message est stock� dans $rangmsg
           // =======================================================================
           // test sur l'existence d'un �ventuel message pr�c�dent,
           // recherche de la r�f�rence de ce message pr�c�dent,
           // et affichage de son intitul�
           // =======================================================================
           // ---------- test sur l'existence du message pr�c�dent   ----------
           // ---------- et recherche de son rang                    ----------

           $rangmsgMS=$rangmsg+1;

           if(@ $index[$rangmsgMS][2]>$index[$rangmsg][2]) {
              // Affichage de la liste des messages suivants
              while(@ $index[$rangmsgMS][2]>$index[$rangmsg][2]) {
                 $tpl->set_var(array(
                     PRE    =>"",   // whitespaces($index[$rangmsgMS][2],"�"),
                     ACTION =>"threadXML.php",
                     NAME   =>$index[$rangmsgMS][1],
                     ID     =>$msg."#".$index[$rangmsgMS][1],
                     SUJET  =>stripslashes(htmlentities(strip_tags($index[$rangmsgMS][5]))),
                     DATE   =>ltrim(chop($index[$rangmsgMS][3]))
                     ));
                 echo $tpl->parse(OUT,"msglink");
                 $rangmsgMS++;
                 }
              }
           }
      // echo "lire.php?msg=".$index[$rangC][1]."\n";
      }
   }




$action= "confirmpost.php";

if ($refer) {
   $nomfichiermsg=$msg_dir."msg".$refer.".xml";
   // ======== Lecture du fichier msg__.xml et stockage des donn�es ========
   // ========               dans le tableau "$message"             ========
   $tabmessage=recuperer_message($nomfichiermsg);
   $nlignes=count($tabmessage)-1;
   // Rappel : le sujet est stock� dans la 4�me ligne
   $sujetMsgRef=$tabmessage[4];
   // Rappel : les lignes de texte du message proprement dit sont stock�es dans
   // les valeurs $tabmessage[5], $tabmessage[6]... jusqu'� $tabmessage[$nlignes]
   $texteMsgRef="--- Message d'origine ---\n";

   for($compt=5;$compt<=$nlignes;$compt++) {
      $texteMsgRef=$texteMsgRef."~ ".$tabmessage[$compt];
      }

   // Note : le texte du message r�f�rant est stock� dans la variable $texteMsgRef
   $sujet = "Re:".htmlentities(stripslashes(strip_tags($sujetMsgRef)));
   $msg = htmlentities(stripslashes(strip_tags($texteMsgRef)));
   }
else {
   $sujet = "";
   $msg = "";
   }

$tpl->set_var(array(
  TEXT     => "<HR>",
  ACTION   => $action,
  SUJET    => $sujet,
  MSG      => $msg,
  REFER    => $refer
  ));

$form = $tpl->parse(OUT,"form");

print $form;

print do_footer();

