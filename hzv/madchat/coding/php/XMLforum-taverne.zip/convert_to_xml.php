<?php

/*
 * ####################################################################
 * --------------------------------------------------------------------
 *                            XML Phorum 0.1
 *                    (Forum de discussion PHP en XML)
 *                       copyleft tobozo et leonard
 *         - tobozo@madchat.org
 *         - leonard@madchat.org
 *         - http://madchat.org/phorum/
 * --------------------------------------------------------------------
 *  Ce forum a �t� r�alis� sur la base du code
 *       de fouletexte 1.5 copyright (c) 2000 Thierry Arsicaud
 *             (http://www.echodelta.net/scriptsphp/).
 * --------------------------------------------------------------------
 * ####################################################################
 */


# UTILISER CE FICHIER POUR CONVERTIR FOULETEXTE->XML PHORUM
# NOTE : effacer d'abord le fichier index.xml et vider le repertoire
#        xmsgs de son contenu sinon ca ne marchera pas !

$inc_dir = "xinc/";
$tpl_dir = "xtpl/";
$msg_dir = "xmsg/";

include($inc_dir."template.inc");
include($inc_dir."function.inc");


$tpl = new template($tpl_dir);
$tpl->debug = 0;
$tpl->set_file(array(
  "header"     => "header.tpl",
  "index"      => "index.xtpl",
  "footer"     => "footer.tpl"
  ));
$header .= $tpl->parse(OUT,"header");

echo $header;

$tabindex=file("index.dat");
$nombremsgs=count($tabindex)-1;
$tpl->set_block("index", "loop_index", "indextpl");

echo "<pre>";

for($compt=1;$compt<=$nombremsgs;$compt++) {
  $index[$compt][1]=strtok($tabindex[$compt],"#"); // identifiant du message
  $index[$compt][2]=strtok("#");                   // niveau du message
  $chainetemp=strtok("#");                         // chaine date+nom+sujet
  $index[$compt][3]=strtok($chainetemp,"|");       // date
  $index[$compt][4]=strtok("|");                   // nom de l'auteur
  $index[$compt][5]=strtok("|");                   // sujet


  $tempw = fopen($msg_dir."msg".$index[$compt][1].".xml","w");
  $tempr = file("msg".$index[$compt][1].".dat");
  $id    = ltrim(chop($tempr[0]));
  $date  = ltrim(chop($tempr[1]));
  $nom   = ltrim(chop($tempr[2]));
  $email = ltrim(chop($tempr[3]));
  $titre = ltrim(chop($tempr[4]));
  $msg="";
  $i=4;
  while($i++<count($tempr)) $msg.=$tempr[$i];;
  $temptpl = new template($tpl_dir);
  $temptpl->set_file(array(
    "msg"        => "msg.xtpl"));
  $temptpl->set_var(Array(
     ID       =>$id,
     DATE     =>$date,
     NOM      =>$nom,
     EMAIL    =>$email,
     TITRE    =>$titre,
     MESSAGE  =>htmlentities($msg)));
  fputs($tempw,$temptpl->parse(OUT, "msg"));
  fclose($tempw);

  $tpl->set_var(array(
     ID     =>$index[$compt][1], // identifiant du message
     FROM   =>$index[$compt][2], // niveau du message
     DATE  =>$index[$compt][3],  // date
     NOM    =>$index[$compt][4], // nom de l'auteur
     TITRE  =>$index[$compt][5]  // sujet
     ));
  $tpl->parse("indextpl", "loop_index", true);
  }

$liste = fopen("index.xml", "w");
fputs($liste, $tpl->parse(OUT,"index"));
fclose($liste);
