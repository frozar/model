<?
/*
 * ####################################################################
 * --------------------------------------------------------------------
 *                            XML Phorum 0.1
 *                    (Forum de discussion PHP en XML)
 *                       copyleft tobozo et leonard
 *         - tobozo@madchat.org
 *         - leonard@madchat.org
 *         - http://madchat.org/phorum/
 * --------------------------------------------------------------------
 *  Ce forum a �t� r�alis� sur la base du code
 *       de fouletexte 1.5 copyright (c) 2000 Thierry Arsicaud
 *             (http://www.echodelta.net/scriptsphp/).
 * --------------------------------------------------------------------
 * ####################################################################
 */

$inc_dir = "xinc/";
$tpl_dir = "xtpl/";
$msg_dir = "xmsg/";

include($inc_dir."template.inc");
include($inc_dir."function.inc");


$tpl = new template($tpl_dir);
$tpl->debug = 0;
$tpl->set_file(array(
  // html templates
  "admin"        => "admin.tpl",
  "header"       => "header.tpl",
  "form"         => "form.tpl",
  "login"        => "loginform.tpl",
  "login2"       => "loginform2.tpl",
  "msglist"      => "msglist.tpl",
  "msglink"      => "msg.tpl",
  "threadlist"   => "threadlist.tpl",
  "footer"       => "footer.tpl",
  "threadfooter" => "footerThreadList.tpl",
  // xml templates
  "index"        => "index.xtpl",
  "msg"          => "msg.xtpl",
  "mdp"          => "mdp.xtpl"
  ));


$allowhtml        = 1;
$NombreMsgParPage = 200; // Nombre maximum de messages � afficher par page
$NombreMaxPages   = 100; // Nombre maximum de pages de messages susceptibles d'�tre affich�es


$NombreMsgParPage=2000; // Nombre maximum de messages � afficher par page

$NombreMaxPages=1000;  // Nombre maximum de pages de messages susceptibles d'�tre affich�es



// === Option permettant d'appliquer ou non les �ventuelles portions
// de code html ins�r�es dans les messages des utilisateurs (pour
// l'insertion directe de liens hypertextes par exemple) ===
$optionCodeHtml=0;  // 0 si vous ne souhaitez pas que le code html
                    // ins�r� soit appliqu� (recommand� pour des raisons de s�curit�)
                    // 1 si vous souhaitez que le code html ins�r� soit appliqu�



