<?php
/*
 * ####################################################################
 * --------------------------------------------------------------------
 *                            XML Phorum 0.1
 *                    (Forum de discussion PHP en XML)
 *                       copyleft tobozo et leonard
 *         - tobozo@madchat.org
 *         - leonard@madchat.org
 *         - http://madchat.org/phorum/
 * --------------------------------------------------------------------
 *  Ce forum a �t� r�alis� sur la base du code
 *       de fouletexte 1.5 copyright (c) 2000 Thierry Arsicaud
 *             (http://www.echodelta.net/scriptsphp/).
 * --------------------------------------------------------------------
 * ####################################################################
 */

include("config.php");


echo do_header();

// #############################################################################
// *****************************************************************************
// Cr�ation du fichier "index.xml" s'il n'existe pas encore
// *****************************************************************************
if (!file_exists("index.xml")) {
   $crfic=fopen("index.xml","w+");

   $tpl->set_var(array(
     ID    => 0,
     TITRE => "Message Initial",
     DATE     =>"ineffacable",  // date
     NOM      =>"Ne pas effacer" // nom de l'auteur
     ));

   fputs($crfic,$tpl->parse(OUT,"index"));
   fclose($crfic);

   $msgfic=fopen($msg_dir."msg0.xml","w+");

   $tpl->set_var(array(
     MESSAGE  =>"",
     ID       =>0, // identifiant du message
     DATE     =>"ineffacable",  // date
     NOM      =>"Ne pas effacer", // nom de l'auteur
     EMAIL    =>"Absolument pas",
     TITRE    =>"Message Initial"  // sujet
     ));

   fputs($msgfic,$tpl->parse(OUT,"msg"));
   fclose($msgfic);
   }

$index = recuperer_index("index.xml");
$nombremsgs=count($index);

// cr�ation du tableau $tabidents, destin� � reccueillir les diff�rentes
// valeurs des identifiants des messages
for($compt=1;$compt<=$nombremsgs;$compt++) {
   $tabidents[$compt]=intval($index[$compt][1]);
   //echo $compt." ".$tabidents[$compt]."\n<br>";
   }

if(!isset($idaction)) $idaction="";
if(!isset($pass)) $pass="";

// =============================================================================
// D�finition de la fonction "tabulation", utilis�e pour mat�rialiser
// la hierarchie du forum
// =============================================================================

function tabulation($n=1) {
  $espacevide=(30*($n-1)+40);
  return($espacevide);
  }

// =============================================================================
// D�finition de la fonction printform() qui imprime le formulaire
// correspondant � la demande "Veuillez entrer le mot de passe"
// =============================================================================

function printform() {
   global $tpl, $tpl_dir;
   $tpl->set_var(array(
     ACTION   => "admin.php",
     ));
   $form = $tpl->parse(OUT,"login");
   return $form;
   }

// =============================================================================
// D�finition de la fonction passprintform() qui imprime le formulaire correspondant
// � la demande "Veuillez choisir votre mot de passe"
// =============================================================================

function passprintform() {
  global $tpl, $tpl_dir, $pass;
  $tpl->set_var(array(
     ACTION   => "admin.php",
     PASS     => $pass
     ));
  $form = $tpl->parse(OUT,"login2");
  return $form;
  }

// #############################################################################
// *****************************************************************************
// R�cup�ration du mot de passe (si un mot de passe a d�j� �t� choisi
// par l'administrateur du forum de discussion)
// *****************************************************************************
if(file_exists("mdp.xml")) {
  $MDP = ltrim(chop(get_pass_from("mdp.xml")));
  // Note : le mot de passe est stock� dans la valeur "$MDP"
  }

// #############################################################################
// *****************************************************************************
// *****************************************************************************
// Modules de choix et de v�fification du mot de passe
// *****************************************************************************
// *****************************************************************************
// *****************************************************************************
// MODULE idaction=""
// cas de figure o� IDaction n'est pas renseign� (premier lancement du script) :
// V�rifie si un mot de passe a d�j� �t� choisi
// - si non : imprime le formulaire de choix de mot de passe
// - si oui : imprime le formulaire d'interrogation de mot de passe
// *****************************************************************************
if ($idaction=="") {
  if(!file_exists("mdp.xml")) {
  // aucun mot de passe n'a �t� choisi
    print("<center> \n");
    print("<br> \n");
    print("<font size=\"+1\"><b>Bienvenue sur l'interface d'administration<br>du forum de discussion</b></font> \n");
    print("<br><br> \n");
    print("Veuillez choisir le mot de passe administrateur. <br><br> \n");
    print("Ce mot de passe vous sera demand� chaque fois<br>que vous souhaiterez acc�der � cette interface, notamment<br> \n");
    print("si vous d�cidez de supprimer certains messages post�s par les utilisateurs. <br><br> \n");
    print("</center> \n");
    echo passprintform();
    }
  else {
  // un mot de passe a d�j� �t� choisi et enregistr�
    print("<center> \n");
    print("<br> \n");
    print("<font size=\"+1\"><b>Bienvenue sur l'interface d'administration<br>du forum de discussion</b></font> \n");
    print("<br><br> \n");
    print("Veuillez vous identifier SVP. <br> \n");
    print("</center> \n");
    print("<br> \n");
    echo printform();
    }
  }

// *****************************************************************************
// Module idaction="testChoixMDP" :
// V�rifie si les deux valeurs "Mot de Passe"  entr�es par l'utilisateur sont
// �quivalentes
// - si non : envoie un message d'avertissement et imprime � nouveau
// le formulaire de choix du mot de passe
// - si oui : enregistre le mot de passe dans le fichier mdep.php et cr�e
// la variable "$pass" n�cessaire pour acc�der au menu des actions possibles
// *****************************************************************************

if ($idaction=="testChoixMDP") {

   // conversion des deux valeurs en minuscule
   //$mdputil1=strtolower($mdputil1);
   //$mdputil2=strtolower($mdputil2);

  if(file_exists("mdp.xml") and $pass!=$MDP) {
    // protection contre des appels du script destin�s � "faire sauter"
    // le mot de passe
    print("Erreur : Veuillez vous <a href=\"admin.php\">identifier</a> � nouveau.");
    exit;
    }

  if($mdputil1=="") {
    // cas de figure o� l'utilisateur a valid� le formulaire pr�c�dent
    // sans entrer de valeurs
    print("<br> \n");
    print("<center> \n");
    print("Veillez recommencer l'op�ration SVP.");
    print("</center> \n");
    echo passprintform();
    exit;
    }

  if ($mdputil1!=$mdputil2) {
  // cas de figure o� les deux valeurs entr�es par l'utilisateur ne coincident pas
    print("<center> \n");
    print("<br> \n");
    print("Les deux valeurs que vous avez entr�es ne coincident pas. Veuiller recommencer SVP. <br> \n");
    print("</center>");
    echo passprintform();
    }
  else {
  // cas de figure o� les deux valeurs entr�es par l'utilisateur coincident
    // --- Enregistrement du mot de passe dans le fichier mdp.xml
    $ficmdep=fopen("mdp.xml","w") or die("Unable to access password file\n<Br>");
    $tpl->set_file(array(
       "mdp"     => "mdp.xtpl"
       ));
    $tpl->set_var(array(
       ID  =>md5($mdputil1)
       ));
    $newxml = $tpl->parse(OUT, "mdp");
    fputs($ficmdep,$newxml);
    fclose($ficmdep);

    // D�finition de la valeur "$pass", qui sera n�cessaire pour les
    // op�rations de configuration ou de suppression de messages
    // Note : "$pass" est produit � partir du mot de passe (crypt�)
    $MDP=md5($mdputil1);
    $MDPcode=$MDP;

    // --- Affichage d'un message de confirmation et impression
    // d'un bouton "Passage � la suite".
    print("<center> \n");
    print("<br> \n");
    print("Le mot de passe a bien �t� enregistr�. <br> \n");
    print("<form method=\"POST\" action=\"admin.php\"> \n");
    print("<input type=\"hidden\" name=\"idaction\" value=\"menuGen\"> \n");
    print("<input type=\"hidden\" name=\"pass\" value=\"$MDP\"> \n");
    print("<input type=\"submit\" value=\"Passer � la suite\" name=\"A1\"> \n");
    print("</form> \n");
    print("</center> \n");
    }
  }

// *****************************************************************************
// MODULE idaction="verifMDP" :
// V�rifie si le mot de passe entr� par l'utilisateur est correct
// - si non : envoie un message d'avertissement et imprime � nouveau
// le formulaire d'interrogration du mot de passe
// - si oui : cr�e la variable "$pass" n�cessaire pour acc�der au menu
// des actions possibles
// *****************************************************************************

if ($idaction=="verifMDP") {
  // la valeur entr�e par l'utilisateur est convertie en minuscules
  //$mdputil=strtolower($mdputil);
  if($MDP!=md5($mdputil)) {
  // cas de figure o� la valeur entr�e par l'utilisateur n'est pas correcte
    print("<center> \n");
    print("<br> \n");
    print("Le mot de passe entr� n'est pas valable. Veuillez � nouveau vous identifier.");
    print("</center> \n");
    echo printform();
    }
  else {
    // cas de figure o� la valeur entr�e par l'utilisateur correspond au mot de passe
    $idaction="menuGen";
    $MDPcode=$MDP;
    $pass=$MDPcode;
    // -------------------------------------------
    // ------ On passe � la suite du script ------
    // -------------------------------------------
    }
  }

// #############################################################################
// *****************************************************************************
// *****************************************************************************
// Modules correspondant aux fonctions d'administration
// *****************************************************************************
// *****************************************************************************

// *****************************************************************************
// Module idaction="menuGen" :
// Affiche le menu g�n�ral des actions possibles
// *****************************************************************************

if ($idaction=="menuGen") {
  if ($pass!=$MDP) {
    print("Erreur : Veuillez vous <a href=\"admin.php\">identifier</a> � nouveau.");
    }
  }

// *****************************************************************************
// Module idaction="menuSupMsgs" :
// Affiche le menu "Suppression de messages"
// *****************************************************************************


if ($pass!=$MDP) {
  print("Erreur : Veuillez vous <a href=\"admin.php\">identifier</a> � nouveau.");
  }
else {
    // ==========================================================================
    // Cas de figure o� aucun message n'a  encore �t� post� dans le forum de discussion
    // ==========================================================================
    if($nombremsgs<1) {
      print("<br> \n");
      print("<center> \n");
      print("Aucun message n'a �t� post� dans ce forum de discussion. <br> \n");
      print("<form method=\"POST\" action=\"admin.php\"><input type=\"hidden\" name=\"idaction\" value=\"menuGen\"><input type=\"hidden\" name=\"pass\" value=\"$pass\"><input type=\"submit\" value=\"Retour au menu g�n�ral\" name=\"A1\"></form> \n");
      print("</center> \n");
      exit;
      }

    // ==========================================================================
    // Affichage des intitul�s des messages dans un tableau (utilisant les
    // param�tres pr�cis�s plus haut)
    // ==========================================================================


    if(!$idmsgsup  && !$rangsupmin && !$rangsupmax) {
      $tpl->set_block("admin", "loop", "admintpl");
      for($compt=1;$compt<=$nombremsgs;$compt++) {
        if($index[$compt][2]==1) {
          $ouch = "#";
          }
        else {
          $ouch = ">";
          }
        $tpl->set_var(array(
          ID     => $index[$compt][1],
          WIDTH  => tabulation(($index[$compt][2])-1),
          OUCH   => $ouch,
          TITRE  => stripslashes(htmlentities(strip_tags($index[$compt][5]))),
          AUTEUR => stripslashes(htmlentities(strip_tags($index[$compt][4]))),
          DATE   => $index[$compt][3]

          ));
        $tpl->parse("admintpl", "loop", true);
        // insertion d'un tableau � une ligne et deux colonnes
        // destin� � mat�rialiser la hierarche du forum
        }
      $allthreads = $tpl->parse(OUT, "admin");
      echo $allthreads;

      // ==========================================================================
      // Impression d'un message d'avertissement et du formulaire de saisie
      // d'identifiant de message � supprimer
      // ==========================================================================
      print("<br> \n");
      print("<table cellpadding=\"5\" border=\"1\"  align=\"center\"> \n");
      print("<tr><td align=\"center\"> \n");
      print("Pour supprimer un message du forum,<br> entrez ici son <b>num�ro d'identification</b> : <br> \n");
      print("<form method=\"POST\" action=\"admin.php\"> \n");
      print("<input type=\"text\" name=\"idmsgsup\" size=\"5\"><br> \n");
      print("<input type=\"hidden\" name=\"idaction\" value=\"demandConfirmSuppMsg\"> \n");
      print("<input type=\"hidden\" name=\"pass\" value=\"$pass\"> \n");
      print("<br> \n");
      print("<input type=\"submit\" value=\"Envoyer\" name=\"A1\">");
      print("</form> \n");
      print(  "<b>Attention !</b> la suppression d'un message entraine automatiquement<br> la suppression des messages qui le suivent dans le fil de discussion<br>(m�me sujet de discussion). \n");
      print("</td></tr> \n");
      print("</table> \n");
      print("</center> \n");
      }

    }


// *****************************************************************************
// Module idaction="demandConfirmSuppMsg" :
// Affiche la page de demande de confirmation de suppression
// *****************************************************************************

if ($idaction=="demandConfirmSuppMsg") {
  if ($pass!=$MDP) {
    print("Erreur : Veuillez vous <a href=\"admin.php\">identifier</a> � nouveau.");
    }
  else {
    // ==========================================================================
    // Lecture du fichier "index.xml" et stockage des donn�es (identifiant,
    // niveau, date, nom et sujet) dans le tableau "$index"
    // ==========================================================================
    // ==========================================================================
    // Cas de figure o� l'utilisateur a entr� une "valeur vide"
    // ==========================================================================
    if($idmsgsup=="") {
      print("<br> \n");
      print("<center> \n");
      print("Erreur ! Vous n'avez saisi aucune valeur. <br> \n");
      print("<form method=\"POST\" action=\"admin.php\"><input type=\"hidden\" name=\"idaction\" value=\"menuSupMsgs\"><input type=\"hidden\" name=\"pass\" value=\"$pass\"><input type=\"submit\" value=\"Retour au menu de suppression de messages\" name=\"A1\"></form> \n");
      print("</center> \n");
      exit;
      }

    // ==========================================================================
    // Cas de figure o� le num�ro de message � supprimer est aberrant
    // ==========================================================================

    if(($idmsgsup<0) or (!file_exists($msg_dir."msg".$idmsgsup.".xml"))) {
      print("<br> \n");
      print("<center> \n");
      print("Erreur ! Ce message n'existe pas<br> ou a d�j� �t� supprim� par l'administrateur du forum de discussion. <br> \n");
      print("<form method=\"POST\" action=\"admin.php\"><input type=\"hidden\" name=\"idaction\" value=\"menuSupMsgs\"><input type=\"hidden\" name=\"pass\" value=\"$pass\"><input type=\"submit\" value=\"Retour au menu de suppression de messages\" name=\"A1\"></form> \n");
      print("</center> \n");
      exit;
      }

    // ==========================================================================
    // Cas de figure o� le message a d�j� �t� supprim� par l'administrateur
    // ==========================================================================
    if(!file_exists($msg_dir."msg".$idmsgsup.".xml")) {
      print("Ce message a d�j� �t� supprim� par l'administrateur. <br> \n");
      print("<form method=\"POST\" action=\"admin.php\"><input type=\"hidden\" name=\"idaction\" value=\"menuSupMsgs\"><input type=\"hidden\" name=\"pass\" value=\"$pass\"><input type=\"submit\" value=\"Retour au menu de suppression de messages\" name=\"A1\"></form> \n");
      exit;
      }

    // ==========================================================================
    // Recherche du rang du premier message � supprimer
    // ==========================================================================
    $rangMsgSupP=1;
    while(@ $index[$rangMsgSupP][1]!=$idmsgsup) {
      $rangMsgSupP++;
      }

    // le rang du premier message � supprimer est stock� dans $rangMsgSupP
    // ==========================================================================
    // Recherche du rang du dernier message � supprimer
    // ==========================================================================
    $rangMsgSupD=$rangMsgSupP;
    while(@ $index[$rangMsgSupD+1][2]>$index[$rangMsgSupP][2]) {
      $rangMsgSupD++;
      }

    // le rang du dernier message � supprimer est stock� dans $rangMsgSupD
    // ==========================================================================
    // Affichage d'un message d'avertissement
    // ==========================================================================
    print("<br> \n");
    print("<table border=\1\"  align=\"center\" cellpadding=\"15\"> \n");
    print("<tr><td align=\"center\"> \n");
    print("<center><b>Vous �tes sur le point de supprimer le(s) message(s) suivant(s)</b> : </center><br> \n");

    // ==========================================================================
    // Affichage des intitul�s des messages � supprimer dans un tableau
    // ==========================================================================
;
    $tpl->set_block("admin", "loop", "admintpl2");

    for($compt=$rangMsgSupP;$compt<=$rangMsgSupD;$compt++) {
       // insertion d'un tableau � une ligne et deux colonnes
       // destin� � mat�rialiser la hierarche du forum
       if($index[$compt][2]==1) {
          $ouch = "#";
          }
       else {
          $ouch = ">";
          }
       $tpl->set_var(array(
          ID     => $index[$compt][1],
          WIDTH  => tabulation(($index[$compt][2])-1),
          OUCH   => $ouch,
          TITRE  => stripslashes(htmlentities(strip_tags($index[$compt][5]))),
          AUTEUR => stripslashes(htmlentities(strip_tags($index[$compt][4]))),
          DATE   => $index[$compt][3]
          ));
       $tpl->parse("admintpl2", "loop", true);
       }

    $allthreads = $tpl->parse(OUT, "admin");

    echo $allthreads;

    // ==========================================================================
    // Affichage de la demande de confirmation
    // ==========================================================================
    print("<center> \n");
    print("<form method=\"POST\" action=\"admin.php\"> \n");
    print("<input type=\"hidden\" name=\"idaction\" value=\"suppresMsgs\"> \n");
    print("<input type=\"hidden\" name=\"pass\" value=\"$pass\"> \n");
    print("<input type=\"hidden\" name=\"rangsupmin\" value=\"$rangMsgSupP\"> \n");
    print("<input type=\"hidden\" name=\"rangsupmax\" value=\"$rangMsgSupD\"> \n");
    print("<input type=\"submit\" value=\"Confirmer la suppression\" name=\"A1\"> \n");
    print("</form> \n");
    print("</center> \n");
    print("</td></tr> \n");
    print("</table> \n");
    print("<center> \n");
    print("<form method=\"POST\" action=\"admin.php\"><input type=\"hidden\" name=\"idaction\" value=\"menuGen\"><input type=\"hidden\" name=\"pass\" value=\"$pass\"><input type=\"submit\" value=\"Annuler (retour au menu g�n�ral)\" name=\"A1\"></form> \n");
    print("</center> \n");
    print("</center> \n");
    }
  }

// *****************************************************************************
// Module idaction="suppresMsgs" :
// Affiche la page de confirmation de suppression d�finitive de messages
// *****************************************************************************

if ($idaction=="suppresMsgs") {
  if ($pass!=$MDP) {
    print("<br> \n");
    print("Erreur : Veuillez vous <a href=\"admin.php\">identifier</a> � nouveau.");
    }
  else {
    // ==========================================================================
    // Lecture du fichier "index.xml" et stockage des donn�es dans le tableau
    // $index
    // ==========================================================================
    // ==========================================================================
    // Suppression des fichiers msg__.dat
    // ==========================================================================

    if($rangsupmax>$nombremsgs) {
      print("<br> \n");
      print("<center> \n");
      print("Vous avez probablement tent� d'actualiser la page de confirmation de suppression de message. <br> \n");
      print("Cette op�ration n'a pas eu de cons�quences dans ce cas pr�cis.<br> \n");
      print("Elle aurait toutefois pu causer une erreur et endommager la structure du forum de discussion.<br><br> \n");
      print("<form method=\"POST\" action=\"admin.php\"><input type=\"hidden\" name=\"idaction\" value=\"menuGen\"><input type=\"hidden\" name=\"pass\" value=\"$pass\"><input type=\"submit\" value=\"Retour au menu g�n�ral\" name=\"A1\"></form> \n");
      exit;
      }

    print("<br> \n");
    print("<center> \n");
    for($compt=$rangsupmin;$compt<=$rangsupmax;$compt++) {
      $testsup=unlink($msg_dir."msg".$index[$compt][1].".xml");
      if($testsup) {
        print("Le message n� ".$index[$compt][1]." a bien �t� supprim�. <br> \n");
        }
      else {
       print("Impossible de supprimer le message n� ".$index[$compt][1].". <br> \n");
       print("<form method=\"POST\" action=\"admin.php\"><input type=\"hidden\" name=\"idaction\" value=\"menuGen\"><input type=\"hidden\" name=\"pass\" value=\"$pass\"><input type=\"submit\" value=\"Retour au menu g�n�ral\" name=\"A1\"></form> \n");
       exit;
       }
     }
    print("</center> \n");

   // ==========================================================================
    // Recopie du fichier "index.xml", avec omission des lignes concernant les
    // messages � supprimer
    // ==========================================================================

    $ficindex=fopen("index.xml","w");

    //fputs($ficindex,"Fichier Index. Ne pas �diter !\n");

    // --- recopie des premi�res lignes du fichier index.dat ---
    $tpl->set_block("index", "loop_index", "indextpl");

    for($compt=1;$compt<=$rangsupmin-1;$compt++) {
      $tpl->set_var(array(
         ID     =>$index[$compt][1], // identifiant du message
         FROM   =>$index[$compt][2], // niveau du message
         DATE   =>$index[$compt][3], // date
         NOM    =>$index[$compt][4], // nom de l'auteur
         TITRE  =>$index[$compt][5]  // sujet
         ));
      $tpl->parse("indextpl", "loop_index", true);
      }

    // --- recopie des derni�res lignes du fichier index.dat ---
    for($compt=$rangsupmax+1;$compt<=$nombremsgs;$compt++) {
      $tpl->set_var(array(
         ID     =>$index[$compt][1], // identifiant du message
         FROM   =>$index[$compt][2], // niveau du message
         DATE   =>$index[$compt][3], // date
         NOM    =>$index[$compt][4], // nom de l'auteur
         TITRE  =>$index[$compt][5]  // sujet
         ));
      $tpl->parse("indextpl", "loop_index", true);
      }

    $all .= $tpl->parse(OUT,"index");

    fputs($ficindex,$all);
    fclose($ficindex);

    // ==========================================================================
    // V�rification du bon d�roulement de l'op�ration de r��criture
    // du fichier "index.dat"
    // ==========================================================================

    $tabindverif=recuperer_index("index.xml");
    $nombremsgsnouv=count($tabindverif);

    if($nombremsgsnouv!=(($nombremsgs-($rangsupmax-$rangsupmin+1)))) {
      print("Erreur durant l'op�ration de mise � jour du fichier index.<br> \n");
      print("La structure du forum a peut-�tre �t� endommag�e.<br> \n");
      print("<form method=\"POST\" action=\"admin.php\"><input type=\"hidden\" name=\"idaction\" value=\"menuGen\"><input type=\"hidden\" name=\"pass\" value=\"$pass\"><input type=\"submit\" value=\"Annuler (retour au menu g�n�ral)\" name=\"A1\"></form> \n");
      exit;
      }
    else {
      print("<center> \n");
      print("Mise � jour de l'index termin�e.<br> \n");
      print("<br> \n");
     print("<form method=\"POST\" action=\"admin.php\"><input type=\"hidden\" name=\"idaction\" value=\"menuGen\"><input type=\"hidden\" name=\"pass\" value=\"$pass\"><input type=\"submit\" value=\"Retour au menu g�n�ral\" name=\"A1\"></form> \n");
     // print("<form method=\"POST\" action=\"admin.php\"><input type=\"hidden\" name=\"idaction\" value=\"menuSupMsgs\"><input type=\"hidden\" name=\"pass\" value=\"$pass\"><input type=\"submit\" value=\"Retour au menu de suppression de messages\" name=\"A1\"></form> \n");
      print("</center> \n");
    }

  }
}

// *****************************************************************************
// Module idaction="menuChangeMDP" :
// Affiche le menu permettant de changer le mot de passe
// *****************************************************************************

if ($idaction=="menuChangeMDP") {
  if ($pass!=$MDP) {
    //print("Erreur : Veuillez vous <a href=\"admin.php\">identifier</a> � nouveau.");
    }
  else {
    print("<center> \n");
    print("<br> \n");
    print("<b>D�finition d'un nouveau mot de passe</b> <br> \n");
    echo passprintform();
    print("</center> \n");
  }
}

echo do_footer();
