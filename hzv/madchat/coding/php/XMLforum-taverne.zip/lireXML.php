<?php
/*
 * ####################################################################
 * --------------------------------------------------------------------
 *                            XML Phorum 0.1
 *                    (Forum de discussion PHP en XML)
 *                       copyleft tobozo et leonard
 *         - tobozo@madchat.org
 *         - leonard@madchat.org
 *         - http://madchat.org/phorum/
 * --------------------------------------------------------------------
 *  Ce forum a �t� r�alis� sur la base du code
 *       de fouletexte 1.5 copyright (c) 2000 Thierry Arsicaud
 *             (http://www.echodelta.net/scriptsphp/).
 * --------------------------------------------------------------------
 * ####################################################################
 */

include("config.php");

echo do_header();
// #############################################################################
// *****************************************************************************
// Cr�ation du fichier "index.xml" s'il n'existe pas encore
// *****************************************************************************

if (!file_exists("index.xml")) {
   die("Error ! No index is set, please contact administrator");
   }

// *****************************************************************************
// Lecture du fichier index.dat et stockage des donn�es
// dans le tableau "$index"
// *****************************************************************************

$messagefile = $msg_dir."msg".$msg.".xml";
$index=recuperer_message($messagefile) or die("Impossible d'ouvrir le message $msg \n<br>");

for($compt=5;$compt<=count($index);$compt++) {
   // if(!$optionCodeHtml)
   $tmp_msg .=$index[$compt];
   }

$tmp_msg = tagster_format($tmp_msg, "_self", "link"); // formattage <a href> et <mailto>

$tpl->set_var(array(
      MSGLINK =>$index[1]."|".$index[2]."|".$index[3]."|".$index[4],
      MESSAGE =>$tmp_msg,
      ACTION  =>"",
      REFER   =>""
      ));

$mess = $tpl->parse(OUT,"msglist");

echo $mess;