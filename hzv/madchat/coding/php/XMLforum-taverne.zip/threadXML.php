<?php
/*
 * ####################################################################
 * --------------------------------------------------------------------
 *                            XML Phorum 0.1
 *                    (Forum de discussion PHP en XML)
 *                       copyleft tobozo et leonard
 *         - tobozo@madchat.org
 *         - leonard@madchat.org
 *         - http://madchat.org/phorum/
 * --------------------------------------------------------------------
 *  Ce forum a �t� r�alis� sur la base du code
 *       de fouletexte 1.5 copyright (c) 2000 Thierry Arsicaud
 *             (http://www.echodelta.net/scriptsphp/).
 * --------------------------------------------------------------------
 * ####################################################################
 */

include("config.php");

echo do_header();
// #############################################################################
// *****************************************************************************
// Cr�ation du fichier "index.xml" s'il n'existe pas encore
// *****************************************************************************

if (!file_exists("index.xml")) {
   die("Error ! No index is set, please contact administrator");
   }

// *****************************************************************************
// Lecture du fichier index.dat et stockage des donn�es
// dans le tableau "$index"
// *****************************************************************************

$index=recuperer_index("index.xml");
$nombremsgs=count($tabindex)-1;


// #############################################################################
// #############################################################################
// *****************************************************************************
// Cas de figure o� le script est appel� sans renseignements sur la valeur $msg.
// Par d�faut, $msg prend la valeur de l'identifiant du premier message post�
//  dans le forum.
// *****************************************************************************
if(!isset($msg)) $msg="";
if(!$msg) {
  if(isset($index)) $msg=$index[$compt][1]; // identifiant du premier message post� dans le forum
  }
// *****************************************************************************
// R�cup�ration du nom du fichier correspondant au message � afficher
// *****************************************************************************
$nomfichiermsg=$msg_dir."msg".$msg.".xml";

// ============================================================================
// Cas de figure o� le message appel� n'existe pas ou n'existe plus
// (suppression par l'administrateur du forum)
// ============================================================================

if(!file_exists($nomfichiermsg)) {
  if($nombremsgs<1) {
    print("Aucun message n'a �t� post� dans ce forum de discussion. <br> \n");
    print("Vous pouvez <a href=\"post.php\">poster</a> un premier message si vous le souhaitez.<br> \n");
    }
  else {
    print("Ce message n'existe pas ou a �t� supprim� par l'administrateur du forum de discussion.<br> \n");
    print("<a href=\"index.php\">Retour � la liste des messages post�s</a> \n");
    }

  }
else {
  // *****************************************************************************
  // Affichage du message, et des intitul�s des �ventuels messages pr�c�dent et suivants
  // *****************************************************************************
  // *****************************************************************************
  // Lecture du fichier msg__.dat et stockage des donn�es
  // dans le tableau "$message"
  // *****************************************************************************

  $tabmessage=recuperer_message($nomfichiermsg);
  $nlignes=count($tabmessage)-1;

  // ============================================================================
  // Stockage des donn�es dans le tableau "$message"
  // ============================================================================

  $message[1]=$tabmessage[1];      // date
  $message[2]=$tabmessage[2];      // nom de l'auteur
  $message[3]=$tabmessage[3];      // adresse �lectronique de l'auteur
  $message[4]=$tabmessage[4];      // sujet

  // Note : les lignes de texte du message proprement dit sont stock�es dans les
  // les valeurs $tabmessage[5], $tabmessage[6]... jusqu'� $tabmessage[$nlignes]
  // *****************************************************************************
  // Affichage du sujet du message,
  // du nom de son auteur, de son adresse �lectronique,
  // de la date de r�daction et du texte du message proprement dit.
  // Les donn�es sont affich�es dans un tableau.
  // *****************************************************************************

  // ==== Affichage du sujet ====
  $tpl->set_var(array(
      PRE    =>"",
      ACTION =>"threadXML.php",
      ID     =>$msg,
      SUJET  =>stripslashes(htmlentities(strip_tags($message[4]))),
      DATE   =>$message[1]
      ));
  $msglink = $tpl->parse(OUT,"msglink");
  $tmp_msg = "";

  for($compt=5;$compt<=$nlignes;$compt++) {
     // if(!$optionCodeHtml)
     $tmp_msg .=$tabmessage[$compt];
     }

  //$tmp_msg = tagster_format($tmp_msg, "_self", "link"); // formattage <a href> et <mailto>

  $tpl->set_var(array(
      MSGLINK =>$msglink,
      MESSAGE => tagster_format($tmp_msg, "_self", "link"),
      ACTION  =>"post.php",
      REFER   =>$msg
      ));

  $mess = $tpl->parse(OUT,"msglist");

  echo $mess;
  // *****************************************************************************
  // Affichage du message pr�c�dent (s'il existe) dans un tableau
  // *****************************************************************************
  // =============================================================================
  // D�termination du rang du message affich� (identifiant $msg)
  // en vue de l'affichage des messages suivants et pr�c�dents �ventuels
  // =============================================================================

  $testrangmsg=1;
  while($index[$testrangmsg][1]!=$msg) {
    $testrangmsg++;
    }

  $rangmsg=$testrangmsg;

  $rangmsgMS=$rangmsg+1;

  if(@ $index[$rangmsgMS][2]>$index[$rangmsg][2]) {
    // Affichage de la liste des messages suivants
      while(@ $index[$rangmsgMS][2]>$index[$rangmsg][2]) {
         /*$msg = $index[$rangmsgMS][1];
         $name = $msg;*/
         $t_msg=$msg_dir."msg".$index[$rangmsgMS][1].".xml";
         if(file_exists($t_msg)) {
           if($q++==1) $sujet =stripslashes(htmlentities(strip_tags($index[$rangmsgMS][5])));
           $tmp_ary = recuperer_message($t_msg);
           $tpl->set_var(array(
              PRE    =>"",
              ACTION =>"threadXML.php",
              NAME   =>$index[$rangmsgMS][1],
              ID     =>$index[$rangmsgMS][1],
              SUJET  =>stripslashes(htmlentities(strip_tags($index[$rangmsgMS][5]))),
              DATE   =>$index[$rangmsgMS][3]
              ));

           $msglink = $tpl->parse(OUT,"msglink");

           $tpl->set_var(array(
             ACTION   =>"post.php",
             MSGLINK  =>$msglink,
             MESSAGE  =>tagster_format($tmp_ary[5], "_self", "link"),
             REFER    =>$index[$rangmsgMS][1],
             ));
           echo $tpl->parse(OUT,"msglist");
           }
         else {
           die("Index corrupted, trying to access file '$t_msg'\n<br>");
           }
         // echo $index[$rangmsgMS][1]."<br>";
         //@include ("lireXMLthread.php");
         $rangmsgMS++;
         }
      }
   }



$action= "confirmpost.php";

$tpl->set_var(array(
  TEXT     => "",
  ACTION   => $action,
  SUJET    => "Re: ".stripslashes(htmlentities(strip_tags($message[4]))),
  MSG      => "",
  REFER    => $msg
  ));

print("<p><hr size=1>");

$form = $tpl->parse(OUT,"form");

echo $form;

// #############################################################################

echo do_footer();
