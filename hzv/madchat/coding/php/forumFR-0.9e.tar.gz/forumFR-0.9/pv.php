<?
/***************************************************************************
                                pv.php
                             -------------------
    last modification    : 21/11/2002
    email                : stick@newffr.org

 ***************************************************************************/

/***************************************************************************
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 ***************************************************************************/
include("fonctions.php");
include("conf/auth.php");
include("header.php");

if(!$user_logged_in)
      error_die("Vous devez �tre logu�");


if($userdata[user_newpv]){
     $query = "UPDATE users SET user_newpv=0 WHERE user_id=$userdata[user_id]";
     if(!mysql_query($query,$db)) error_die("Mise � jour impossible");
     $userdata[user_newpv] = 0;
}

switch($mode){
    case "del":
          $Pv_msg = new Pv_msg($userdata[user_id]);
          $Pv_msg->del($del);

    break;
    case "save":

          $post_text = strip_tags($post_text);
          $post_text = str_replace("\n","<BR>",$post_text) ;
          $post_text = bbencode($post_text);
          $post_text = make_clickable($post_text);
          $post_text = smile($post_text);
          //$n_texte = addslashes(nl2br($n_texte));
          $time = mktime();

          $query = "SELECT user_id FROM users WHERE username=\"".addslashes($n_dest)."\"";
          if(!$result=mysql_query($query,$db)) error_die("Requ�te incorrecte");
          if(!$to_userid = mysql_result($result,0)) error_die("Impossible de r�cup�rer le destinataire");

          $Pv_msg = new Pv_msg($userdata[user_id]);
          $Pv_msg->sendpmsg($userdata[user_id],$to_userid,$time,$post_text,$db);

}

if($send){
        //recup du nom du destinataire
    settype($msg_id,"integer");
    settype($quote,"integer");
    if($msg_id || $quote){
              $msg_id = ($quote)? $quote : $msg_id;
          $Pv_msg = new Pv_msg($userdata[user_id]);
          $replyto = $Pv_msg->readpmsg($msg_id);

          $query = "SELECT username FROM users WHERE user_id=".$replyto[POSTER_ID];
          $from_username = mysql_result(mysql_query($query,$db),0);

          if($quote){
                     $replyto[MSG_TIME] = date("d-m-Y � H:i",$replyto[MSG_TIME]);
             $text = desmile($replyto[TEXT]);
             $text = str_replace("<BR>", "", $text);
             $text = stripslashes($text);
             $text = bbdecode($text);
             $text = undo_make_clickable($text);
             $text = str_replace("[addsig]", "", $text);

             $quotetxt = "";
                         $quotetxt = "[quote]\n".
                         "Le $replyto[MSG_TIME], $from_username a �crit :\n".
                         "___________________________________________________\n".
                         $text.
                         "\n[/quote]\n";
                  }
    }


?>
<form action=<?=$PHP_SELF?> method=post name=form_reply>
<input type=hidden name=sess_id value=<?=$sess_id?>>
<input type=hidden name=ln value=<?=$ln?>>
<input type=hidden name=mode value=save>
<table width=95% align=center class=texte bgcolor=#<?=$theme[table_liserai]?> cellspacing="<?=$theme[cellspacing]?>" cellpadding="<?=$theme[cellpadding]?>">
  <tr>
    <td colspan="2" class=titrecadre>Envoyer un Message Priv�</td>
  </tr>
  <tr>
    <td class=texte bgcolor=#<?=$theme[color1]?>><b>Destinataire :</b></td>
    <td class=texte bgcolor=#<?=$theme[color2]?>>
       <?if($msg_id)
            echo "<input type=hidden name=n_dest value=\"$from_username\">$from_username";
         else
            echo "<input type=text name=n_dest>";
       ?>
    </td>
  </tr>
  <tr>
    <td class=texte valign="top" bgcolor=#<?=$theme[color1]?>>
      <b>Message :</b>
         <br><br><br><br><br>
         <div align=center>
         <?=bbcode_javascript()/* affichage des bouton BBcode */?>
         </div>
    </td>
    <td bgcolor=#<?=$theme[color2]?>>
       <table width=100%>
         <tr>
            <td><textarea name="post_text" cols="60" rows="20"><?=$quotetxt?></textarea>
            </td>
            <td><?=smiley_javascript(5,$config[smiles_url],$db)?></td>
         </tr>
       </table>
    </td>
  </tr>
  <tr align="center">
    <td colspan="2" bgcolor=#<?=$theme[color1]?>>
      <input type="submit" name="Submit" value="                Envoyer                " class=button>
    </td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
</table>
<?

}else{

$Pv_msg = new Pv_msg($userdata[user_id]);
$allmsgs = $Pv_msg->readpmsg();

$msgs_poster = $allmsgs[POSTERS_ID];
$allmsgs[POSTERS_ID] = "";

if(count($msgs_poster)){
       //recup des infos sur les users du topic
       $query = "SELECT * FROM users WHERE user_id=";
       $msgs_poster = @array_keys($msgs_poster);
       $msgs_poster = @implode(" OR user_id=",$msgs_poster);
       $query .= $msgs_poster;
       unset($msgs_poster);
       if(!$result = mysql_query($query, $db))
           error_die("R�cup des infos des contacts impossible");
       while($row=mysql_fetch_array($result)){
             $posterdata[$row[user_id]] = $row;
       }
}

?>
<p align=center><a href=<?="$PHP_SELF?$sess_link&send=1"?> class=texte>Envoyer un message
  priv�</a> - <a href=# class=texte onclick="document.form_pv.submit()">Supprimer les messages</a></p>


<form action=<?=$PHP_SELF?> method=post name=form_pv>
<input type=hidden name=sess_id value=<?=$sess_id?>>
<input type=hidden name=ln value=<?=$ln?>>
<input type=hidden name=mode value=del>
<table width=95% align=center class=texte bgcolor=#<?=$theme[table_liserai]?> cellspacing="<?=$theme[cellspacing]?>" cellpadding="<?=$theme[cellpadding]?>">
  <tr>
     <td colspan=2 align=center class=titrecadre>Messages priv�s</td>
  </tr>
  <tr bgcolor=#<?=$theme[color2]?>>
    <td class=titre><b>Exp&eacute;diteur</b></td>
    <td class=titre align=center><b>Message</b></td>
  </tr>
<?
     $i=0;
     if(!count($allmsgs[MSGS])){
?>
     <tr bgcolor=#<?=$theme[color1]?>>
       <td align=center class=texte colspan=2>
            Vous n'avez pas de messages
       </td>
     </tr>
<?
     }else{
           while (list($key,$msg)=each($allmsgs[MSGS])) {
                  $message = stripslashes($msg[TEXT]);
                  $message = eregi_replace("class=message", "", $message);
                  $message = eregi_replace("<a href=", "<a class=texte href=", $message);


?>
  <tr bgcolor=#<?=($i%2==0)? $theme[color1] : $theme[color2] ?>>
    <td valign=top class=texte>
         <?=$posterdata[$msg[POSTER_ID]][username]?><br><br><br>
         <input type=checkbox name=del[<?=$msg[MSG_ID]?>] value=1> <span class=minitexte>Supprimer</span>
    </td>
    <td valign=top class=texte>
           <span class=minitexte>post� le : <?=date("d-m-Y H:i",$msg[MSG_TIME])?></span>
           <hr>
           <?=$message?>
           <hr>
            <a href=<?="$PHP_SELF?$sess_link&ln=$ln&send=1&msg_id=$msg[MSG_ID]"?> class=minitexte>R�pondre</a>
           | <a href=<?="$PHP_SELF?$sess_link&ln=$ln&send=1&quote=$msg[MSG_ID]"?> class=minitexte>quote</a>
           | <a href=<?="$PHP_SELF?$sess_link&ln=$ln&mode=del&del[$msg[MSG_ID]]=1"?> class=minitexte>Supprimer</a>
    </td>
  </tr>
<?
                  $i++;
           }
     }
?>
</table>
</form>
<p>&nbsp; </p>
<?
}

include("tail.php");

?>
