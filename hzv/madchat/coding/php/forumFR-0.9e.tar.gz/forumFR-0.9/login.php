<?
/***************************************************************************
                                login.php
                             -------------------
    last modification    : 21/11/2002
    email                : stick@newffr.org

 ***************************************************************************/

/***************************************************************************
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 ***************************************************************************/

include("fonctions.php");
include("conf/auth.php");
include("header.php");


//traitement
if($submit){
      if($lost_pwd && !$pass){
             $chars = array(
                  "a","A","b","B","c","C","d","D","e","E","f","F","g","G","h","H","i","I","j","J",
                  "k","K","l","L","m","M","n","N","o","O","p","P","q","Q","r","R","s","S","t","T",
                  "u","U","v","V","w","W","x","X","y","Y","z","Z","1","2","3","4","5","6","7","8",
                  "9","0"
                  );
             $max_elements = count($chars) - 1;
             srand((double)microtime()*1000000);
             $newpw = $chars[rand(0,$max_elements)];
             $newpw .= $chars[rand(0,$max_elements)];
             $newpw .= $chars[rand(0,$max_elements)];
             $newpw .= $chars[rand(0,$max_elements)];
             $newpw .= $chars[rand(0,$max_elements)];
             $newpw .= $chars[rand(0,$max_elements)];
             $newpw .= $chars[rand(0,$max_elements)];
             $newpw .= $chars[rand(0,$max_elements)];
             $newpw_enc = md5($newpw);

             $query = "UPDATE users SET user_password='$newpw_enc' WHERE username = \"".addslashes($login)."\"";
             if(!$result = mysql_query($query,$db)) error_die("Impossible d'interroger la bdd");

             $query = "SELECT user_email FROM users WHERE username = \"".addslashes($login)."\"";
             if(!$result = mysql_query($query,$db)) error_die("Impossible d'interroger la bdd");
             if(mysql_num_rows($result)!=1) error_die("Utilisateur inexistant");
             $user_mail = mysql_result($result,0);

             $mail_body =
             "Bonjours,\n\n".
             "Voici vos login et password :\n".
             "Login : ".addslashes($login)."\n".
             "Password : $newpw\n\n\n".
             "A bientot sur le forum http://$config[site_name] :)";

             $mail_dest = $user_mail;
             $mail_subjet = "login/password $site_name";
             $mail_header = "Content-type: text/text\n".
                            "From: stick@newffr.org\n";

             if(!mail($mail_dest, $mail_subjet, $mail_body, $mail_header)) error_die("Impossible d'envoyer le mail");
             error_die("Vos nouveaux login/password viennent d'�tre envoy�s, vous les recevrez d'ici 5 minutes<br><br>
                        <a href=index.php?$sess_link class=texte>Cliquez ici pour retourner � l'index</a>");
      }

      if(!$login || !$pass)
            error_die("formulaire incomplet");

      $query = "SELECT * FROM users WHERE username=\"".addslashes($login)."\"";
      if(!$result = mysql_query($query,$db)) error_die("Impossible d'interroger la bdd");
      if(!$userdata = @mysql_fetch_array($result)) error_die("Ce pseudo n'existe pas<br><br><a href=register.php?$sess_link class=texte>Cliquez ici pour vous enregistrer</a>");
      if(!$md5_pass = $userdata[user_password])
           die("Mot de passe incorrect<br><br><a href=register.php?$sess_link class=texte>Cliquez ici pour vous enregistrer</a><br><br><a href=index.php?$sess_link class=texte>Cliquez ici pour retourner � l'index</a>");

      if(md5($pass) != $md5_pass)
            error_die("Mot de passe incorrect");

      $user_logged_in = 1;
      session_register("user_logged_in");

      session_register("userdata");

      //requete un peu batarde, updater sess_id alors qu'on se base dessus dans le where, mais ca permet, a l'affichage, de supprimer les doublon sans requete sup
      $query = "UPDATE whosonline SET username=\"$userdata[username]\", user_id=$userdata[user_id], timestamp=".mktime().", sess_id='$sess_id' WHERE sess_id='$sess_id' OR username='$userdata[username]'";
      if(!mysql_query($query,$db)) error_die("Ecriture whos_online impossible (5)");

      echo "<script>window.location='$config[site_host]$config[site_url]/?sess_id=$sess_id'</script>";

}elseif($logout){

      $query = "DELETE FROM whosonline WHERE sess_id='$sess_id' OR username='$userdata[username]'";
      if(!mysql_query($query,$db)) error_die("Purge whosonline impossible");

      session_destroy();

      header("Location: $config[site_host]$config[site_url]\n");

}

?>

<form method="post" action=login.php>
  <input type="hidden" name="sess_id" value="<?=$sess_id?>">
<br>
<table width=50% align=center class=texte bgcolor=#<?=$theme[table_liserai]?> cellspacing="<?=$theme[cellspacing]?>" cellpadding="<?=$theme[cellpadding]?>">
  <tr>
    <td colspan=2 align=center>Login</td>
  </tr>
  <tr>
    <td align=right bgcolor=#<?=$theme[color1]?> class=texte>Login : </td>
    <td bgcolor=#<?=$theme[color1]?> class=texte><input type="text" name="login"></td>
  </tr>
  <tr>
    <td align=right bgcolor=#<?=$theme[color1]?> class=texte>Password : </td>
    <td bgcolor=#<?=$theme[color1]?> class=texte><input type="password" name="pass"></td>
  </tr>
  <tr>
    <td bgcolor=#<?=$theme[color1]?> colspan=2 class=minitexte><br>Mot de passe perdu ? cochez cette case et tapez votre pseudo,
         un nouveau password vous sera envoy� � l'adresse indiqu�e lors de l'inscription.
         <input type=checkbox name=lost_pwd value=1>
    </td>
  </tr>
  <tr>
    <td bgcolor=#<?=$theme[color1]?> align=center colspan=2>
    <br><br>
    <input type="submit" name="submit" value="Envoyer" class=button>
    </td>
  </tr>
</table>
</form>
