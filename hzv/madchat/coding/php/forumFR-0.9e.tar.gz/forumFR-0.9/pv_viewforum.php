<?
/***************************************************************************
                                pv_viewforum.php
                             -------------------
    last modification    : 21/11/2002
    email                : stick@newffr.org

 ***************************************************************************/

/***************************************************************************
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 ***************************************************************************/

include("fonctions.php");
include("conf/auth.php");
include("header.php");


settype($forum,"integer");
settype($start,"integer");


if(!$user_logged_in)
      error_die("Vous devez �tre logu�");


if($userdata[user_level]<2) exit();


$query = "SELECT forum_name, forum_id, forum_type, forum_topics FROM forums WHERE forum_id=$forum";
if(!$result = mysql_query($query,$db)) error_die("recup des infos du forum impossible");
$forum_infos = mysql_fetch_array($result);


//recup des topics a afficher
$query = "SELECT * FROM topics WHERE forum_id=$forum ORDER BY topic_sticky DESC, topic_last_post_time DESC LIMIT $start,$config[topic_par_page]";
if(!$result = mysql_query($query,$db)) error_die("recup des topics impossibles");
while($row = mysql_fetch_array($result)){
       $alltopics[] = $row;
       $topics_users[$row[topic_poster]] = 1;
}
$topics_users = array_keys($topics_users);


//recup des infos sur les user concern� par l'affichage
$query = "SELECT username,user_id FROM users WHERE user_id=".implode(" OR user_id=",$topics_users);
if(!$result = mysql_query($query,$db)) error_die("recup des username impossible");
while($row = mysql_fetch_array($result))
      $topics_users[$row[user_id]] = $row[username];
?>
<table width=95% align=center class=texte bgcolor=#<?=$theme[table_liserai]?> cellspacing="<?=$theme[cellspacing]?>" cellpadding="<?=$theme[cellpadding]?>">
   <tr class=titrecadre>
      <td><b><?=$forum_infos[forum_name]?></b></td>
      <td colspan=4 class=texte align=right>
         <a href=newtopic.php?<?=$sess_link?>&forum=<?=$forum?> class=texte><b>Newtopic</b></a>
      </td>
   </tr>
   <tr bgcolor=#<?=$theme[table_titre]?> align=center class=titre>
      <td align=left>Titre</td>
      <td>replies</td>
      <td>view</td>

      <td>initiateur</td>
      <td>dernier post</td>
   </tr>
<?
$i=0;
while(list($key,$row)=each($alltopics)){
       //creation de la navigation
       if($row[topic_replies]>$config[post_par_page]){
          $nbpage = ceil($row[topic_replies]/$config[post_par_page]) ;
          $navigation = "<span class=minitexte>";
          for($z=0;$z<$nbpage;$z++){
              $navigation .= "<a href='pv_viewtopic.php?$sess_link&forum=$forum&topic=$row[topic_id]&start=".($config[post_par_page]*$z)."' class=minitexte>".($z+1)."</a>";
              $navigation .= ($z+1<$nbpage)? " | " : "";
          }
          $navigation .= "</span>\n";
       }




      ?>
        <tr bgcolor=#<?=$theme[color1]?>>
         <td>
           <a href=pv_viewtopic.php?<?=$sess_link?>&forum=<?=$forum?>&topic=<?=$row[topic_id]?> class=texte><?=($row[topic_sticky])? "[Annonce]" : "" ?> <?=stripslashes($row[topic_title])?></a>
           <?=($row[topic_replies]>$config[post_par_page])? "( $navigation )" : "" ?>
         </td>
         <td align=center bgcolor=#<?=$theme[color2]?>><?=$row[topic_replies]?></td>
         <td align=center bgcolor=#<?=$theme[color2]?>><?=$row[topic_views]?></td>
         <td align=center><a href=profil.php?<?$sess_link?>&mode=voir&user_id=<?=$row[topic_poster]?> class=minitexte><?=$topics_users[$row[topic_poster]]?></a></td>
         <td class=<?=($row[topic_last_post_time]>$user_session_start)? "newpv" : "minitexte" ?> align=center bgcolor=#<?=$theme[color2]?>><?=date("d-m-Y H:i",$row[topic_last_post_time])."<br>".$row[topic_last_poster]?></td>
      </tr>
      <?
      $i++;
}


//creation de la navigation
if($forum_infos[forum_topics]>$config[topic_par_page]){
    $nbpage = ceil($forum_infos[forum_topics]/$config[topic_par_page]) ;
    $navigation = "<span class=minitexte>";
    for($z=0;$z<$nbpage;$z++){
       $navigation .= ($config[topic_par_page]*$z!=$start)? "<a href='pv_viewforum.php?$sess_link&forum=$forum&start=".($config[topic_par_page]*$z)."' class=minitexte>" : "" ;
       $navigation .= $z+1;
       $navigation .= ($config[topic_par_page]*$z!=$start)? "</a> | " : " | ";
    }
    $navigation .= ($start+$config[topic_par_page]<$forum_infos[forum_topics])? "<a href='pv_viewforum.php?$sess_link&forum=$forum&start=".($start+$config[topic_par_page])."' class=minitexte>Page suivante</a>" : "" ;
    $navigation .= "</span>\n";
}

?>
   <tr>
      <td colspan=5>
         <table width=100% class=titrecadre>
            <tr>
              <td width=25%>
                 <a href=newtopic.php?forum=<?=$forum?> class=texte><b>Newtopic</b></a>
              </td>
              <td align=right>
                 <?=$navigation?>
              </td>
            </tr>
         </table>
      </td>
   </tr>
</table>

<?



include("tail.php");
?>
