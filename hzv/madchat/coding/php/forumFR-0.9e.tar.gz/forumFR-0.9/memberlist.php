<?
/***************************************************************************
                                memberlist.php
                             -------------------
    last modification    : 21/11/2002
    email                : borax@newffr.org

 ***************************************************************************/

/***************************************************************************
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 ***************************************************************************/

include("fonctions.php");
include("conf/auth.php");
include("header.php");


settype($user_id, "integer");
settype($user_level, "integer");
settype($user_uin, "integer");
settype($user_posts, "integer");
settype($inverser, "integer");
settype($methode, "integer");
settype($nombre, "integer");
settype($debut, "integer");
settype($fin, "integer");

$inverser=($inverser)? 1 : 0;

$nombre=60;
$debut = ($debut)? $debut : 0;
$classement = array(1=>"username", 2=>"user_email", 3=>"user_from", 4=>"user_timestamp");

$methode=($methode)? $methode : 1;
$sens=($inverser==1)? "DESC" : "ASC";

$sql="SELECT * FROM users WHERE 1 ORDER BY $classement[$methode] $sens LIMIT $debut, $nombre";
      if(!$result=mysql_query($sql, $db)) error_die("Impossible d'executer la requete $sql");


$count_sql = "SELECT COUNT(*) FROM users WHERE 1";
              if(!$result_count = mysql_query($count_sql,$db)) error_die("Impossible d'interroger la bdd");
              if(!$count = mysql_result($result_count,0)) error_die("Aucun enregistrement disponible");



if($count>$nombre){
    $nbpage = ceil($count/$nombre) ;
    $navigation = "<span class=minitexte>";
    for($z=0;$z<$nbpage;$z++){
       $navigation .= ($nombre*$z!=$debut)? "<a href='$_PHP_SELF?$sess_link&debut=".($nombre*$z)."&methode=$methode' class=minitexte>" : "" ;
       $navigation .= $z+1;
       $navigation .= ($nombre*$z!=$debut)? "</a> | " : " | ";
       $navigation .= ($z%20==0)? "<br>" : "" ;
    }
    $navigation .= ($debut+$nombre<$count)? "<br><a href='$_PHP_SELF?$sess_link&debut=".($nombre+$debut)."&methode=$methode' class=minitexte>Page suivante</a>" : "" ;
    $navigation .= "</span>\n";
}

$macouille = explode(" ",microtime());
$macouille = $macouille[0] + $macouille[1];
//$query = "SELECT username, user_id FROM users WHERE user_id=MAX(user_id)";
$query = "SELECT username, user_id FROM users ORDER BY user_timestamp DESC LIMIT 0,1";
if(!$membres_info = mysql_query($query,$db)) error_die("Recup des infos membres impossible");
$membres_info = mysql_fetch_array($membres_info);
$apresmacouille = explode(" ",microtime());
$apresmacouille = $apresmacouille[0] + $apresmacouille[1];
$lerestedecouille = $apresmacouille-$macouille;
echo "<font color=black>requete execut�e en $lerestedecouille sec</font>";
?>
<table width=85% align=center class=minitexte  cellspacing="0" cellpadding="0">
     <tr>
         <td nowrap>
            Nombre de membres : <?=$count?><br>
            Dernier membre inscrit : <a href=profil.php?<?=$sess_link?>&mode=voir&user_id=<?=$membres_info[user_id]?> class=minitexte><?=$membres_info[username]?></a>
         </td>
         <td align=right>
            <?=$navigation?>
         </td>
     </tr>
</table>

<?

$inverser=($inverser==1)? 0 : 1;
?>
<table width=95% align=center class=texte bgcolor=#<?=$theme[table_liserai]?> cellspacing="<?=$theme[cellspacing]?>" cellpadding="<?=$theme[cellpadding]?>">
        <tr class=texte bgcolor=#<?=$theme[table_liserai]?>>
        <td <? $theme[color1] ?>><a class=texte href=<? echo"$_PHP_SELF?$sess_link&methode=1&debut=$debut&inverser=$inverser"; ?> >Nom:</a></td>
        <td <? $theme[color2] ?>><a class=texte href=<? echo"$_PHP_SELF?$sess_link&methode=4&debut=$debut&inverser=$inverser"; ?> >Date d'enregistrement:</a></td>
        <td <? $theme[color1] ?>><a class=texte href=<? echo"$_PHP_SELF?$sess_link&methode=2&debut=$debut&inverser=$inverser"; ?> >Mail:</a></td>
        <td <? $theme[color1] ?>><a class=texte href=<? echo"$_PHP_SELF?$sess_link&methode=3&debut=$debut&inverser=$inverser"; ?> >De:</a></td>
        </tr>
<?

        while($user=mysql_fetch_array($result))
        {
            $user_id=$user[user_id];
            $user_level=$user[user_level];
            $username=strip_tags(stripslashes($user[username]));
            $user_mail=strip_tags(stripslashes($user[user_email]));
            $user_date=date("d / m / Y",$user[user_timestamp]);
            $user_posts=$user[user_posts];
            $user_from=strip_tags($user[user_from]);

              echo"
              <tr  class=texte>
              <td bgcolor=$theme[color1]><a class=texte href=profil.php?$sess_link&mode=voir&user_id=$user_id>$user[username]</a></td>
              <td bgcolor=$theme[color2]>$user_date</td>
              <td bgcolor=$theme[color1]>".
                    (($user[user_viewemail])? "<a class=texte href = mailto:$user_mail>$user_mail</a>" : "" ).
              "</td>
              <td bgcolor=$theme[color2]>$user_from</td>
              </tr>
                  ";

        }



?>
</table>

<?
echo "<table cellspacing=\"2\">
       <tr>";

       if (($debut - $nombre) >= 0)
            echo"<td align=\"left\" classe=minitexte><a class=minitexte href=$_PHP_SELF?$sess_link&debut=".($debut-$nombre)."&methode=$methode>Page pr�c�dente</a></td>";

       if ($count > ($debut+$nombre))
            echo"<td align=\"right\" class=minitexte><a class=minitexte href=$_PHP_SELF?$sess_link&debut=".($debut+$nombre)."&methode=$methode&methode=$methode>Page suivante</a></td>";

echo " </tr>
      </table>";
?>
