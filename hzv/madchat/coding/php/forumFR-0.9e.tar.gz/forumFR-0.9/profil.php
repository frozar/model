<?
/***************************************************************************
                                fonctions.php
                             -------------------
    last modification    : 21/11/2002
    email                : borax@newffr.org

 ***************************************************************************/

/***************************************************************************
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 ***************************************************************************/


include("fonctions.php");
include("conf/auth.php");
include("header.php");

//on type les variables qui ne doivent pas avoir de char, et on definit le level de l'user afin d'eviter toute fraude.
$user_level=$userdata[user_level];
settype($user_id, "integer");
settype($user_level, "integer");
settype($user_uin, "integer");
settype($user_posts, "integer");

switch($mode)
{
        /**********************Partie privee si l'user veut modifier son profil****************************/


       case 'modif':

            if(!$user_logged_in)
               error_die("Veuillez vous logger pour acceder � cette zone.");

                //si jamais il soumet le formulaire de modification
                 if($submit)
                 {
                //au cas ou les mots de passe ne sont pas rentres comme il faut,
                  if(($password && !$password_bis) || (!$password && $password_bis))
                      error_die("Vous n'avez pas renseign� tous les champs pour le changement de mot de passe.");

                //sinon, on va recuperer le mot de  passer de l'user qui modifie le profil, et on le compare avec le pass rentre dans le form.
                  $query = "SELECT user_password FROM users WHERE user_id=$userdata[user_id]";
                  if(!$result = mysql_query($query,$db))
                      error_die("user inexistant");

                  $password_crypte = mysql_result($result,0);

                  if($password_crypte!=md5($check_password) || !$check_password)
                     error_die("Veuillez entrer votre mot de passe actuel.");


                  settype($user_uin, "integer");

                //on redefinit les variables en fonction de celles rentrees dans le formulaire.
                  $user_mail=addslashes(strip_tags($new_mail));
                  $user_avatar=addslashes(strip_tags($new_avatar));
                  $user_website=addslashes(strip_tags($new_website));
                  $user_aim=addslashes(strip_tags($new_aim));
                  $user_occ=addslashes(strip_tags($new_occ));
                  $user_int=addslashes(strip_tags($new_int));
                  $user_from=addslashes(strip_tags($new_from));
                  $user_msn=addslashes(strip_tags($new_msn));
                  settype($new_viewemail, "integer");
                  settype($new_uin, "integer");
                  settype($new_attachsig, "integer");
                  settype($new_pvsound, "integer");

                  $user_viewemail=$new_viewemail;
                  $user_attachsig=$new_attachsig;
                  $user_pvsound=$new_pvsound;

                  //bbencodage de la signature
                    $user_sig = censor_string($new_sig);
                    $user_sig = bbencode($user_sig);
                    $user_sig = smile($user_sig,$db);
                    $user_sig = make_clickable($user_sig);
                    $user_sig = str_replace("\n","<BR>",$user_sig);
                    $user_sig = addslashes($user_sig);

                //si l'utilisateur a rentre des nouveaux mots de passe pour une modification,
                  if($password && $password_bis)
                  {  //on check si les mots de passe sont les meme.
                     if(md5($password) != md5($password_bis))
                         error_die("Les nouveaux mots de passe ne concordent pas. Veuillez r�essayer.");

                     //si c'est bon, on cree la signature md5 du nouveau mot de passe.
                     $password_crypte=md5($password);
                  }


                //s'il n'y a pas eu de problemes avant, on enregistre les nouvelles infos dans la base.
                  $sql="UPDATE users SET
                            user_password=\"$password_crypte\",
                            user_occ=\"$user_occ\",
                            user_website=\"$user_website\",
                            user_aim=\"$user_aim\",
                            user_icq=\"$new_uin\",
                            user_email=\"$user_mail\",
                            user_viewemail=\"$new_viewemail\",
                            user_sig=\"$user_sig\",
                            user_msnm=\"$user_msn\",
                            user_intrest=\"$user_int\",
                            user_from=\"$user_from\",
                            user_attachsig=\"$new_attachsig\",
                            user_pvsound=\"$new_pvsound\",
                            user_avatar=\"$user_avatar\"
                            WHERE user_id=$userdata[user_id]";

                  if(!$result=mysql_query($sql, $db))
                     error_die("Impossible d'ajouter les infos dans la base.");

                  //on met a jour le userdata
                  $userdata[user_password]=$password_crypte;
                  $userdata[user_occ]=$user_occ;
                  $userdata[user_website]=$user_website;
                  $userdata[user_aim]=$user_aim;
                  $userdata[user_icq]=$new_uin;
                  $userdata[user_email]=$user_mail;
                  $userdata[user_viewemail]=$new_viewemail;
                  $userdata[user_sig]=$user_sig;
                  $userdata[user_msnm]=$user_msn;
                  $userdata[user_intrest]=$user_int;
                  $userdata[user_from]=$user_from;
                  $userdata[user_attachsig]=$new_attachsig;
                  $userdata[user_pvsound]=$new_pvsound;
                  $userdata[user_avatar]=$user_avatar;

                  error_die("Modifications enregistr�es<br><br><a href='$config[site_url]/index.php?$sess_link' class=texte>Cliquez ici retourner � l'index</a>", "Profil");

                 }

                /******************La on affiche le formulaire de modification.**********************/


                //Si jamais on ne peut pas recuperer les infos du membres logg�, on affiche une erreur.
               $sql="SELECT * FROM users WHERE user_id=$userdata[user_id]";
               if(!$result=mysql_query($sql,$db))
                   error_die("Impossible d'acceder � la base pour la requ�te.");

               if(!$user=mysql_fetch_array($result))
                   error_die("Impossible d'afficher les infos pour ce membre.");

                //On definit les variables en fonction de ce qu'ona dans la base.
               $user_level=$user[user_level];
               $username=$user[username];
               $user_mail=stripslashes($user[user_email]);
               $user_avatar=$user[user_avatar];
               $user_date=date("d / m / Y",$user[user_timestamp]);
               $user_uin=$user[user_icq];
               $user_website=addslashes($user[user_website]);
               $user_aim=stripslashes($user[user_aim]);
               $user_occ=stripslashes($user[user_occ]);
               $user_int=stripslashes($user[user_intrest]);
               $user_from=stripslashes($user[user_from]);
               $user_msn=stripslashes($user[user_msnm]);
               $user_posts=$user[user_posts];
               $user_sig=stripslashes($user[user_sig]);

               $user_sig = str_replace("<BR>", "", $user_sig);
               $user_sig = stripslashes($user_sig);
               $user_sig = desmile($user_sig);
               $user_sig = bbdecode($user_sig);
               $user_sig = undo_make_clickable($user_sig);

               //Pour activer le checked au niveau des radio du form. Cf.  plus bas.
               $check_view_email=($user[user_viewemail]=="1")? "checked": "";
               $non_check_view_email=($user[user_viewemail]=="0")? "checked": "";

               $check_attachsig=($user[user_attachsig]=="1")? "checked": "";
               $non_check_attachsig=($user[user_attachsig]=="0")? "checked": "";

               $check_pvsound=($user[user_pvsound]=="1")? "checked": "";
               $non_check_pvsound=($user[user_pvsound]=="0")? "checked": "";

                //le form en lui m�me
               echo"
               <form method=post>

               <input type=\"HIDDEN\" name=sess_id VALUE=\"$sess_id\">

               <TABLE width=95% align=center class=texte bgcolor=\"$theme[table_liserai]\" cellspacing=\"$theme[cellspacing]\" cellpadding=\"$theme[cellpadding]\">
                      <tr>
                      <td colspan=3 class=titrecadre>Profil:</td>
                      </tr>

                      <tr>
                      <td bgcolor=$theme[color1]>Pseudonyme:</td>
                      <td bgcolor=$theme[color1] colspan=2>$username</td>
                      </tr>

                      <tr>
                      <td bgcolor=$theme[color2]>Mot de passe actuel:</td>
                      <td bgcolor=$theme[color2] colspan=2><input TYPE=\"password\" SIZE=\"8\" name=check_password VALUE=\"\"></td>
                      </tr>

                      <tr>
                      <td bgcolor=$theme[color1]>Nouveau mot de passe:</td>
                      <td bgcolor=$theme[color1] colspan=2><input TYPE=\"password\" SIZE=\"8\" name=password VALUE=\"\"></td>
                      </tr>

                      <tr>
                      <td bgcolor=$theme[color2]>Confirmer nouveau mot de passe:</td>
                      <td bgcolor=$theme[color2] colspan=2><input TYPE=\"password\" SIZE=\"8\" name=password_bis VALUE=\"\"></td>
                      </tr>

                      <tr>
                      <td bgcolor=$theme[color1]>E-Mail:</td>
                      <td bgcolor=$theme[color1] colspan=2><input TYPE=\"TEXT\" SIZE=\"40\" name=new_mail VALUE=\"$user_mail\"></td>
                      </tr>

                      <tr>
                      <td bgcolor=$theme[color2]>UIN (ICQ):</td>
                      <td bgcolor=$theme[color2] colspan=2><input TYPE=\"TEXT\" SIZE=\"40\" name=new_uin VALUE=\"$user_uin\"></td>
                      </tr>

                      <tr>
                      <td bgcolor=$theme[color1]>AIM:</td>
                      <td bgcolor=$theme[color1] colspan=2><input TYPE=\"TEXT\" SIZE=\"40\" name=new_aim VALUE=\"$user_aim\"></td>
                      </tr>

                      <tr>
                      <td bgcolor=$theme[color2]>MSN:</td>
                      <td bgcolor=$theme[color2] colspan=2><input TYPE=\"TEXT\" SIZE=\"40\" name=new_msn VALUE=\"$user_msn\"></td>
                      </tr>

                      <tr>
                      <td bgcolor=$theme[color1]>Site Web:</td>
                      <td bgcolor=$theme[color1] colspan=2><input TYPE=\"TEXT\" SIZE=\"40\" name=new_website VALUE=\"$user_website\"></td>
                      </tr>

                      <tr>
                      <td bgcolor=$theme[color2]>De:</td>
                      <td bgcolor=$theme[color2] colspan=2><input TYPE=\"TEXT\" SIZE=\"40\" name=new_from VALUE=\"$user_from\"></td>
                      </tr>

                      <tr>
                      <td bgcolor=$theme[color1]>Occupation:</td>
                      <td bgcolor=$theme[color1] colspan=2><input TYPE=\"TEXT\" SIZE=\"40\" name=new_occ VALUE=\"$user_occ\"></td>
                      </tr>

                      <tr>
                      <td bgcolor=$theme[color2]>Interets personnels:</td>
                      <td bgcolor=$theme[color2] colspan=2><input TYPE=\"TEXT\" SIZE=\"40\" name=new_int VALUE=\"$user_int\"></td>
                      </tr>

                      <tr>
                      <td bgcolor=$theme[color1]>Signature:</td>
                      <td bgcolor=$theme[color1] colspan=2><input type=texte size=40 name=new_sig VALUE=\"$user_sig\"></td>
                      </tr>

                      <tr>
                        <td bgcolor=$theme[color2]>Avatar:</td>
                        <td bgcolor=$theme[color2] colspan=2><INPUT TYPE=\"TEXT\" size=40 name=new_avatar VALUE=\"$user_avatar\"></td>
                      </tr>

                      <tr>
                      <td bgcolor=$theme[color1]>Laisse les membres voir votre E-mail:</td>
                      <td bgcolor=$theme[color1]><input type=radio name=new_viewemail value=1 $check_view_email>Oui</td>
                      <td bgcolor=$theme[color1]><input type=radio name=new_viewemail value=0 $non_check_view_email>Non</td>
                      </tr>

                      <tr>
                      <TD bgcolor=$theme[color2]>Utiliser un son pour signaler les pv</TD>
                      <td bgcolor=$theme[color2]><input type=radio name=new_pvsound value=1 $check_pvsound>Oui</td>
                      <td bgcolor=$theme[color2]><input type=radio name=new_pvsound value=0 $non_check_pvsound>Non</td>
                      </tr>

                      <tr>
                      <td bgcolor=$theme[color1]>Afficher votre signature dans les posts:</td>
                      <td bgcolor=$theme[color1]><input type=radio name=new_attachsig value=1 $check_attachsig>Oui</td>
                      <td bgcolor=$theme[color1]><input type=radio name=new_attachsig value=0 $non_check_attachsig>Non</td>
                      </tr>

                      <br>

                      <tr>
                      <td align=center colspan=3><INPUT TYPE=\"submit\" name=\"submit\" VALUE=\"Modifier votre profil.\"></td>
                      </tr>

                    </table>
                    </form>

                    ";

         break;



        /***************************Partie publique qui affichera le profil du membre*******************/

         case 'voir':

                //On va chercher les infos du membre.
               $sql="SELECT * FROM users WHERE user_id=$user_id";

               if(!$result = mysql_query($sql, $db))
                   error_die("Hummmm... Pas possible de chopper la base des users.");

               if(!$user=mysql_fetch_array($result))
                   error_die("Impossible d'afficher les infos pour ce membre.");

               $user_level=$user[user_level];
               $username=stripslashes($user[username]);
               $user_mail=strip_tags(stripslashes($user[user_email]));
               $user_avatar=strip_tags($user[user_avatar]);
               $user_date=date("d / m / Y",$user[user_timestamp]);
               $user_uin=$user[user_icq];
               $user_website=strip_tags(addslashes($user[user_website]));
               $user_aim=strip_tags(stripslashes($user[user_aim]));
               $user_occ=strip_tags(stripslashes($user[user_occ]));
               $user_int=strip_tags(stripslashes($user[user_intrest]));
               $user_from=strip_tags(stripslashes($user[user_from]));
               $user_msn=strip_tags(stripslashes($user[user_msnm]));
               $user_posts=$user[user_posts];


            //On definit des rangs en fonction du level de l'user.
        $array_rank = array(1 => "Membre",
                             2 => "Mod�rateur",
                             3 => "Super-Mod�rateur",
                             4 => "Administrateur"
                             );
        $user_rank = $array_rank[$user_level];

        //On affiche le tableau avec les infos du membre.
?>
                     <center>
                     <table width=95% align=center class=texte bgcolor=#<?=$theme[table_liserai]?> cellspacing="<?=$theme[cellspacing]?>" cellpadding="<?=$theme[cellpadding]?>">

                     <tr>
                     <td colspan=2 class=titrecadre>Profil:</td>
                     </tr>

                     <tr><td bgcolor=#<?=$theme[color1]?>>Pseudonyme: </td><td bgcolor=#<?=$theme[color2]?>><? echo $username; ?></td></tr>


                     <tr><td bgcolor=#<?=$theme[color1]?>>Date d'inscription: </td><td bgcolor=#<?=$theme[color2]?>><? echo $user_date; ?></td></tr>


        <? if($user[user_viewemail]=="1" || $userdata[user_level]=="4")
        {
                  echo "<tr><td  bgcolor=$theme[color1]>E-mail: </td><td bgcolor=$theme[color2]><a class=texte href=mailto:$user_mail>$user_mail</a></td></tr>";
                } ?>

                </center>


        <? if($user_from)
                     echo"
                     <tr><td bgcolor=$theme[color1]>De: </td><td bgcolor=$theme[color2]>$user_from</td></tr>
                         "; ?>



                     <? if($user_uin)
                     echo"
                     <tr><td bgcolor=$theme[color1]>UIN (ICQ): </td><td bgcolor=$theme[color2]>$user_uin</td></tr>
                         "; ?>

                     <? if($user_aim)
                     echo"
                     <tr><td bgcolor=$theme[color1]>AIM: </td><td bgcolor=$theme[color2]>$user_aim</td></tr>
                         "; ?>

                     <? if($user_msn)
                     echo"
                     <tr><td bgcolor=$theme[color1]>MSN: </td><td bgcolor=$theme[color2]>$user_msn</td></tr>
                         "; ?>

                     <? if($user_occ)
                     echo"
                     <tr><td bgcolor=$theme[color1]>Occupation: </td><td bgcolor=$theme[color2]>$user_occ</td></tr>
                         "; ?>

                     <? if($user_int)
                     echo"
                     <tr><td bgcolor=$theme[color1]>Inter�ts: </td><td bgcolor=$theme[color2]>$user_int</td></tr>
                         "; ?>

                     <? if($user_website)
                     echo"
                     <tr><td bgcolor=$theme[color1]>Site Web: </td><td bgcolor=$theme[color2]>$user_website</td></tr>
                         "; ?>

                     <tr><td bgcolor=#<?=$theme[color1]?>>Rank: </td><td bgcolor=#<?=$theme[color2]?>><? echo $user_rank; ?></td></tr>

                     <? if($user_avatar)
                     echo"
                     <tr><td bgcolor=$theme[color1]>Avatar: </td><td bgcolor=$theme[color2]>$user_avatar</td></tr>
                         "; ?>
                     </table>

                     <br>
                <? if($userdata[user_level=="4"])
            echo "<table><tr><td><a class=texte href=admin/user.php?$sess_link&user_id=$user_id&modif=Modifier>Modifier le membre / </a></td><td>"; ?>

             <center>
                     <a href=index.php class=texte>Retour � l'index</a>
                     </center>

<?        if($userdata[user_level]=="4")
        echo"</td></tr></table>";
         break;


}

?>
