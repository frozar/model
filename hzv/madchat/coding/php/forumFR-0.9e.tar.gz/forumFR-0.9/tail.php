<?
/***************************************************************************
                                tail.php
                             -------------------
    last modification    : 21/11/2002
    email                : stick@newffr.org

 ***************************************************************************/

/***************************************************************************
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 ***************************************************************************/
if(ereg("tail\.php",$_SERVER["REQUEST_URI"]))
      exit();


if($userdata[user_level]>3){
     echo "<br><div align=center><a href=$config[site_url]/admin/?$sess_link class=texte>Panneau d'admin</a></div>";
}

$query = "SELECT DISTINCT sess_id,username,user_id FROM whosonline";
if(!$result = mysql_query($query,$db)) error_die("recup whosonline impossible");
?>
<br>
<table width=95% align=center class=texte bgcolor=#<?=$theme[table_liserai]?> cellspacing="<?=$theme[cellspacing]?>" cellpadding="<?=$theme[cellpadding]?>">
  <tr>
    <td bgcolor=#<?=$theme[color1]?> class=minitexte>
     Online :
<?
//definition du whosonline
while($row = mysql_fetch_array($result)){
       if($row[user_id])
            $online_user[] = "<a href=profil.php?$sess_link&mode=voir&user_id=$row[user_id] class=minitexte>$row[username]</a>";
       else
            $online_guest++;
}
if(!count($online_user) && !$online_guest) echo "degun..";
else{
    echo @implode(", ",$online_user);
    echo (count($online_user) && $online_guest)? " et " : "" ;
    echo ($online_guest)? "$online_guest Guest".(($online_guest>1)? "s" : "") : "" ;
}

mysql_close($db);

$END_TIME = explode(" ",microtime());
$END_TIME = $END_TIME[0] + $END_TIME[1];
$TIME = $END_TIME-$START_TIME;

?>
    </td>
  </tr>
</table>

<br><br>
<table width=95% align=center class=minitexte>
    <tr>
       <td><a href="<?=$config[site_url]?>" class=minitexte>Retour Index</a></td>
       <td align=center>
Forum Sql/Xml - 2002 <a href=http://newffr.org class=minitexte>Newffr.org</a><br>
Pour toute plainte ou probl�me, contacter l'<a href=mailto:<?=$config[admin_mail]?> class=minitexte>administrateur</a>
       </td>
       <td align=right><a href=#hautdepage class=minitexte>Retour haut de page</a></td>
    </tr>
</table>
<span style="color:black;font-size:9px"><?=$TIME?> sec.</span>
