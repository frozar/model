<?
/***************************************************************************
                                register.php
                             -------------------
    last modification    : 21/11/2002
    email                : stick@newffr.org

 ***************************************************************************/

/***************************************************************************
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 ***************************************************************************/

include("fonctions.php");
include("conf/auth.php");
include("header.php");




if($submit){
      if(!$login) error_die("Veuillez indiquez un nom d'utilisateur");
      if(!$pass || !$repass) error_die("Veuillez donner un mot de passe");
      if($pass != $repass) error_die("Mot de passe incorrect");
      if(!$email) error_die("Veuillez indiquer une adresse email,<br> apr�s inscription un mail vous sera envoy� pour vous rappeler vos identifiants");
      if(!ereg("^.+@.+\.[a-zA-Z0-9]+$",$email)) error_die("Veuillez indiquer une adresse email valide,<br> apr�s inscription un mail vous sera envoy� pour vous rappeler vos identifiants");


      $login = trim(strip_tags($login));
      $pass = md5($pass);

      while(list($key,$val)=@each($config[disallow_username])){
            if($val==$login) error_die("Ce nom d'utilisateur est interdit par l'administrateur");
      }
      $login = addslashes($login);
      $query = "SELECT user_id FROM users WHERE username = '$login'";
      if(!$result = mysql_query($query,$db)) error_die("Pseudo deja utilis�");
      if(@mysql_result($result,0)) error_die("Pseudo deja utilis�");


      $email = addslashes($email);
      $website = strip_tags($website);
      $website = (ereg("^http://",$website))? $website : "http://".$website ;
      $website = addslashes($website);
      settype($icq,"integer");
      $aim = addslashes(strip_tags($aim));
      $msn = addslashes(strip_tags($msn));
      $yahoo = addslashes(strip_tags($yahoo));
      $from = addslashes(strip_tags($from));
      $occ = addslashes(strip_tags($occ));
      $interet = addslashes(strip_tags($interet));
      $sig = addslashes(strip_tags($sig));
      $avatar = addslashes(strip_tags($avatar));
      settype($viewmail,"integer");
      settype($withsig,"integer");


      $query = "INSERT INTO users(username,user_timestamp,user_password,user_email,user_icq,user_website,user_occ,
                                  user_from,user_intrest,user_sig,user_viewemail,user_aim,user_yim,user_msnm,user_attachsig,
                                  user_avatar )
                VALUES ('$login',".mktime().",'$pass','$email',$icq,'$website','$occ',
                        '$from','$interet','$sig',$viewmail,'$aim','$yahoo','$msn',$withsig,'$avatar')";
      if(!mysql_query($query,$db)) error_die("Enregistrement impossible");


      mail($email,"Inscription sur le forum $config[site_name]",
      "Bonjour,\n\n".
      "rappel de vos login/pass :\n".
      "--------------------------\n".
      "login : $login\n".
      "pass  : $repass\n\n\n".
      "Bonne navigation sur les forums ;)\n\n".
      "$config[site_name]\n",
      "From: $config[site_name] <$config[admin_mail]>\nContent-Type: text/plain\nReturn-Path: <$config[admin_mail]>\n"
      );


      error_die("l'inscription s'est d�roul�e avec succes<br><br><a href='$config[site_url]/index.php?$sess_link' class=texte>Cliquez ici retourner � l'index</a>","Inscription");

}
?>
<table width=95% align=center class=texte bgcolor=#<?=$theme[table_liserai]?> cellspacing="<?=$theme[cellspacing]?>" cellpadding="<?=$theme[cellpadding]?>">


<form method=post>
<input type=hidden name=sess_id value=<?=$sess_id?>>


  <tr>
    <td colspan=2 class=titrecadre>S'enregistrer</td>
  </tr>

  <tr>
    <td bgcolor=#<?=$theme[color2]?> colspan=2 class=titre>login/pass</td>
  </tr>
  <tr>
    <td bgcolor=#<?=$theme[color1]?> class=texte>Login :</td>
    <td bgcolor=#<?=$theme[color2]?>><input type=text name=login maxlength=40 size=30></td>

  </tr>
  <tr>
    <td bgcolor=#<?=$theme[color1]?> class=texte>Pass :</td>
    <td bgcolor=#<?=$theme[color2]?>><input type=password name=pass></td>
  </tr>
  <tr>
    <td bgcolor=#<?=$theme[color1]?> class=texte>Confirm. :</td>
    <td bgcolor=#<?=$theme[color2]?>><input type=password name=repass></td>
  </tr>
  <tr>
    <td bgcolor=#<?=$theme[color2]?> colspan=2 class=titre>infos</td>
  </tr>
  <tr>
    <td bgcolor=#<?=$theme[color1]?> class=texte>Email :</td>
    <td bgcolor=#<?=$theme[color2]?>><input type=text name=email maxlength=50 size=30></td>
  </tr>
  <tr>
    <td bgcolor=#<?=$theme[color1]?> class=texte>Site web :</td>
    <td bgcolor=#<?=$theme[color2]?>><input type=text name=website maxlength=100 size=60></td>
  </tr>
  <tr>
    <td bgcolor=#<?=$theme[color1]?> class=texte>ICQ :</td>
    <td bgcolor=#<?=$theme[color2]?>><input type=text name=icq maxlength=12 size=12></td>
  </tr>
  <tr>
    <td bgcolor=#<?=$theme[color1]?> class=texte>AIM :</td>
    <td bgcolor=#<?=$theme[color2]?>><input type=text name=aim maxlength=40 size=30></td>
  </tr>
  <tr>
    <td bgcolor=#<?=$theme[color1]?> class=texte>MSN :</td>
    <td bgcolor=#<?=$theme[color2]?>><input type=text name=msn maxlength=40 size=30></td>
  </tr>
  <tr>
    <td bgcolor=#<?=$theme[color1]?> class=texte>Yahoo! :</td>
    <td bgcolor=#<?=$theme[color2]?>><input type=text name=yahoo maxlength=40 size=30></td>
  </tr>
  <tr>
    <td bgcolor=#<?=$theme[color1]?> class=texte>De :</td>
    <td bgcolor=#<?=$theme[color2]?>><input type=text name=from maxlength=100 size=60></td>
  </tr>
  <tr>
    <td bgcolor=#<?=$theme[color1]?> class=texte>Occupation :</td>
    <td bgcolor=#<?=$theme[color2]?>><input type=text name=occ maxlength=100 size=60></td>
  </tr>

  <tr>
    <td bgcolor=#<?=$theme[color1]?> class=texte>Interets personnels :</td>
    <td bgcolor=#<?=$theme[color2]?>><input type=text name=interet maxlength=150 size=60></td>
  </tr>
  <tr>
    <td bgcolor=#<?=$theme[color1]?> class=texte>Avatar :</td>
    <td bgcolor=#<?=$theme[color2]?>><input type=text name=avatar maxlength=100 size=60></td>
  </tr>
  <tr>
    <td bgcolor=#<?=$theme[color1]?> class=texte>Signature :</td>
    <td bgcolor=#<?=$theme[color2]?>><input type=text name=sig maxlength=255 size=60></td>
  </tr>
  <tr>
    <td bgcolor=#<?=$theme[color2]?> colspan=2 class=titre>pr�f�rences</td>
  </tr>
  <tr>
    <td bgcolor=#<?=$theme[color1]?> class=texte>Souhaitez vous que votre email<br> soit visible ?</td>
    <td bgcolor=#<?=$theme[color2]?>><input type=checkbox name=viewmail checked> Oui</td>
  </tr>
  <tr>
    <td bgcolor=#<?=$theme[color1]?> class=texte nowrap width=1%>Souhaitez vous que votre signature<br> soit toujours attach�e ?</td>
    <td bgcolor=#<?=$theme[color2]?>><input type=checkbox name=withsig> Oui</td>
  </tr>
  <tr>
    <td bgcolor=#<?=$theme[color2]?> colspan=2 class=titre align=center><input type=submit name=submit value="            Envoyer            " class=button></td>
  </tr>


</form>


</table>
