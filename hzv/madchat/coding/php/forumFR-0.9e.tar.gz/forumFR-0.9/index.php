<?
/***************************************************************************
                                index.php
                             -------------------
    last modification    : 21/11/2002
    email                : stick@newffr.org

 ***************************************************************************/

/***************************************************************************
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 ***************************************************************************/

include("fonctions.php");
include("conf/auth.php");
include("header.php");


$query="";
while(list($forum_id,$val)=@each($config[forum_mods]))
    while(list($key,$user_id)=each($val))
        $query .= " OR user_id=$user_id" ;
@reset($config[forum_mods]);

$query = "SELECT user_id,username FROM users WHERE 0=1".$query;
$result = mysql_query($query,$db);
while($row = mysql_fetch_array($result)){
      $forum_mods_name[$row[user_id]] = $row[username];
}


$query = "SELECT * FROM forums ORDER BY cat_id ASC, forum_id ASC";
$result = mysql_query($query,$db);
$currentid = -1;

?>
<table width=95% align=center class=texte bgcolor=#<?=$theme[table_liserai]?> cellspacing="<?=$theme[cellspacing]?>" cellpadding="<?=$theme[cellpadding]?>">
       <tr align=center class=titrecadre>
           <td>Nom</td>
           <td>topics</td>
           <td>posts</td>
           <td>dernier post</td>
           <td>modos</td>
       </tr>
<?
while($row = mysql_fetch_array($result)){
       if($row[cat_id]>100) continue;
       elseif($currentid != $row[cat_id]){
           echo "<tr bgcolor=#$theme[table_titre] class=titre><td colspan=5>".$config[forum_cats][$row[cat_id]]."</td></tr>";
           $currentid = $row[cat_id];
       }


       $pv_ = ($row[forum_type]==1)? "pv_" : "" ;
       $mod_string = "";
       while(list($key,$user_id)=@each($config[forum_mods][$row[forum_id]])){
            $mod_string .= "<a href=profil.php?$sess_link&mode=voir&user_id=$user_id class=minitexte>$forum_mods_name[$user_id]</a> " ;
       }
       $row[forum_desc] = stripslashes($row[forum_desc]);
       $row[forum_name] = stripslashes($row[forum_name]);
       ?>
       <tr bgcolor=#<?=$theme[color1]?>>
           <td>
             <a href=<?=$pv_?>viewforum.php?<?=$sess_link?>&forum=<?=$row[forum_id]?> class=texte><?=$row[forum_name]?></a><br>
             <span class=minitexte><?=$row[forum_desc]?></span>
           </td>
           <td bgcolor=#<?=$theme[color2]?> align=center><?=$row[forum_topics]?></td>
           <td bgcolor=#<?=$theme[color2]?> align=center><?=$row[forum_posts]?></td>
           <td class=<?=($row[forum_last_post_time]>$user_session_start)? "newpv" : "minitexte" ?> align=center><?=date("d-m-Y H:i",$row[forum_last_post_time]).", ".stripslashes($row[forum_last_poster])?></td>
           <td bgcolor=#<?=$theme[color2]?> class=minitexte align=center><?=$mod_string?></td>
       </tr>
       <?
}
?>
</table>
<?

include("tail.php");
?>
