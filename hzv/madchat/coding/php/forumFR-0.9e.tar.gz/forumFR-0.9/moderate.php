<?
/***************************************************************************
                                moderate.php
                             -------------------
    last modification    : 21/11/2002
    email                : stick@newffr.org

 ***************************************************************************/

/***************************************************************************
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 ***************************************************************************/

include("fonctions.php");
include("conf/auth.php");
include("header.php");

settype($forum,"integer");
settype($topic,"integer");
settype($newforum,"integer");
settype($an,"integer");
if(!$forum) error_die("forum inconnu");
if(!$topic) error_die("topic inconnu");

if(!$user_logged_in) error_die("Veuillez vous logger");

if($userdata[user_level]<2)
   if(!is_modo($forum,$userdata[user_id]))
      error_die("Vous n'avez pas les droits necessaires.");


if($confirm || $mode=="an"){
     $Topic = new Topics_admin($forum,$topic);
     switch($mode){
         case "del":
               $Topic->deltopic($db);
         break;
         case "move":
               $Topic->movetopic($newforum,$db);
         break;
         case "an":
               $query = "SELECT topic_sticky FROM topics WHERE topic_id=$topic";
               $etat = mysql_result(mysql_query($query,$db),0);
               $etat = ($etat)? "0" : 1 ;
               $query = "UPDATE topics SET topic_sticky=$etat WHERE topic_id=$topic";
               if(!mysql_query($query,$db)) error_die("update impossible");
         break;
         case "lock":
               $contenu = $Topic->readfile();
               $Topic->topic_locked = ($Topic->topic_locked)? 0 : 1 ;
               $Topic->write_file($contenu);

               $query = "SELECT topic_status FROM topics WHERE topic_id=$topic";
               $is_locked = mysql_result(mysql_query($query,$db),0);
               $statut=($is_locked)? "0" : 1;
               $query="UPDATE topics SET topic_status=$statut WHERE topic_id=$topic";
                if(!$result=mysql_query($query, $db))
                    error_die("Impossible d'executer la requete $query");
         break;
     }

     $forum = ($newforum)? $newforum : $forum ;
     echo "<script>window.location='$config[site_host]$config[site_url]/viewforum.php?sess_id=$sess_id&forum=$forum'</script>";
     exit();

}else{
     ?>
<table width=95% align=center class=texte bgcolor=#<?=$theme[table_liserai]?> cellspacing="<?=$theme[cellspacing]?>" cellpadding="<?=$theme[cellpadding]?>">
    <tr>
      <td>Administration Topic</td>
    </tr>
    <tr bgcolor=#<?=$theme[color1]?>>
       <td class=texte align=center>
           <form method=post>
              <input type=hidden name=topic value=<?=$topic?>>
              <input type=hidden name=sess_id value="<?=$sess_id?>">
              <input type=hidden name=forum value=<?=$forum?>>
              <input type=hidden name=confirm value=1>
              <?
              switch($mode){
                  case "del":
                        echo "<input type=hidden name=mode value=del>";
                        echo "Etes vous s�r de vouloir supprimer ce topic ??";
                  break;
                  case "move":
                        echo "D�placer vers : ";
                        echo "<select name=newforum>" ;
                        $query = "SELECT * FROM forums WHERE cat_id<100";
                        $result = mysql_query($query,$db);
                        while($row = mysql_fetch_array($result)){
                               if($row[forum_id]==$forum) continue;
                               echo "<option value=$row[forum_id]>$row[forum_name]</option>";
                        }
                        echo "</select>";
                        echo "<input type=hidden name=mode value=move>";
                  break;

                  case "lock":
                        echo "<input type=hidden name=mode value=lock>";
                        echo "Confirmer ?";
                  break;
              }
              ?>
              <br>
              <input type=submit name=submit value="           Envoyer           " class=button>
           </form>
       </td>
    </tr>
</table>
     <?

}

include("tail.php");
?>
