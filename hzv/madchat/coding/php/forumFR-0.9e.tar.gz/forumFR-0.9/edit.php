<?
/***************************************************************************
                                edit.php
                             -------------------
    last modification    : 21/11/2002
    email                : stick@newffr.org

 ***************************************************************************/

/***************************************************************************
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 ***************************************************************************/

include("fonctions.php");
include("conf/auth.php");
include("header.php");

settype($forum,"integer");
settype($topic,"integer");
settype($post,"integer");
if(!$post) error_die("post inconnu");
if(!$forum) error_die("forum inconnu");
if(!$topic) error_die("topic inconnu");

if(!$user_logged_in) error_die("Veuillez vous logger");

$Topic = new Topics_admin($forum,$topic);
$Thepost = $Topic->viewpost($post);

if($userdata[user_level]<3)
   if(!is_modo($forum,$userdata[user_id]) && ($Thepost[POSTER_ID] != $userdata[user_id] || $Thepost[LOCKED]))
           error_die("Vous n'avez pas le droit d'�diter ce post.");

?>
<table width=95% align=center class=texte bgcolor=#<?=$theme[table_liserai]?> cellspacing="<?=$theme[cellspacing]?>" cellpadding="<?=$theme[cellpadding]?>">
<?
if($submit){

        if($delete){
              //si c le seul post du topic
              if($Thepost[last_post_id]==1){
                     //on delete le topic
                     $Topic->deltopic($db);
              }else{
                   //si c le dernier post
                   if($post == $Thepost[last_post_id]){
                         $Topic->delpost($post,$db);
                         unset($Topic);
                         $Topic = new Topics_admin($forum,$topic);
                         $thetopic = $Topic->viewtopic();
                         $post_time = $thetopic[POSTS][$thetopic[last_post_id]][POST_TIME];
                         $poster = $thetopic[POSTS][$thetopic[last_post_id]][POSTER_ID];
                         $query = "SELECT username FROM users WHERE user_id=$poster";
                         $poster = mysql_result(mysql_query($query,$db),0);
                         $query = "UPDATE topics SET topic_last_post_time=$post_time, topic_last_poster='$poster' WHERE topic_id=$topic";
                         mysql_query($query,$db);

                   }else{
                         //on supprime le post et basta
                         $Topic->delpost($post,$db);
                   }
              }
              echo "<script>window.location='$config[site_host]$config[site_url]/index.php?$sess_link'</script>";
              exit();
        }else{//edit simple

              $date = date("Y-m-d H:i");
              //formatage du texte
              $post_text = censor_string($post_text);
              if(!$bbcode){
                    $post_text = bbencode($post_text);
                    $post_text = smile($post_text,$db);
              }
              $post_text = make_clickable($post_text);
              $post_text = str_replace("\n","<BR>",$post_text);
              $post_text .= "<BR><BR><font size=-1>[ Ce Message a �t� �dit� par: $userdata[username] le $date ]</font>";

              if($post==1){
                   $title = trim($title);
                   $title = censor_string($title);
                   $title = str_replace("\n"," ",$title);
                   $title = substr($title,0,99);

                   if($title){
                      $query = "UPDATE topics SET topic_title='$title' WHERE topic_id='$topic'";
                      mysql_query($query,$db);
                   }

                   $Topic->editpost($post,$post_text,$title);
              }else{
                   $Topic->editpost($post,$post_text);
              }

        }

        $pv_ = (mysql_result(mysql_query("SELECT forum_type FROM forums WHERE forum_id=$forum",$db),0)==1)? "pv_" : "";
        echo "<script>window.location='$config[site_host]$config[site_url]/$pv_"."viewtopic.php?$sess_link&topic=$topic&forum=$forum'</script>";
        exit();
}else{

        //$message = eregi_replace("\[addsig]$", "\n_________________\n" . $myrow[user_sig], $message);
        //$message = eregi_replace("\[addsig]", "", $message);
        $Thepost[TEXT] = str_replace("<BR>", "", $Thepost[TEXT]);
        $Thepost[TEXT] = stripslashes($Thepost[TEXT]);
        $Thepost[TEXT] = desmile($Thepost[TEXT]);
        $Thepost[TEXT] = bbdecode($Thepost[TEXT]);
        $Thepost[TEXT] = undo_make_clickable($Thepost[TEXT]);

        // Special handling for </textarea> tags in the message, which can break the editing form..
        $Thepost[TEXT] = preg_replace('#</textarea>#si', '&lt;/TEXTAREA&gt;', $Thepost[TEXT]);
        $Thepost[TEXT] = ereg_replace("<font size=-1>\[ Ce Message a �t� �dit� par: ".$userdata[username]." le ....\-..\-.. ..\:.. \]</font>","", $Thepost[TEXT]);

?>
      <form method=post name=form_reply>
      <input type="hidden" name="sess_id" value="<?=$sess_id?>">
      <input type=hidden name=topic value=<?=$topic?>>
      <input type=hidden name=forum value=<?=$forum?>>
      <input type=hidden name=post value=<?=$post?>>
      <tr>
        <td colspan=2 class=titrecadre>Edit</td>
      </tr>
      <tr class=texte>
         <td bgcolor=#<?=$theme[color1]?>><b>Pseudo<b/></td>
         <td bgcolor=#<?=$theme[color2]?>><?=$userdata[username]?></td>
      </tr>
      <?if($post==1){?>
         <tr class=texte>
            <td bgcolor=#<?=$theme[color1]?>><b>Titre du Topic :</b></td>
            <td bgcolor=#<?=$theme[color2]?>><input type=text name=title size=40 value="<?=$Thepost[TITLE]?>"></td>
         </tr>
      <?}?>
      <tr class=texte>
         <td bgcolor=#<?=$theme[color1]?>>
             Texte :
         <br><br><br><br><br>
         <div align=center>
         <?=bbcode_javascript()/* affichage des bouton BBcode */?>
         </div>
         </td>
         <td bgcolor=#<?=$theme[color2]?>>
           <table width=100%>
            <tr>
               <td><TEXTAREA NAME="post_text" ROWS=18 COLS=60 WRAP="VIRTUAL"><?=$Thepost[TEXT]?></TEXTAREA></td>
               <td><?=smiley_javascript(5,$config[smiles_url],$db)?></td>
            </tr>
           </table>
         </td>
      </tr>
      <tr>
         <td bgcolor=#<?=$theme[color1]?>></td>
         <td bgcolor=#<?=$theme[color2]?>>
          <input type=checkbox name=delete> Supprimer ce message <br>
          <input type=checkbox name=bbcode> D�sactiver bbcode/smile <br>
         </td>
      </tr>
      <tr>
         <td colspan=2 align=center><input type=submit name=submit class=button value="     Envoyer     "></td>
      </tr>
      </form>
<?
}
?>
</table>
<?
include("tail.php");

?>
