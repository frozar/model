<?
/***************************************************************************
                                newtopic.php
                             -------------------
    last modification    : 21/11/2002
    email                : stick@newffr.org

 ***************************************************************************/

/***************************************************************************
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 ***************************************************************************/

include("fonctions.php");
include("conf/auth.php");
include("header.php");

settype($forum,"integer");
if(!$forum) error_die("forum inconnu");

if(!$user_logged_in) error_die("Veuillez vous logger");

$query = "SELECT forum_name, forum_id, forum_type FROM forums WHERE forum_id=$forum";
if(!$result = mysql_query($query,$db)) error_die("recup des infos du forum impossible");
$forum_infos = mysql_fetch_array($result);

?>
<table width=95% align=center class=texte bgcolor=#<?=$theme[table_liserai]?> cellspacing="<?=$theme[cellspacing]?>" cellpadding="<?=$theme[cellpadding]?>">
<?

if($submit){

      $title = trim($title);
      $post_text = trim($post_text);

      if(!$title || !$post_text) error_die("Veuillez remplir les 2 champs");

      //filtrage
      settype($bbcode,"integer");
      settype($signature,"integer");
      $time = mktime();
      $username = addslashes($userdata[username]);


      //formatage du texte
      $post_text = strip_tags($post_text);
      $post_text = censor_string($post_text);
      if(!$bbcode){
          $post_text = bbencode($post_text);
          $post_text = smile($post_text,$db);
      }
      $post_text = make_clickable($post_text);
      $post_text = str_replace("\n","<BR>",$post_text);
      if($signature || $userdata[user_attachsig])
          $post_text .= "\n[addsig]";

      $title = censor_string($title);
      $title = strip_tags($title);
      $title = str_replace("\n"," ",$title);
      $title = substr($title,0,99);

      $query = "INSERT INTO topics(topic_title,topic_poster,topic_last_post_time,topic_last_poster,forum_id)
                      VALUES ('".addslashes($title)."',$userdata[user_id],".mktime().",'$username',$forum)";
      if(!mysql_query($query,$db)) error_die("insertion du topic impossible");
      $topic = mysql_insert_id();

      $Topic = new Topics($forum,$topic);
      $Topic->addpost($userdata[user_id],mktime(),$post_text,$title);

      $query = "UPDATE forums SET forum_topics=forum_topics+1, forum_last_post_time=$time, forum_last_poster='$username' WHERE forum_id=$forum";
      mysql_query($query,$db);

      $pv_ = ($forum_infos[forum_type])? "pv_" : "";
      echo "<script>window.location='$config[site_host]$config[site_url]/$pv_"."viewtopic.php?sess_id=$sess_id&topic=$topic&forum=$forum'</script>";

}else{

?>
   <form name=form_reply method=post>
   <input type="hidden" name="sess_id" value="<?=$sess_id?>">
   <input type=hidden name=forum value=<?=$forum?>>
   <tr>
      <td colspan=2 class=texte><a href=viewforum.php?forum=<?=$forum?> class=texte><b><?=$forum_infos[forum_name]?></b></a></td>
   </tr>
   <tr>
      <td bgcolor=#<?=$theme[color1]?> class=texte><b>Nom</b></td>
      <td bgcolor=#<?=$theme[color2]?> class=texte><?=$userdata[username]?></td>
   </tr>
   <tr>
      <td bgcolor=#<?=$theme[color1]?> class=texte><b>Titre du topic</b></td>
      <td bgcolor=#<?=$theme[color2]?> class=texte><input type=text name=title size=50></td>
   </tr>
   <tr>
      <td bgcolor=#<?=$theme[color1]?> valign=top class=texte>
         <b>Texte</b><br>
         <br><br><br><br><br>
         <?=bbcode_javascript()/* affichage des bouton BBcode */?>
      </td>
      <td bgcolor=#<?=$theme[color2]?>>
         <table width=100%>
            <tr>
               <td><TEXTAREA NAME="post_text" ROWS=18 COLS=60 WRAP="VIRTUAL"></TEXTAREA></td>
               <td><?=smiley_javascript(5,$config[smiles_url],$db)?></td>
            </tr>
         </table>
      </td>
   </tr>
   <tr>
      <td bgcolor=#<?=$theme[color1]?>></td>
      <td bgcolor=#<?=$theme[color2]?> class=texte>
          <input type=checkbox name=bbcode> D�sactiver bbcode/smile <br>
          <input type=checkbox name=signature <?=($userdata[user_attachsig])? "checked" : ""?>> Inclure la signature <br>
      </td>
   </tr>
   <tr>
      <td bgcolor=#<?=$theme[color1]?> colspan=2 align=center><input type=submit name=submit value="         Envoyer la r�ponse         " class=button></td>
   </tr>
   </form>
<?

}
?>
</table>
<?
include("tail.php");

?>
