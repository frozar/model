<?
/***************************************************************************
                                auth.php
                             -------------------
    last modification    : 21/11/2002
    email                : stick@newffr.org

 ***************************************************************************/

/***************************************************************************
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 ***************************************************************************/


if(ereg("auth\.php",$_SERVER["REQUEST_URI"]))
      exit();

$START_TIME = explode(" ",microtime());
$START_TIME = $START_TIME[0] + $START_TIME[1];

//********************* config ***********************//
//                        ||
//                        ||
//                        ||
//                        \/

$config[admin_mail] = "admin@forumFR.org";
$config[site_name] = "sitename";
$config[site_host] = "http://site.org";
$config[site_url] = "/site"; //ex: /forum
$config[images_url] = "$config[site_host]$config[site_url]/images";
$config[smiles_url] = "$config[images_url]/smiles";

//config bdd
$config[db_host]  = "";
$config[db_name]  = "";
$config[db_login] = "";
$config[db_pass]  = "";

$config[topic_par_page] = 20;
$config[post_par_page]  = 20;
$config[sess_time] = 60*60;
$config[sess_time_whosonline] = 60*15;

//------------------partie g�r�e par script------------------//
//vous pouvez editer les variables � la main,
//mais NE MODIFIEZ AUCUN COMMENTAIRE ni aucun nom de variable

//banlist - liste des bans
$config[banlist] = array();

//membres_equipe - non utilis�, a voir...
//$config[membres_equipe] = array(1,3,4,5,9,14,15,18,21,44,164,3360);

//censor_words - mots interdit dans les posts : "mot interdit" -> "remplacement"

//disallow_username - usrename interdit a l'enregistement

//forum_cats - categorie de forum, classee par ordre d'apparition

//theme - look & feel ;O)
$theme[bgcolor]="000000";
$theme[table_liserai]="555555";
$theme[color1]="222222";
$theme[color2]="000000";
$theme[texte_color]="aaaaaa";
$theme[link_color]="CECECE";
$theme[vlink_color]="B6BAC3";
$theme[titrecadre_color]="000000";
$theme[titre_color]="335477";
$theme[newmsg]="689ACE";
$theme[cellpadding]="3";
$theme[cellspacing]="1";
$theme[button_color]="335477";
$theme[button_border]="000000";

//forum_mods -

//-----------------------------------------------//

//********************** fin de config ************************//

//mise a 0 des variables "sensibles"
$user_logged_in = 0 ;
unset($userdata);
$new_session=0;
$stats_id=0;
unset($_COOKIE["PHPSESSID"]);
unset($_SERVER["HTTP_COOKIE"]);

//necessaire chez digital en raison de la config de php
$sess_id = ($sess_id)? $sess_id : $_GET[PHPSESSID] ;

//on recupere l'id de session si semble valide
if(ereg("[a-z0-9]{32}",$sess_id)){
     session_id($sess_id);

}else{
     $new_session=1;
}
session_start();
setcookie("PHPSESSID","");//on supprime le cookie, pas trouv� de moyen + �l�gant...
$sess_id = session_id();//si id fourni est valide, alors on le garde, sinon nouveau
$sess_link = "sess_id=".$sess_id; //necessaire suivant la config server


if( $user_session_timestamp+$config[sess_time] < mktime() && $new_session==0){
      session_destroy();
      header("Location: http://$_SERVER[SERVER_NAME]$config[site_url]\n");
}
$old_user_session_timestamp = ($user_session_timestamp)? $user_session_timestamp : mktime() ;
$user_session_timestamp = mktime();

        session_register("user_session_timestamp");//sert pour login-timeout
        session_register("user_session_ip");//secu secu secu
        session_register("user_session_start");//sert pour afficher les nouveaux post

//connexion a la bdd
if(!$db = @mysql_connect($config[db_host], $config[db_login], $config[db_pass]))
        die("connexion a la bdd impossible");
if(!@mysql_select_db($config[db_name],$db))
        die("selection de la bdd impossible");

if($new_session){

        //ecriture whosonline
        $query = "DELETE FROM whosonline WHERE sess_id='$sess_id'";
        if(!mysql_query($query,$db)) die("Purge whosonline impossible (1)");
        $query = "INSERT INTO whosonline(username,sess_id,ip,timestamp) VALUES (\"Guest\",\"$sess_id\",\"$_SERVER[REMOTE_ADDR]\",".mktime().")";
        if(!mysql_query($query,$db)) die("Ecriture whosonline impossible (2)");

        $stats_id = mysql_insert_id($db);

        $user_session_ip = $_SERVER["REMOTE_ADDR"];
        $user_session_start = mktime();

        $url_stats = (strstr($_SERVER[REQUEST_URI],"admin"))? "" : "admin/";
        $fp = fopen($url_stats."mystats/".date("d-m-Y").".stats","a");
        fputs($fp,mktime()."|".$user_session_ip."|".$_SERVER[REMOTE_HOST]."\n");
        fclose($fp);
}

if($user_session_ip != $_SERVER["REMOTE_ADDR"]) exit();

if($wop) $user_session_start = mktime();//re-init nouveaux posts

//purge whosonline
$query = "DELETE FROM whosonline WHERE timestamp<".(mktime()-$config[sess_time_whosonline]);
if(!mysql_query($query,$db)) die("Purge whosonline impossible (3)");
//ecriture whosonline
if(!$new_session){
      if($config[sess_time_whosonline]+$old_user_session_timestamp < mktime()){ //si n'est plus dans le whosonline
           $temp = ($userdata[username])? $userdata[username] : "Guest" ;
           $query = "INSERT INTO whosonline(username,user_id,sess_id,ip,timestamp) VALUES (\"$temp\",$userdata[user_id],\"$sess_id\",\"$_SERVER[REMOTE_ADDR]\",".mktime().")";
           @mysql_query($query,$db);
      }else{
           $query = "UPDATE whosonline SET timestamp=".mktime()." WHERE sess_id='$sess_id'";
           if(!mysql_query($query,$db)) die("Ecriture whos_online impossible (5)");
      }
}

if($user_logged_in){//fuck, recup des nouveaux pv, voir si on peut pas faire autrement
   $query = "SELECT user_newpv FROM users WHERE user_id=$userdata[user_id]";
   if($newpv = mysql_result(mysql_query($query,$db),0))
      $userdata[user_newpv] = $newpv;
}

?>
