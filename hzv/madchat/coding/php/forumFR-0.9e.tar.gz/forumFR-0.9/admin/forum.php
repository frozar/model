<?
/***************************************************************************
                                admin/forum.php
                             -------------------
    last modification    : 21/11/2002
    email                : stick@newffr.org

 ***************************************************************************/

/***************************************************************************
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 ***************************************************************************/
include("../fonctions.php");
include("../conf/auth.php");
include("../header.php");

settype($forum,"integer");

if(!$user_logged_in) error_die("Veuillez vous logger");
if($userdata[user_level]!=4) error_die("Vous n'avez pas access");


function rewrite($group, $newvar){
     @unlink("../conf/authbak.php");
     copy("../conf/auth.php","../conf/authbak.php");  //copie en cas de pb
     $fptemp = fopen("../conf/authtemp.php","w");
     $fp = fopen("../conf/auth.php","r+");
     //on recopie jusqu'au group a modif
     while($buf = fgets($fp,512)){
        fputs($fptemp,$buf);
        if(strstr($buf,$group)!=false) break;
     }
     //on ecrit le nouveau group
     fputs($fptemp,$newvar);
     //on deplace le pointeur jusqu'a la fin de l'ancien group (ou le debut du prochain)
     while($buf = fgets($fp,512))
        if(trim($buf)=="" || strstr("//",$buf)){
               fputs($fptemp,$buf);
               break;
        }
     //on ecrit la suite
     while($buf = fgets($fp,512))
        fputs($fptemp,$buf);
     fclose($fp);
     fclose($fptemp);
     unlink("../conf/auth.php");
     rename("../conf/authtemp.php","../conf/auth.php");
}





if($submit_new){//on  sauve le nouveau forum

      //pas besoin de cr�er le repertoire, il se cr�e automatiquement dans la class Topics

      $n_forum_name = addslashes(strip_tags($n_forum_name));
      $n_forum_desc = addslashes(strip_tags($n_forum_desc));
      settype($n_forum_cat,"integer");
      settype($n_forum_type,"integer");

      $query = "INSERT INTO forums(forum_name,forum_desc,cat_id,forum_type)
                VALUES ('$n_forum_name','$n_forum_desc',$n_forum_cat,$n_forum_type)";
      if(!mysql_query($query,$db)) error_die("cr�ation du forum impossible");
          mkdir("../txts/f".mysql_insert_id($db),0777);

      echo "<script>window.location='$config[site_host]$config[site_url]/admin/forum.php?sess_id=$sess_id'</script>";

}elseif($submit_edit){
      settype($forum_a_editer,"integer");

      if($submit_edit=="Sauver"){
           $n_forum_name = addslashes($n_forum_name);
           $n_forum_desc = addslashes($n_forum_desc);
           settype($n_forum_type,"integer");
           settype($n_forum_cat,"integer");
           settype($mods_del,"integer");
           settype($mods_new,"integer");

           $query = "UPDATE forums SET forum_name='$n_forum_name', forum_desc='$n_forum_desc',
                                       forum_type=$n_forum_type, cat_id=$n_forum_cat
                     WHERE forum_id=$forum_a_editer";
           if(!mysql_query($query,$db)) error_die("update impossible $query");

           while(list($forum_id,$val)=@each($config[forum_mods])) {
               while(list($key,$user_id)=each($val)){
                    if($user_id == $mods_del && $forum_id==$forum_a_editer) continue;

                    $towrite .= "\$config[forum_mods][$forum_id][]=$user_id;\n";
               }
           }
           if($mods_new)
                $towrite .= "\$config[forum_mods][$forum_a_editer][]=$mods_new;\n";

           rewrite("//forum_mods", $towrite) ;

           echo "<script>window.location='$config[site_host]$config[site_url]/admin/forum.php?sess_id=$sess_id'</script>";

      }else{ //on edite
           $query = "SELECT * FROM forums WHERE forum_id=$forum_a_editer";
           $result = mysql_query($query,$db);
           $forum_edit = mysql_fetch_array($result);

           if($forum_edit[forum_type]=="1") $type_pv = "selected";
           else $type_pub = "selected";

      }
}elseif($submit_del){

      $forum = new Topics_admin($forum_a_editer,1);
      $forum->delforum();

      $query = "DELETE FROM forums WHERE forum_id=$forum_a_editer";
      if(!mysql_query($query,$db)) error_die("suppression du forum impossible");
      $query = "DELETE FROM topics WHERE forum_id=$forum_a_editer";
      if(!mysql_query($query,$db)) error_die("suppression des topics impossible");


      while(list($forum_id,$val)=each($config[forum_mods])) {
           while(list($key,$user_id)=each($val)){
               if($forum_id==$forum_a_editer) continue;

               $towrite .= "\$config[forum_mods][$forum_id][]=$user_id;\n";
           }
      }
      rewrite("//forum_mods", $towrite) ;

      echo "<script>window.location='$config[site_host]$config[site_url]/admin/forum.php?sess_id=$sess_id'</script>";
}


?>

<table width=95% align=center class=texte bgcolor=#<?=$theme[table_liserai]?> cellspacing="<?=$theme[cellspacing]?>" cellpadding="<?=$theme[cellpadding]?>">
 <tr class=titrecadre>
   <td colspan=2>Administration des forums</td>
 </tr>

 <form method=post>
 <input type=hidden name=sess_id value="<?=$sess_id?>">

 <!---------- Modifier/Supprimer ------------>
 <tr class=titre>
   <td colspan=2 bgcolor=#<?=$theme[color2]?>>Modifier/Supprimer un forum</td>
 </tr>
 <tr>
   <td bgcolor=#<?=$theme[color1]?> class=texte>Forum � editer:</td>
   <td bgcolor=#<?=$theme[color2]?>>
       <select name=forum_a_editer>
      <?
      $query = "SELECT forum_name, forum_id FROM forums";
      if(!$allforum = mysql_query($query,$db)) error_die("recup des forums impossible");
      while($row = mysql_fetch_array($allforum)){
           $selected = ($row[forum_id]==$forum_a_editer)? "selected" : "" ;
           echo "<option value=$row[forum_id] $selected>$row[forum_name]</option>";
      }
      ?>
       </select>
       <input type=submit name=submit_edit value="Editer" class=button>
       <input type=submit name=submit_del value="Supprimer" class=button>
   </td>
 </tr>

 <!---------- Cr�er un forum ------------>
 <tr class=titre>
   <td colspan=2 bgcolor=#<?=$theme[color2]?>><?=($submit_edit)? "Modifier" : "Cr�er" ?> un forum</td>
 </tr>
 <tr class=texte>
    <td bgcolor=#<?=$theme[color1]?>>Nom :</td>
    <td bgcolor=#<?=$theme[color2]?>><input type=text name=n_forum_name size=50 value="<?=stripslashes($forum_edit[forum_name])?>"></td>
 </tr>
 <tr class=texte>
    <td bgcolor=#<?=$theme[color1]?>>Description :</td>
    <td bgcolor=#<?=$theme[color2]?>><input type=text name=n_forum_desc size=80 value="<?=stripslashes($forum_edit[forum_desc])?>"></td>
 </tr>
 <tr class=texte>
    <td bgcolor=#<?=$theme[color1]?>>Cat�gorie :</td>
    <td bgcolor=#<?=$theme[color2]?>>
       <select name=n_forum_cat>
       <?
       while(list($key,$val)=each($config[forum_cats])){
            $selected = ($key==$forum_edit[cat_id])? "selected" : "" ;
            echo "<option value=$key $selected>$val</option>";
       }
       reset($config[forum_cats]);
       ?>
            <option value=9999>Masqu�</option>
       </select>
    </td>
 </tr>
 <tr class=texte>
    <td bgcolor=#<?=$theme[color1]?>>Type :</td>
    <td bgcolor=#<?=$theme[color2]?>>
       <select name=n_forum_type>
          <option value=0 <?=$type_pub?>>Public</option>
          <option value=1 <?=$type_pv?>>Priv�</option>
       </select>
    </td>
 </tr>
 <?
     if($submit_edit){

          while(list($forum_id,$val)=@each($config[forum_mods])) {
               while(list($key,$user_id)=each($val))
                   if($forum_id == $forum_a_editer)
                        $forummods[] = $user_id;
          }
          @reset($config[forum_mods]);
          $query = "SELECT username,user_id FROM users ORDER BY username";
          $result = mysql_query($query,$db);
          while($row = mysql_fetch_array($result)){
               if(@in_array($row[user_id],$forummods)) $current_mods .= "<option value=$row[user_id]>$row[username]</option>\n";
               else $no_mods .= "<option value=$row[user_id]>$row[username]</option>\n";
          }

          ?>
 <tr>
     <td bgcolor=#<?=$theme[color1]?>>Supprimer un mod�rateur :</td>
     <td bgcolor=#<?=$theme[color2]?>>
         <select name=mods_del>
            <option>Ne pas enlever de mod�rateur</option>
            <?=$current_mods?>
         </select>
     </td>
 </tr>
 <tr>
     <td bgcolor=#<?=$theme[color1]?>>Ajouter un mod�rateur :</td>
     <td bgcolor=#<?=$theme[color2]?>>
         <select name=mods_new>
            <option>Ne pas ajouter de mod�rateur</option>
            <?=$no_mods?>
         </select>
     </td>
 </tr>
          <?
     }
 ?>

 <tr bgcolor=#<?=$theme[color1]?>>
   <td colspan=2 align=center><input type=submit name=submit_<?=($submit_edit)? "edit" : "new" ?> value="<?=($submit_edit)? "Sauver" : "Cr�er" ?>" class=button></td>
 </tr>
 </form>

</table>
<?

include("../tail.php");
?>
