<?
/***************************************************************************
                                admin/theme.php
                             -------------------
    last modification    : 21/11/2002
    email                : stick@newffr.org

 ***************************************************************************/

/***************************************************************************
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 ***************************************************************************/
include("../fonctions.php");
include("../conf/auth.php");
include("../header.php");

settype($forum,"integer");

if(!$user_logged_in) error_die("Veuillez vous logger");
if($userdata[user_level]!=4) error_die("Vous n'avez pas access");


function hexatodec_color($hexa){
         $color[0]=base_convert(substr($hexa,0,2),16,10);
         $color[1]=base_convert(substr($hexa,2,2),16,10);
         $color[2]=base_convert(substr($hexa,4,2),16,10);

         return $color;
}

function rewrite($group, $newvar){
     @unlink("../conf/authbak.php");
     copy("../conf/auth.php","../conf/authbak.php");  //copie en cas de pb
     $fptemp = fopen("../conf/authtemp.php","w");
     $fp = fopen("../conf/auth.php","r+");
     //on recopie jusqu'au group a modif
     while($buf = fgets($fp,512)){
        fputs($fptemp,$buf);
        if(strstr($buf,$group)!=false) break;
     }
     //on ecrit le nouveau group
     fputs($fptemp,$newvar);
     //on deplace le pointeur jusqu'a la fin de l'ancien group (ou le debut du prochain)
     while($buf = fgets($fp,512))
        if(trim($buf)=="" || strstr("//",$buf)){
               fputs($fptemp,$buf);
               break;
        }
     //on ecrit la suite
     while($buf = fgets($fp,512))
        fputs($fptemp,$buf);
     fclose($fp);
     fclose($fptemp);
     unlink("../conf/auth.php");
     rename("../conf/authtemp.php","../conf/auth.php");
}


if($submit_save){

      while(list($key,$val)=each($view_theme)) {
          $towrite .= "\$theme[$key]=\"$val\";\n";
      }
      rewrite("//theme", $towrite) ;

      echo "<script>window.location='$config[site_host]$config[site_url]$PHP_SELF?sess_id=$sess_id'</script>";
}


//######################################################################################
//################################## fabrication de l'image ############################

          $view_theme = ($view_theme && !$submit_init)? $view_theme : $theme;

          //taille et param�tres
          $img_width=450;
          $img_height=550;

          //cr�ation de l'image
          $image = imagecreate($img_width, $img_height);

          //conversion hexa->decimal du theme
          $img[color1]=hexatodec_color($view_theme[color1]);
          $img[color2]=hexatodec_color($view_theme[color2]);
          $img[table_liserai]=hexatodec_color($view_theme[table_liserai]);
          $img[table_titre]=hexatodec_color($view_theme[table_titre]);
          $img[cellpadding] = $view_theme[cellpadding];
          $img[cellspacing] = $view_theme[cellspacing];
          $img[bgcolor] = hexatodec_color($view_theme[bgcolor]);
          $img[texte_color]=hexatodec_color($view_theme[texte_color]);
          $img[link_color]=hexatodec_color($view_theme[link_color]);
          $img[vlink_color]=hexatodec_color($view_theme[vlink_color]);
          $img[titrecadre_color]=hexatodec_color($view_theme[titrecadre_color]);
          $img[titre_color]=hexatodec_color($view_theme[titre_color]);
          $img[newmsg]=hexatodec_color($view_theme[newmsg]);
          $img[button_color]=hexatodec_color($view_theme[button_color]) ;
          $img[button_border]=hexatodec_color($view_theme[button_border]) ;


          //definition des couleurs
          while(list($key,$val)=each($img)){
               $img[$key] = imagecolorallocate($image, $val[0], $val[1], $val[2]);
          }
          $black=imagecolorallocate($image, 0, 0, 0);
          $white=imagecolorallocate($image, 255, 255, 255);
          $gray=imagecolorallocate($image, 150, 150, 150);
          $gray1=imagecolorallocate($image, 200, 200, 200);

          //remplissage du fond
          imagefill($image, 0, 0, $img[bgcolor]);

          //premiere table, exemple index, viewforum, pages annexes...
          imagefilledrectangle($image,20,92,$img_width,240,$img[table_liserai]);

          imagefilledrectangle($image,21,117,$img_width,137,$img[color2]);//2eme ligne

          imagefilledrectangle($image,21,139,190,163,$img[color1]);//3eme
          imagefilledrectangle($image,192,139,$img_width,163,$img[color2]);
          imagerectangle      ($image,198,142,320,160,$img[button_border]);//bouton
          imagefilledrectangle($image,199,143,319,159,$white);

          imagefilledrectangle($image,21,165,190,187,$img[color1]);//4eme
          imagefilledrectangle($image,192,165,$img_width,187,$img[color2]);
          imagerectangle      ($image,198,168,380,184,$img[button_border]);//bouton
          imagefilledrectangle($image,199,169,349,183,$white);

          imagefilledrectangle($image,21,189,190,213,$img[color1]);//5eme
          imagefilledrectangle($image,192,189,$img_width,213,$img[color2]);

          imagefilledrectangle($image,21,215,$img_width,239,$img[color2]);//ligne submit
          imagerectangle      ($image,195,218,295,236,$img[button_border]);//bouton
          imagefilledrectangle($image,196,219,294,235,$img[button_color]);

          imagestring($image, 3, 27, 99, "Administration des forums", $img[titrecadre_color]);
          imagestring($image, 3, 27, 121, "Cr�er un forum", $img[titre_color]);
          imagestring($image, 4, 27, 144, "Nom :", $img[texte_color]);
          imagestring($image, 4, 27, 168, "Description :", $img[texte_color]);
          imagestring($image, 2, 195+30, 221, "Envoyer", $black);

          //separateur
          imagedashedline($image,0,273,$img_width,273,$black);
          imagedashedline($image,4,277,$img_width,277,$white);

          //2eme image, viewtopic StY13
          imagefilledrectangle($image,20,300,$img_width,550,$img[table_liserai]);
          imagefilledrectangle($image,21,329,       160,349,$img[color2]);//2eme ligne
          imagefilledrectangle($image,162,329,$img_width,349,$img[color2]);

          imagefilledrectangle($image,21,351,       160,457,$img[color1]);//3eme l. - 1erpost
          imagefilledrectangle($image,162,351,$img_width,457,$img[color1]);
          imageline           ($image,166,372,$img_width,372,$gray); //1er sep, sous "poste le"
          imageline           ($image,166,373,$img_width,373,$gray1);
          imageline           ($image,166,427,$img_width,427,$gray);  //2er sep, avant "edit quote"
          imageline           ($image,166,428,$img_width,428,$gray1);

          imagefilledrectangle($image,21,459,       160,550,$img[color2]);//4eme l. - 2erpost
          imagefilledrectangle($image,162,459,$img_width,550,$img[color2]);
          imageline           ($image,166,480,$img_width,480,$gray); //1er sep, sous "poste le"
          imageline           ($image,166,481,$img_width,481,$gray1);

          imagestring($image, 3, 27, 307, "Discutions generales >> Et pourquoi que ? hein ?", $img[titrecadre_color]);
          imagestring($image, 3, 400, 307, "Newtopic", $img[link_color]);
          imagestring($image, 3, 27, 334, "poster", $img[titre_color]);
          imagestring($image, 3, 167, 334, "txt", $img[titre_color]);
          //1erpost
          imagestring($image, 4, 27, 354, "Pierre", $img[link_color]);
          imagestring($image, 4, 28, 354, "Pierre", $img[link_color]);
          imagestring($image, 2, 27, 372, "Inscrit le 11-11-2002", $img[texte_color]);
          imagestring($image, 2, 167, 354, "Poste le 11-11-2002 04:30", $img[texte_color]);
          imagestring($image, 4, 167, 382, "blablabla blabla bla blabla, bla...", $img[texte_color]);
          imagestring($image, 4, 167, 402, "bla blabla bla blablabla :)", $img[texte_color]);
          imagestring($image, 4, 168, 437, "profil | edit quote", $img[link_color]);
          imagestring($image, 4, 167, 437, "profil | edit quote", $img[link_color]);
          //2eme post
          imagestring($image, 4, 27, 462, "wowo", $img[link_color]);
          imagestring($image, 4, 28, 462, "wowo", $img[link_color]);
          imagestring($image, 2, 27, 480, "Inscrit le 11-11-2002", $img[texte_color]);
          imagestring($image, 2, 167, 462, "Poste le 11-11-2002 04:43", $img[texte_color]);
          imagestring($image, 4, 167, 490, "blabla !!", $img[texte_color]);
          imagestring($image, 4, 167, 530, "bla la -> ", $img[texte_color]);
          imagestring($image, 4, 247, 530, "http://www.newffr.org", $img[link_color]);
          imagestring($image, 4, 248, 530, "http://www.newffr.org", $img[link_color]);

          unlink("mystats/test.png");
          imagepng($image, "mystats/test.png");

          //force le navigateur a recharger l'image
          srand((float) microtime()*1000000);
          $randval = rand(0,10000);
?>

<table width=95% align=center class=texte bgcolor=#<?=$theme[table_liserai]?> cellspacing="<?=$theme[cellspacing]?>" cellpadding="<?=$theme[cellpadding]?>">
 <tr class=titrecadre>
   <td colspan=2>Gestion du th�me</td>
 </tr>

 <form method=post>
 <input type=hidden name=sess_id value="<?=$sess_id?>">
 <tr class=titre>
   <td colspan=2 bgcolor=#<?=$theme[color2]?>>Modifier :</td>
 </tr>
 <tr>
    <td bgcolor=#<?=$theme[color2]?> colspan=2><b>Couleurs du forums</b></td>
 </tr>
 <tr>
    <td bgcolor=#<?=$theme[color1]?>>Couleur de fond de page :</td>
    <td bgcolor=#<?=$theme[color2]?>><input type=text name=view_theme[bgcolor] value="<?=$view_theme[bgcolor]?>"></td>
 </tr>
 <tr>
    <td bgcolor=#<?=$theme[color1]?>>Liserais de table :</td>
    <td bgcolor=#<?=$theme[color2]?>><input type=text name=view_theme[table_liserai] value="<?=$view_theme[table_liserai]?>"></td>
 </tr>
 <tr>
    <td bgcolor=#<?=$theme[color1]?>>Couleur cellule 1 :</td>
    <td bgcolor=#<?=$theme[color2]?>><input type=text name=view_theme[color1] value="<?=$view_theme[color1]?>"></td>
 </tr>
 <tr>
    <td bgcolor=#<?=$theme[color1]?>>Couleur cellule 2 :</td>
    <td bgcolor=#<?=$theme[color2]?>><input type=text name=view_theme[color2] value="<?=$view_theme[color2]?>"></td>
 </tr>
 <tr>
    <td bgcolor=#<?=$theme[color2]?> colspan=2><b>Couleurs des polices</b></td>
 </tr>
 <tr>
    <td bgcolor=#<?=$theme[color1]?>>Couleur du texte :</td>
    <td bgcolor=#<?=$theme[color2]?>><input type=text name=view_theme[texte_color] value="<?=$view_theme[texte_color]?>"></td>
 </tr>
 <tr>
    <td bgcolor=#<?=$theme[color1]?>>Couleur des liens :</td>
    <td bgcolor=#<?=$theme[color2]?>><input type=text name=view_theme[link_color] value="<?=$view_theme[link_color]?>"></td>
 </tr>
 <tr>
    <td bgcolor=#<?=$theme[color1]?>>Couleur des liens visit�s:</td>
    <td bgcolor=#<?=$theme[color2]?>><input type=text name=view_theme[vlink_color] value="<?=$view_theme[vlink_color]?>"></td>
 </tr>
 <tr>
    <td bgcolor=#<?=$theme[color1]?>>Couleur titre de table :</td>
    <td bgcolor=#<?=$theme[color2]?>><input type=text name=view_theme[titrecadre_color] value="<?=$view_theme[titrecadre_color]?>"></td>
 </tr>
 <tr>
    <td bgcolor=#<?=$theme[color1]?>>Couleur titre de bloc (style les cat�gorie) :</td>
    <td bgcolor=#<?=$theme[color2]?>><input type=text name=view_theme[titre_color] value="<?=$view_theme[titre_color]?>"></td>
 </tr>
 <tr>
    <td bgcolor=#<?=$theme[color1]?>>Couleur des nouveaux messages :</td>
    <td bgcolor=#<?=$theme[color2]?>><input type=text name=view_theme[newmsg] value="<?=$view_theme[newmsg]?>"></td>
 </tr>
 <tr>
    <td bgcolor=#<?=$theme[color2]?> colspan=2><b>Divers</b></td>
 </tr>
 <tr>
    <td bgcolor=#<?=$theme[color1]?>>Table Cellpadding :</td>
    <td bgcolor=#<?=$theme[color2]?>><input type=text name=view_theme[cellpadding] value="<?=$view_theme[cellpadding]?>"></td>
 </tr>
 <tr>
    <td bgcolor=#<?=$theme[color1]?>>Table Cellspacing :</td>
    <td bgcolor=#<?=$theme[color2]?>><input type=text name=view_theme[cellspacing] value="<?=$view_theme[cellspacing]?>"></td>
 </tr>
 <tr>
    <td bgcolor=#<?=$theme[color1]?>>Couleur des boutons :</td>
    <td bgcolor=#<?=$theme[color2]?>><input type=text name=view_theme[button_color] value="<?=$view_theme[button_color]?>"></td>
 </tr>
 <tr>
    <td bgcolor=#<?=$theme[color1]?>>Bordure des boutons :</td>
    <td bgcolor=#<?=$theme[color2]?>><input type=text name=view_theme[button_border] value="<?=$view_theme[button_border]?>"></td>
 </tr>
 <tr>
    <td bgcolor=#<?=$theme[color1]?> colspan=2 align=center>
       <input type=submit name=submit_save value="Sauver" class=button>
       <input type=submit name=submit_view value="             Aper�u dessous            " class=button>
       <input type=submit name=submit_init value="Reinit" class=button>
    </td>
 </tr>
 </form>

 <!---------- apercu ------------>
 <tr class=titre>
   <td colspan=2 bgcolor=#<?=$theme[color2]?>>Aper�u :</td>
 </tr>
 <tr>
   <td colspan=2 bgcolor=#<?=$theme[color2]?> align=center>
          <br>
          <img src=mystats/test.png?<?=$randval?> style="border-color:#<?=$theme[texte_color]?>" border=1>
          <br>
   </td>
 </tr>
</table>
<?
include("../tail.php");
?>
