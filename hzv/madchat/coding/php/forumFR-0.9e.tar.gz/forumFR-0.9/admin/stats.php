<?
/***************************************************************************
                                admin/stats.php
                             -------------------
    last modification    : 21/11/2002
    email                : stick@newffr.org

 ***************************************************************************/

/***************************************************************************
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 ***************************************************************************/
include("../fonctions.php");
include("../conf/auth.php");
include("../header.php");

settype($forum,"integer");

if(!$user_logged_in) error_die("Veuillez vous logger");
if($userdata[user_level]!=4) error_die("Vous n'avez pas access");



?>
<script>
function copie(from){
         document.thepage.textleft.value+=from.value
}
function copypaste(from){
       dest = (from.name=="goright")? "textright" : "textleft" ;
       source = (from.name!="goright")? "textright" : "textleft" ;
       eval("document.thepage."+dest+".value = document.thepage."+source+".value");
}

</script>
Tous les doublons sont illimin�s, on compte une visite par jour par ip<br>
<br>

<form name=thepage>
<table width=95% align=center class=texte bgcolor=#<?=$theme[table_liserai]?> cellspacing="<?=$theme[cellspacing]?>" cellpadding="<?=$theme[cellpadding]?>">
   <tr class=titre>
      <td colspan=3 bgcolor=#<?=$theme[color2]?>>Les stats</td>
   </tr>
       <tr class=titrecadre>
          <td colspan=3>S�lection :</td>
       </tr>
       <tr align=center>
          <td colspan=3 bgcolor=#<?=$theme[color1]?>>
            <input type=button name=goleft value=" Reset " class=button onclick="document.thepage.textleft.value=''">
            <input type=button name=goleft value="   <<   " class=button onclick="copypaste(this)">
              &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            <input type=button name=goright value="   >>   " class=button onclick="copypaste(this)">
            <input type=button name=goleft value=" Reset " class=button onclick="document.thepage.textright.value=''">
            <br>
            <textarea name=textleft rows=10 cols=70 style="font-family: verdana;"></textarea>
            <textarea name=textright rows=10 cols=70 style="font-family: verdana;"></textarea>
          </td>
       </tr>
       <tr class=titrecadre align=center>
          <td>Date</td>
          <td>Nb visites</td>
          <td>Visiteurs</td>
       </tr>

<?

if ($dir = @opendir("mystats")) {
  while($file = readdir($dir)) {
       if($file=="." || $file=="..") continue;

           $filedate = substr($file,0,strpos($file,"."));
           $filedate = explode("-",$filedate);
           $timestamp = mktime(0,0,0,$filedate[1],$filedate[0],$filedate[2]);
           if($timestamp < mktime() - (3600*24*5)){
                  if($timestamp < mktime() - (3600*24*30))
                                unlink("mystats/".$file);
                          continue;
           }

       $nodouble = array();
       $visiteurs = "";

       $visit=0;
       $fp = fopen("mystats/".$file,"r");
       while($line = fgets($fp,512)){
            $stats = explode("|",$line);
            if(@in_array($stats[1],$nodouble)) continue;
            $visiteurs.="<option value='".date("H:i",$stats[0])."|$stats[1]|$stats[2]'>".date("H:i",$stats[0])."|$stats[1]|$stats[2]</option>";
            $nodouble[] = $stats[1];
            $visit++;
       }
       fclose($fp);

       $date = date("D, d-m-Y",$timestamp);
?>
       <tr>
          <td bgcolor=#<?=$theme[color1]?>><?=$date?></td>
          <td bgcolor=#<?=$theme[color2]?>><?=$visit?></td>
          <td bgcolor=#<?=$theme[color2]?>>
            <select size="10" multiple name=listeip onchange="copie(this)">
               <?=$visiteurs?>
            </select>
          </td>
       </tr>
<?
  }
  closedir($dir);
}

?>
</table>
</form>
<?
include("../tail.php");
?>
