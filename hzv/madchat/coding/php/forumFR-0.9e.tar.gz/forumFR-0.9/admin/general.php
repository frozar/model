<?
/***************************************************************************
                                admin/general.php
                             -------------------
    last modification    : 21/11/2002
    email                : stick@newffr.org

 ***************************************************************************/

/***************************************************************************
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 ***************************************************************************/
include("../fonctions.php");
include("../conf/auth.php");
include("../header.php");

settype($forum,"integer");

if(!$user_logged_in) error_die("Veuillez vous logger");
if($userdata[user_level]!=4) error_die("Vous n'avez pas access");


function rewrite($group, $newvar){
     @unlink("../conf/authbak.php");
     copy("../conf/auth.php","../conf/authbak.php");  //copie en cas de pb

     $fptemp = fopen("../conf/authtemp.php","w");
     $fp = fopen("../conf/auth.php","r+");

     //on recopie jusqu'au group a modif
     while($buf = fgets($fp,512)){
        fputs($fptemp,$buf);
        if(strstr($buf,$group)!=false){
              break;
        }
     }

     //on ecrit le nouveau group
     fputs($fptemp,$newvar);

     //on deplace le pointeur jusqu'a la fin de l'ancien group (ou le debut du prochain)
     while($buf = fgets($fp,512)){
        if(trim($buf)=="" || strstr("//",$buf)){
               fputs($fptemp,$buf);
               break;
        }
     }

     //on ecrit la suite
     while($buf = fgets($fp,512)){
        fputs($fptemp,$buf);
     }

     fclose($fp);
     fclose($fptemp);

     unlink("../conf/auth.php");
     rename("../conf/authtemp.php","../conf/auth.php");
}

$towrite="";
if($submit_ban){

     settype($toban,"integer");
     settype($deban,"integer");


     while(list($key,$val)=each($config[banlist])){
            if($val == $deban) continue;
            $banlist[] = $val;
     }
     if($toban)
         $banlist[] = $toban;
     $banlist = @implode(",",$banlist) ;
     $towrite = "\$config[banlist] = array($banlist);\n";

     rewrite("//banlist", $towrite) ;

     echo "<script>window.location='$config[site_host]$config[site_url]/admin/general.php?sess_id=$sess_id'</script>";

}elseif($submit_censor){

     if(!$new_word && $new_remp) error_die("Indiquez le mot � remplacer");
     while(list($key,$val)=@each($config[censor_words])) {
          if($key == stripslashes($delete)) continue;
          $towrite .= "\$config[censor_words][\"".addslashes($key)."\"]=\"".addslashes($val)."\";\n";
     }

     if($new_word) //pas de addslashes, on est en magic_quote
          $towrite .= "\$config[censor_words][\"".$new_word."\"]=\"".$new_remp."\";\n";

     rewrite("//censor_words", $towrite) ;

     echo "<script>window.location='$config[site_host]$config[site_url]/admin/general.php?sess_id=$sess_id'</script>";
}elseif($submit_name){

     settype($novalidusername,"integer");

     $i=0;
     while(list($key,$val)=each($config[disallow_username])) {
          if($key == $novalidusername) continue;
          $towrite .= "\$config[disallow_username][$i]=\"".addslashes($val)."\";\n";
          $i++;
     }
     if($newname)
          $towrite .= "\$config[disallow_username][$i]=\"".addslashes($newname)."\";\n";

     rewrite("//disallow_username", $towrite) ;

     echo "<script>window.location='$config[site_host]$config[site_url]/admin/general.php?sess_id=$sess_id'</script>";

}elseif($submit_cat){

     settype($cat_del,"integer");

     $i=0;
     while(list($key,$val)=each($config[forum_cats])) {
          if($key == $cat_del) continue;
          $towrite .= "\$config[forum_cats][$i]=\"".addslashes($val)."\";\n";
          $i++;
     }
     if($cat_new)
          $towrite .= "\$config[forum_cats][$i]=\"".addslashes($cat_new)."\";\n";

     rewrite("//forum_cats", $towrite) ;

     echo "<script>window.location='$config[site_host]$config[site_url]/admin/general.php?sess_id=$sess_id'</script>";
}


?>

<div align=center class=texte>
!!!! ATTENTION !!!! CETTE PAGE EDITE LE FICHIER auth.php !!!! <br>
AU MOINDRE PROBLEME, AVANT TOUTE CHOSE, ALLEZ SUR LE FTP, REMPLACEZ auth.php PAR authbak.php
</div>

<table width=95% align=center class=texte bgcolor=#<?=$theme[table_liserai]?> cellspacing="<?=$theme[cellspacing]?>" cellpadding="<?=$theme[cellpadding]?>">
 <tr class=titrecadre>
   <td colspan=2>Configuration G�n�rale du forum</td>
 </tr>


 <!-------- BANLIST -------->
 <? $current_ban="";
    $no_ban="";
    $query = "SELECT username, user_id FROM users ORDER BY username";
    $result = mysql_query($query,$db);
    while($row = mysql_fetch_array($result)){
        if(in_array($row[user_id],$config[banlist])) {
             $current_ban.= "<option value=$row[user_id]>$row[username]</option>\n";
        }else{
             $no_ban.= "<option value=$row[user_id]>$row[username]</option>\n";
        }
    }
 ?>
 <tr class=titre>
   <td colspan=2 bgcolor=#<?=$theme[color2]?>>Liste des bans</td>
 </tr>
 <form method=post>
 <input type=hidden name=sess_id value="<?=$sess_id?>">
 <tr>
     <td bgcolor=#<?=$theme[color1]?>>Utilisateurs bannis :</td>
     <td bgcolor=#<?=$theme[color2]?>>
         <select name=deban>
            <option>Ne pas enlever de ban</option>
            <?=$current_ban?>
         </select>
     </td>
 </tr>
 <tr>
     <td bgcolor=#<?=$theme[color1]?>>Utilisateurs a bannir (vite vite) :</td>
     <td bgcolor=#<?=$theme[color2]?>>
         <select name=toban>
            <option>Ne pas ajouter de ban</option>
            <?=$no_ban?>
         </select>
     </td>
 </tr>
 <tr>
   <td bgcolor=#<?=$theme[color1]?> colspan=2 align=center><input class=button type=submit name=submit_ban value="     Envoyer     "></td>
 </tr>
 </form>


 <!-------- CENSOR WORD -------->
 <form method=post>
 <input type=hidden name=sess_id value="<?=$sess_id?>">
 <tr class=titre>
   <td colspan=2 bgcolor=#<?=$theme[color2]?>>Mots interdits</td>
 </tr>
 <tr>
   <td colspan=2 align=center bgcolor=#<?=$theme[color1]?>>
         <table width=100% align=center class=texte bgcolor=#<?=$theme[table_liserai]?> cellspacing="<?=$theme[cellspacing]?>" cellpadding="<?=$theme[cellpadding]?>">
          <tr>
             <td align=center bgcolor=#<?=$theme[color2]?>><b>Mot</b></td>
             <td align=center bgcolor=#<?=$theme[color2]?>><b>Remplacement</b></td>
             <td align=center bgcolor=#<?=$theme[color2]?>><b>Action</b></td>
          </tr>
          <?
          while(list($key,$val)=@each($config[censor_words])) {
              ?>
              <tr class=minitexte>
                  <td align=center bgcolor=#<?=$theme[color1]?>><?=htmlspecialchars($key)?></td>
                  <td align=center bgcolor=#<?=$theme[color1]?>><?=htmlspecialchars($val)?></td>
                  <td align=center bgcolor=#<?=$theme[color2]?>><a href=<?=$PHP_SELF?>?<?=$sess_link?>&submit_censor=1&delete=<?=urlencode($key)?> class=minitexte>supprimer</a></td>
              </tr>
              <?
          }
          ?>
          <tr>
            <td align=center bgcolor=#<?=$theme[color1]?>><input type=text name=new_word></td>
            <td align=center bgcolor=#<?=$theme[color1]?>><input type=text name=new_remp></td>
            <td align=center bgcolor=#<?=$theme[color1]?>><input type=submit name=submit_censor value="Cr�er" class=button></td>
          </tr>
        </table>
   </td>
 </tr>
 </form>

 <!-------- USERNAME INTERDITS -------->
 <form method=post>
 <input type=hidden name=sess_id value="<?=$sess_id?>">
 <tr class=titre>
   <td colspan=2 bgcolor=#<?=$theme[color2]?>>Noms d'utilisateurs</td>
 </tr>
 <tr>
     <td bgcolor=#<?=$theme[color1]?>>Noms d'utilisateurs interdits</td>
     <td bgcolor=#<?=$theme[color2]?>>
         <select name=novalidusername>
            <option value=-1>Ne rien supprimer</option>
         <?while(list($key,$val)=each($config[disallow_username])){
                 echo "<option value=$key>$val</option>\n";
           }
         ?>
         </select>
         <input type=submit name=submit_name value="    Supprimer    " class=button>
     </td>
 </tr>
 <tr>
    <td bgcolor=#<?=$theme[color1]?>>nouveau :<input type=text name=newname></td>
    <td bgcolor=#<?=$theme[color2]?>><input type=submit name=submit_name value="    Ajouter    " class=button></td>
 </tr>
 </form>

 <!-------- CATEGORIE DE FORUM -------->
 <form method=post>
 <input type=hidden name=sess_id value="<?=$sess_id?>">
 <tr class=titre>
   <td colspan=2 bgcolor=#<?=$theme[color2]?>>Cat�gories de forums</td>
 <tr>
     <td bgcolor=#<?=$theme[color1]?>>Cat�gories actuelles</td>
     <td bgcolor=#<?=$theme[color2]?>>
         <select name=cat_del>
            <option value=-1>Ne rien supprimer</option>
         <?while(list($key,$val)=each($config[forum_cats])){
                 echo "<option value=$key>$val</option>\n";
           }
         ?>
         </select>
         <input type=submit name=submit_cat value="    Supprimer    " class=button>
     </td>
 </tr>
 <tr>
    <td bgcolor=#<?=$theme[color1]?>>nouveau :<input type=text name=cat_new></td>
    <td bgcolor=#<?=$theme[color2]?>><input type=submit name=submit_cat value="    Ajouter    " class=button></td>
 </tr>
 </tr>

</table>
<?

include("../tail.php");
?>
