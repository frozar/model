<?
/***************************************************************************
                                admin/index.php
                             -------------------
    last modification    : 21/11/2002
    email                : borax@newffr.org

 ***************************************************************************/

/***************************************************************************
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 ***************************************************************************/

include("../fonctions.php");
include("../conf/auth.php");
include("../header.php");

if(!$user_logged_in) error_die("Veuillez vous logger");
if($userdata[user_level]!=4)
        error_die("Vous n'avez pas acces � cette zone");

?>
<table width=95% align=center class=texte bgcolor="<?=$theme[table_liserai]?>" cellspacing="<?=$theme[cellspacing]?>" cellpadding="<?=$theme[cellpadding]?>">
        <tr>
        <td class=titrecadre>Index du panneau d'administration.</td>
        </tr>

        <tr>
        <td bgcolor=#<?=$theme[color1]?>><a class=texte href=general.php?<?=$sess_link?>>Administration g�n�rale</a></td>
        </tr>

        <tr>
        <td bgcolor=#<?=$theme[color1]?>><a class=texte href=user.php?<?=$sess_link?>>Modifier / Supprimer un utilisateur</a></td>
        </tr>

        <tr>
        <td bgcolor=#<?=$theme[color1]?>><a class=texte href=forum.php?<?=$sess_link?>>Modifier/ajouter un forum</a></td>
        </tr>

        <tr>
        <td bgcolor=#<?=$theme[color1]?>><a class=texte href=theme.php?<?=$sess_link?>>G�rer le th�me</a></td>
        </tr>

        <tr>
        <td bgcolor=#<?=$theme[color1]?>><a class=texte href=stats.php>Nombre de visiteurs</a></td>
        </tr>

        <!----tr>
        <td bgcolor=#<?=$theme[color1]?>><a class=texte href=entretien.php?<?=$sess_link?>>Entretien/Syncronisation du forum</a></td>
        </tr----->

<table>

<?

include("../tail.php");
?>
