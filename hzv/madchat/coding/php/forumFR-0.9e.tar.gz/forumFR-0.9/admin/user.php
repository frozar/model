<?
/***************************************************************************
                                admin/user.php
                             -------------------
    last modification    : 21/11/2002
    email                : borax@newffr.org

 ***************************************************************************/

/***************************************************************************
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 ***************************************************************************/

include("../fonctions.php");
include("../conf/auth.php");
include("../header.php");

//Si jamais l'user n'est pas logg� ou n'est pas un administrateur, on affiche une erreur
if(!$user_logged_in || $userdata[user_level]!=4)
    error_die("Acces interdit � cette zone.");

//Si jamais on n'a pas defini d'id a modifier, on affiche la liste des users, pour en choisir un.
if(!$user_id)
{
?>

<form method="get">
<table width=95% align=center class=texte bgcolor=<?=$theme[table_liserai]?> cellspacing=<?=$theme[cellspacing]?> cellpadding=<?=$theme[cellpadding]?>>
      <tr>
       <td class=titrecadre>Choisissez l'user � modifier:</td>
      </tr>

      <tr bgcolor=<?=$theme[color1]?> >
      <td>
       <select name=user_id>
        <option>------- Select -------</option>

        <?
        $sql="SELECT username, user_id FROM users WHERE 1 ORDER BY username ASC";

        if(!$result=mysql_query($sql, $db))
          error_die("Impossible de chopper la liste d'user.");

        while($user_list=mysql_fetch_array($result))
        {
              echo"<option value=$user_list[user_id]>$user_list[username]</option><br>";
        }
        ?>

       </select>
      </td>
      </tr>
        <tr bgcolor=<?=$theme[color1]?>>
        <td><input type=submit value=Modifier name=modif></td>
        </tr>
      </table>
</form>

<?
}

//Pour supprimer l'user.
if($del && !$confirm_del)
        error_die("Veuillez confirmer la suppression");

if($del && $confirm_del && $user_id)
{
        $sql="DELETE FROM users WHERE user_id=$user_id";

        if(!$result_del=mysql_query($sql, $db))
                error_die("Impossible de supprimer le membre.");

        error_die("Utilisateur supprim�<br><br><a href=$config[site_url]/admin/?$sess_link class=texte>Cliquez ici pour revenir au pannel</a>", "Utilisateur supprim�");

}





//si on a d�fini l'user et qu'on a envoy� le form pour la modif, on update la bdd
if($user_id && $modif)
{
     if($submit)
     {
      settype($user_uin, "integer");

      $user_mail=addslashes($new_mail);
      $user_avatar=addslashes($new_avatar);
      $user_website=addslashes($new_website);
      $user_aim=addslashes($new_aim);
      $user_occ=addslashes($new_occ);
      $user_int=addslashes($new_int);
      $user_from=addslashes($new_from);
      $user_msn=addslashes($new_msn);
      $user_sig=addslashes($new_sig);
      $username=addslashes($new_username);

      $user_viewemail=$new_viewemail;
      $user_attachsig=$new_attachsig;
      $user_pvsound=$new_pvsound;
      $user_avatar=$new_avatar;
      $user_uin=$new_uin;
      $user_level=$new_level;

      $sql="UPDATE users SET username=\"$username\",user_avatar=\"$user_avatar\" , user_viewemail=\"$user_viewemail\" , user_occ=\"$user_occ\", user_website=\"$user_website\", user_aim=\"$user_aim\", user_icq=\"$user_uin\", user_email=\"$user_mail\", user_sig=\"$user_sig\", user_msnm=\"$user_msn\", user_intrest=\"$user_int\", user_from=\"$user_from\", user_attachsig=\"$user_attachsig\", user_level=\"$user_level\", user_pvsound=\"$user_pvsound\"  WHERE user_id=$user_id";

      if(!$result=mysql_query($sql, $db))
         error_die("Impossible d'ajouter les infos dans la base. $sql");

      else error_die("Profil utilisateur modifi�<br><br><a href=$config[site_url]/admin/?$sess_link class=texte>Cliquez ici pour revenir au pannel</a>", "Modifications effectu�es");
      exit();

     }

//On recupere les infos du membres et on les affiche dans un formulaire
   $sql="SELECT * FROM users WHERE user_id=$user_id";
   if(!$result=mysql_query($sql,$db))
       error_die("Impossible d'acceder � la base pour la requ�te.");

   if(!$user=mysql_fetch_array($result))
       error_die("Impossible d'afficher les infos pour ce membre.");

   //pour que le level du membre sois selectionn� par defaut (evite que les admins se retrouvent membre sans faire expres :P)

   $level1=($user[user_level]=="1")? "SELECTED" : "";
   $level2=($user[user_level]=="2")? "SELECTED" : "";
   $level3=($user[user_level]=="3")? "SELECTED" : "";
   $level4=($user[user_level]=="4")? "SELECTED" : "";

   $username=stripslashes($user[username]);
   $user_mail=stripslashes($user[user_email]);
   $user_avatar=$user[user_avatar];
   $user_date=date("d / m / Y",$user[user_timestamp]);
   $user_uin=$user[user_icq];
   $user_website=addslashes($user[user_website]);
   $user_aim=stripslashes($user[user_aim]);
   $user_occ=stripslashes($user[user_occ]);
   $user_int=stripslashes($user[user_intrest]);
   $user_from=stripslashes($user[user_from]);
   $user_msn=stripslashes($user[user_msnm]);
   $user_posts=$user[user_posts];
   $user_sig=stripslashes($user[user_sig]);

   //a adapter en fonction dans la prochaine version.
   $check_view_email=($userdata[view_email]==1)? "checked": "";
   $non_check_view_email=($userdata[view_email]==0)? "checked": "";

   $check_attachsig=($userdata[user_attachsig]==1)? "checked": "";
   $non_check_attachsig=($userdata[user_attachsig]==0)? "checked": "";

   $check_pvsound=($userdata[user_pvsound]==1)? "checked": "";
   $non_check_pvsound=($userdata[user_pvsound]==0)? "checked": "";

   echo"
   <form method=post>

   <input type=\"HIDDEN\" name=sess_id VALUE=\"$sess_id\">

   <TABLE width=95% align=center class=texte bgcolor=\"$theme[table_liserai]\" cellspacing=\"$theme[cellspacing]\" cellpadding=\"$theme[cellpadding]\">

          <tr>
          <td colspan=1 class=titrecadre>Profil de:</td>
          <td colspan=2 class=titrecadre>$user[username]</td>
          </tr>


          <tr>
          <td colspan=1 bgcolor=$theme[color2]>Pseudonyme:</td>
          <td colspan=2 bgcolor=$theme[color2]><INPUT TYPE=\"TEXT\" SIZE=\"40\" name=new_username VALUE=\"$username\"></td>
          </tr>

          <tr>
          <td bgcolor=$theme[color1]>E-Mail:</td>
          <td bgcolor=$theme[color1] colspan=2><input TYPE=\"TEXT\" SIZE=\"40\" name=new_mail VALUE=\"$user_mail\"></td>
          </tr>

          <tr>
          <td bgcolor=$theme[color2]>UIN (ICQ):</td>
          <td bgcolor=$theme[color2] colspan=2><input TYPE=\"TEXT\" SIZE=\"40\" name=new_uin VALUE=\"$user_uin\"></td>
          </tr>

          <tr>
          <td bgcolor=$theme[color1]>AIM:</td>
          <td bgcolor=$theme[color1] colspan=2><input TYPE=\"TEXT\" SIZE=\"40\" name=new_aim VALUE=\"$user_aim\"></td>
          </tr>

          <tr>
          <td bgcolor=$theme[color2]>MSN:</td>
          <td bgcolor=$theme[color2] colspan=2><input TYPE=\"TEXT\" SIZE=\"40\" name=new_msn VALUE=\"$user_msn\"></td>
          </tr>

          <tr>
          <td bgcolor=$theme[color1]>Site Web:</td>
          <td bgcolor=$theme[color1] colspan=2><input TYPE=\"TEXT\" SIZE=\"40\" name=new_website VALUE=\"$user_website\"></td>
          </tr>

          <tr>
          <td bgcolor=$theme[color2]>De:</td>
          <td bgcolor=$theme[color2] colspan=2><input TYPE=\"TEXT\" SIZE=\"40\" name=new_from VALUE=\"$user_from\"></td>
          </tr>

          <tr>
          <td bgcolor=$theme[color1]>Occupation:</td>
          <td bgcolor=$theme[color1] colspan=2><input TYPE=\"TEXT\" SIZE=\"40\" name=new_occ VALUE=\"$user_occ\"></td>
          </tr>

          <tr>
          <td bgcolor=$theme[color2]>Interets personnels:</td>
          <td bgcolor=$theme[color2] colspan=2><input TYPE=\"TEXT\" SIZE=\"40\" name=new_int VALUE=\"$user_int\"></td>
          </tr>

          <tr>
          <td bgcolor=$theme[color1]>Signature:</td>
          <td bgcolor=$theme[color1] colspan=2><input type=texte size=40 name=new_sig VALUE=\"$user_sig\"></td>
          </tr>

          <tr>
          <td bgcolor=$theme[color2]>Avatar:</td>
          <td bgcolor=$theme[color2] colspan=2><INPUT TYPE=\"TEXT\" size=40 name=new_avatar VALUE=\"$user_avatar\"></td>
          </tr>

          <tr>
          <td bgcolor=$theme[color1]>Laisse les membres voir votre E-mail:</td>
          <td bgcolor=$theme[color1]><input type=radio name=new_viewemail value=1 $check_view_email>Oui</td>
          <td bgcolor=$theme[color1]><input type=radio name=new_viewemail value=0 $non_check_view_email>Non</td>
          </tr>

          <tr>
          <TD bgcolor=$theme[color2]>Utiliser un son pour signaler les pv</TD>
          <td bgcolor=$theme[color2]><input type=radio name=new_pvsound value=1 $check_pvsound>Oui</td>
          <td bgcolor=$theme[color2]><input type=radio name=new_pvsound value=0 $non_check_pvsound>Non</td>
          </tr>

          <tr>
          <td bgcolor=$theme[color1]>Afficher votre signature dans les posts:</td>
          <td bgcolor=$theme[color1]><input type=radio name=new_attachsig value=1 $check_attachsig>Oui</td>
          <td bgcolor=$theme[color1]><input type=radio name=new_attachsig value=0 $non_check_attachsig>Non</td>
          </tr>

          <tr>
          <td colspan=3 bgcolor=$theme[color2]>
          <select name=new_level>
          <option value=1 $level1>Membre</option>
          <option value=2 $level2>Moderateur</option>
          <option value=3 $level3>Super-mod�rateur</option>
          <option value=4 $level4>Administrateur</option>
          </select>
          </td>
          </tr>

          <br>

          <tr>
          <td align=center><INPUT TYPE=\"submit\" name=\"submit\" VALUE=\"Modifier le profil de $username.\" class=button></td>
          <td colspan=2><INPUT TYPE=\"submit\" name=\"del\" VALUE=\"Supprimer $username du forum\" class=button> Confirmer: <INPUT TYPE=\"checkbox\" NAME=\"confirm_del\"></td>
          </tr>
        </table>
        </form>

        ";

}


include("../tail.php");
?>
