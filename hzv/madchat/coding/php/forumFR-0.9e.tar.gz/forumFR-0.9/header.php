<?
/***************************************************************************
                                header.php
                             -------------------
    last modification    : 21/11/2002
    email                : stick@newffr.org

 ***************************************************************************/

/***************************************************************************
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 ***************************************************************************/
if(ereg("header\.php",$_SERVER["REQUEST_URI"]))
      exit();
?>
<html>
<head>
<style>


BODY { scrollbar-face-color: #; scrollbar-shadow-color: #; scrollbar-highlight-color: #FFFFFF;      scrollbar-3dlight-color: #; scrollbar-darkshadow-color: #000000; scrollbar-track-color: #;      scrollbar-arrow-color: #}




.texte {font-family: verdana; font-size: 10pt; color: #<?=$theme[texte_color]?>}
a.texte {color: #<?=$theme[link_color]?>; text-decoration: none; font-weight : bold}
a.texte:visited {color: #<?=$theme[vlink_color]?>; text-decoration: none; font-weight : bold}
a.texte:hover {color: #<?=$theme[link_color]?>; text-decoration: underline; font-weight : bold}


.minitexte {font-family: verdana; font-size: 8pt; color: #<?=$theme[texte_color]?>}
a.minitexte {color: #<?=$theme[link_color]?>; text-decoration: none; font-weight : bold}
a.minitexte:visited {color: #<?=$theme[vlink_color]?>; text-decoration: none; font-weight : bold}
a.minitexte:hover {color: #<?=$theme[link_color]?>; text-decoration: underline; font-weight : bold}
.newpv {font-family: verdana; font-size: 8pt; color: #<?=$theme[newmsg]?>}


<!-- titre principal, 1ere ligne de toutes les table -->
.titrecadre {font-family: verdana; font-size: 8pt; color: #<?=$theme[titrecadre_color]?>; font-weight : bold}
a.titrecadre {color: #<?=$theme[titrecadre_color]?>; text-decoration: none; font-weight : bold}
a.titrecadre:visited {color: #<?=$theme[titrecadre_color]?>; text-decoration: none; font-weight : bold}
a.titrecadre:hover {color: #<?=$theme[titrecadre_color]?>; text-decoration: underline; font-weight : bold}


<!-- titre divers, style les categories, [titre, views, replies], etc...  ; text-decoration: underline -->
.titre {font-family: verdana; font-size: 8pt; color: #<?=$theme[titre_color]?>; font-weight : bold}
a.titre {color: #<?=$theme[link_color]?>; text-decoration: none}
a.titre:visited {color: #<?=$theme[link_color]?>; text-decoration: none}
a.titre:hover {color: #<?=$theme[link_color]?>; text-decoration: underline}


<!-- les formulaires -->
input { text-indent : 2 px; }
textarea { font-size : 11 px; }
input.button {
     color : #000000;
     background-color : #<?=$theme[button_color]?>;
}


input, select, checkbox, radio {
     color : #000000;
     font-family : verdana;
     font-size : 11 px;
     border : 1 px ;
     border-color : #<?=$theme[button_border]?>;
}
</style>
<script>
function addBB(code){
      document.form_reply.post_text.value += code;
      document.form_reply.post_text.focus();
}
</script>
</head>


<body  text="#<?=$theme[texte_color]?>" bgcolor=#<?=$theme[bgcolor]?>>
<a name=hautdepage>
<table align=center width=95%>
  <tr>
    <td width="300" rowspan=2> <a href=<?=$config[site_url]?>/?<?=$sess_link?> ><img src=<?=$config[images_url]."/logo.gif"?> border=0></a>
    </td>
    <td width="96">&nbsp;</td>
    <td valign=top align=center>
        - <a href=<?=$config[site_url]?>/index.php?<?=$sess_link?>&wop=1 class=minitexte>Reinit
          des nouveaux posts</a> -
     </td>
    <td width="96" align=center valign=top>&nbsp;</td>
  </tr>
  <tr>
    <td colspan="3" align=center valign=bottom class=minitexte> <a href=<?=$config[site_url]?>/register.php?<?=$sess_link?> class=minitexte>S'enregistrer</a>
      - <a href=<?=$config[site_url]?>/pv.php?<?=$sess_link?> class=minitexte>Messages Priv�s</a>
      - <a href=<?=$config[site_url]?>/memberlist.php?<?=$sess_link?> class=minitexte>Liste des
      membres</a> <br>
      <? if($user_logged_in){
                  echo"<a href=$config[site_url]/profil.php?$sess_link&mode=modif&user_id=$userdata[user_id] class=minitexte>Profil</a> - ";
                  echo"<a href=$config[site_url]/login.php?$sess_link&logout=1 class=minitexte>Logout</a>";
            }


         ?>
      <!--br><br>
         online : <?=$nb_online?> personne(s)
         <br-->
      <?
         if($user_logged_in){
              echo "<br><br>Utilisateur logg� $userdata[username], vous avez $userdata[user_newpv] nouveau(x) message(s) priv�(s)<br>";
         }else{
              ?>
      <form method=post action=<?=$config[site_url]?>/login.php>
        <input type="hidden" name="sess_id" value="<?=$sess_id?>">
        <span class=minitexte> <b>Vous logger :</b> Login
        <input type=text name=login size=8>
        Pass
        <input type=password name=pass size=8>
        <input type=submit name=submit value="ok">
        </span>
      </form>
      <?
         }




         ?>
    </td>
  </tr>
  <tr>
    <td colspan=4><br></td>
  </tr>
</table>
