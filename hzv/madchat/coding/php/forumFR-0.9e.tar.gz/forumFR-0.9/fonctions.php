<?php
/***************************************************************************
                                fonctions.php
                             -------------------
    last modification    : 21/11/2002
    email                : stick@newffr.org

 ***************************************************************************/

/***************************************************************************
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 ***************************************************************************/

class Topics extends xml_base {
       var $topic_id;
       var $forum_id;
       var $filename_tpl;
       var $topic_title;
       var $topic_locked;

       function Topics($forum_id,$topic_id){
            settype($forum_id,"integer");
            settype($topic_id,"integer");

            $up="";
            if(strstr($_SERVER[REQUEST_URI],"admin")) $up = "../";
            if(!is_dir($up."txts/f$forum_id"))
               if(!mkdir($up."txts/f$forum_id",0777)) error_die("creation du rep $up"."txts/f$forum_id impossible");

            $this->filename_tpl = $up."txts/f#forum#/t#topic#.xml";

            $this->forum_id = $forum_id;
            $this->topic_id = $topic_id;
            $this->topic_locked="0";
            $this->filename = str_replace("#forum#",$forum_id,$this->filename_tpl);
            $this->filename = str_replace("#topic#",$topic_id,$this->filename);
       }

       function make_entitie($post_id,$poster_id,$post_time,$post_text){
             $toadd =
             "\t<post post_id=\"$post_id\" poster_id=\"$poster_id\" post_time=\"$post_time\">\n".
             "\t\t<text>$post_text</text>\n".
             "\t</post>\n";
             return $toadd;
       }

       function viewtopic(){
              $xml_parse = $this->parse();
              ksort($xml_parse[POSTS]);

              return $xml_parse;
       }

       function readfile(){
              $xml_parse = $this->parse();
              @ksort($xml_parse[POSTS]);
              $this->topic_title = $xml_parse[TITLE];
              if($xml_parse[LOCKED])
                    $this->topic_locked = 1;

              while(list($key,$post)=@each($xml_parse[POSTS])){
                   $post[TEXT] = htmlspecialchars($post[TEXT]);

                   $return .= $this->make_entitie($post[POST_ID],$post[POSTER_ID],$post[POST_TIME],$post[TEXT]);
              }

              return $return;
       }

       function write_file($contenu){
              global $IS_SUEXEC;

              $buf =
              "<?xml version=\"1.0\" encoding=\"ISO-8859-1\"?>\n\n".
              "<topic title=\"".htmlspecialchars($this->topic_title)."\" locked=\"".$this->topic_locked."\">\n".
              $contenu.
              "</topic>\n";

              $fp = fopen($this->filename,"w");
              fputs($fp,$buf);
              fclose($fp);
              if($IS_SUEXEC) chmod($this->filename,0600);
              else chmod($this->filename,0777);
       }
}

class Topics_admin extends Topics {
       var $filename2;
       var $xml_parse;
       var $forum_rep;

       function Topics_admin($forum_id,$topic_id){
              $this->Topics($forum_id,$topic_id);
              $this->xml_parse = $this->parse();
              $this->topic_title = $this->xml_parse[TITLE];
              $this->topic_locked = $this->xml_parse[LOCKED];
              @ksort($this->xml_parse[POSTS]);
       }

       function viewpost($post_id){
              while(list($key,$post)=each($this->xml_parse[POSTS])){
                   if($post[POST_ID]!=$post_id){
                        continue;
                   }
                   $post[last_post_id] = $this->xml_parse[last_post_id];
                   break;
              }
              $post[TITLE] = $this->xml_parse[TITLE];
              $post[LOCKED] = $this->xml_parse[LOCKED];

              reset($this->xml_parse[POSTS]);
              return $post;
       }

       function editpost($post_id,$newpost,$title=""){
              if($title) $this->topic_title=$title;

              while(list($key,$post)=each($this->xml_parse[POSTS])){
                   $post[TEXT] = ($post[POST_ID]==$post_id)? htmlspecialchars($newpost) : htmlspecialchars($post[TEXT]);
                   //if($post[POST_ID]==$post_id) echo "post trouv�";

                   $allposts .= $this->make_entitie($post[POST_ID],$post[POSTER_ID],$post[POST_TIME],$post[TEXT]);
              }
              reset($this->xml_parse[POSTS]);

              $this->write_file($allposts);
       }

       function delforum(){
                $forum_rep = ereg_replace("^(.*)/[^/]+$","\\1",$this->filename);
                if(!$dir = @opendir($forum_rep)) error_die("parcours du rep $forum_rep impossible");

                while($file = readdir($dir)){
                      if($file=="." || $file=="..") continue;
                      if(!unlink($forum_rep."/".$file)) error_die("suppression du fichier $forum_rep/$file impossible");
                }
                closedir($dir);

                rmdir($forum_rep);
       }

       function delpost($post_id,$db){
              $query = "UPDATE forums SET forum_posts=forum_posts-1 WHERE forum_id=".$this->forum_id;
              if(!mysql_query($query,$db)) error_die("mise a jour du nombre de post impossible");
              $query = "UPDATE topics SET topic_replies=topic_replies-1 WHERE topic_id=".$this->topic_id;
              if(!mysql_query($query,$db)) error_die("mise a jour du nombre de post impossible");

              $i=1;
              while(list($key,$post)=each($this->xml_parse[POSTS])){
                   if($post[POST_ID]==$post_id){
                        unset($post_id);
                        continue;
                   }

                   $post[TEXT] = htmlspecialchars($post[TEXT]);
                   $allposts .= $this->make_entitie($i,$post[POSTER_ID],$post[POST_TIME],$post[TEXT]);
                   $i++ ;
              }
              reset($this->xml_parse[POSTS]);

              $this->write_file($allposts);
       }

       function deltopic($db){
              global $userdata;

              //on supprime le topic
              $query = "DELETE FROM topics WHERE topic_id=".$this->topic_id;
              if(!mysql_query($query,$db)) error_die("suppression entr�e topic impossible");
              //on choppe le nouveau dernier topic du forum
              $query = "SELECT topic_last_post_time, topic_last_poster FROM topics WHERE forum_id=".$this->forum_id." ORDER BY topic_last_post_time DESC LIMIT 0,1";
              if(!$result = mysql_query($query,$db)) error_die("recup du dernier topic impossible");
              $top = mysql_fetch_array($result);

              //on update les entr�e dernier poster et dernier post_time du forum
              $query = "UPDATE forums SET forum_topics=forum_topics-1, forum_posts=forum_posts-".$this->xml_parse[last_post_id].
                       ", forum_last_poster='".$top[topic_last_poster]."', forum_last_post_time=".$top[topic_last_post_time].
                       " WHERE forum_id=".$this->forum_id;
              if(!mysql_query($query,$db)) error_die("mise a jour du nombre de post impossible");

              if(!unlink($this->filename)) error_die("suppression du topic impossible");

              //envoie de la notif par pv
              $init_id = $this->xml_parse[POSTS][1][POSTER_ID];
              $Pv_msg = new Pv_msg($init_id);
              $Pv_msg->sendpmsg($userdata[user_id],$init_id,mktime(),"Votre topic \"".$this->xml_parse[TITLE]."\" a �t� supprim�<br><br>Si vous avez des questions, vous pouvez contacter $userdata[username]",$db);

       }

       function movetopic($dest,$db){
              global $userdata, $db, $config, $IS_SUEXEC;

              settype($dest,"integer");
              //on bouge le topic dans le bon forum
              $query = "UPDATE topics SET forum_id=$dest WHERE topic_id=".$this->topic_id;
              if(!mysql_query($query, $db)) error_die("impossible de mettre a jour la bdd");

              //on choppe le nouveau dernier topic du forum source
              $query = "SELECT topic_last_post_time, topic_last_poster FROM topics WHERE forum_id=".$this->forum_id." ORDER BY topic_last_post_time DESC LIMIT 0,1";
              if(!$result = mysql_query($query,$db)) error_die("recup du dernier topic impossible");
              $top = mysql_fetch_array($result);
              //on update les entr�e dernier poster et dernier post_time du forum source
              $query = "UPDATE forums SET forum_topics=forum_topics-1, forum_posts=forum_posts-".$this->xml_parse[last_post_id].
                       ", forum_last_poster='".$top[topic_last_poster]."', forum_last_post_time=".$top[topic_last_post_time].
                       " WHERE forum_id=".$this->forum_id;
              if(!mysql_query($query,$db)) error_die("mise a jour du nombre de post impossible.");

              $query = "SELECT username FROM users WHERE user_id=".$this->xml_parse[POSTS][$this->last_post_id][POSTER_ID];
              $name = mysql_result(mysql_query($query,$db),0);

              //on update les entr�e dernier poster et dernier post_time du forum destination
              $query = " UPDATE forums SET forum_topics=forum_topics+1, forum_posts=forum_posts+".$this->xml_parse[last_post_id].
                       ", forum_last_poster='".$name."', forum_last_post_time=".$this->xml_parse[POSTS][$this->last_post_id][POST_TIME].
                       " WHERE forum_id=".$dest;
              if(!mysql_query($query,$db)) error_die("mise a jour du nombre de post impossible..");

              $this->filename2 = str_replace("#forum#",$dest,$this->filename_tpl);
              $this->filename2 = str_replace("#topic#",$this->topic_id,$this->filename2);

              if(!copy($this->filename,$this->filename2)) error_die("copie de ".$this->filename." vers ".$this->filename2." impossible");
              if($IS_SUEXEC) chmod($this->filename2,0600);
              else chmod($this->filename2,0777);
              if(!unlink($this->filename)) error_die("suppression de ".$this->filename." impossible");

              //envoie de la notif par pv
              $init_id = $this->xml_parse[POSTS][1][POSTER_ID];
              $Pv_msg = new Pv_msg($init_id);
              $Pv_msg->sendpmsg($userdata[user_id],$init_id,mktime(),"Votre topic \"".$this->xml_parse[TITLE]."\" a �t� d�plac�<br>Vous le trouverez <a href='$config[site_url]/viewtopic.php?forum=$dest&topic=$this->topic_id' class=texte>ici</a>",$db);

       }
}

class Pv_msg extends xml_base {
       var $xml_parse;

       function Pv_msg($user_id){
             settype($user_id,"integer");

             $this->filename="pvs/u$user_id.xml";
       }

       function sendpmsg($poster_id,$touser,$time,$text,$db){
             $this->filename="pvs/u$touser.xml";
             $this->addpost($poster_id,$time,$text);

             $query = "UPDATE users SET user_newpv=user_newpv+1 WHERE user_id=$touser";
             if(!mysql_query($query, $db))  error_die("Could not enter data into the database.");
       }

       function readpmsg($reply=0){
              $xml_parse = $this->parse();
              @krsort($xml_parse[MSGS]);

              if($reply)
                  return $xml_parse[MSGS][$reply];
              else
                  return $xml_parse;
       }

       function make_entitie($msg_id,$poster_id,$post_time,$text){
             $toadd =
             "\t<msg msg_id=\"$msg_id\" poster_id=\"$poster_id\" msg_time=\"$post_time\">\n".
             "\t\t<text>$text</text>\n".
             "\t</msg>\n";
             return $toadd;
       }

       function del($posts_array){
              $xml_parse = $this->parse();
              if(!$xml_parse[MSGS]) return false;
              ksort($xml_parse[MSGS]);

              $i=1;
              while(list($key,$msg)=each($xml_parse[MSGS])){
                  if($posts_array[$msg[MSG_ID]]==1) continue;

                  $msg[TEXT] = htmlspecialchars($msg[TEXT]);
                  $return .= $this->make_entitie($i,$msg[POSTER_ID],$msg[MSG_TIME],$msg[TEXT]);
                  $i++;
              }

              $this->write_file($return);
       }

       function readfile(){
              $xml_parse = $this->parse();
              @ksort($xml_parse[MSGS]);

              while(list($key,$msg)=@each($xml_parse[MSGS])){
                   $msg[TEXT] = htmlspecialchars($msg[TEXT]);

                   $return .= $this->make_entitie($msg[MSG_ID],$msg[POSTER_ID],$msg[MSG_TIME],$msg[TEXT]);
              }

              return $return;
       }

       function write_file($contenu){
              global $IS_SUEXEC;

              $buf =
              "<?xml version=\"1.0\" encoding=\"ISO-8859-1\"?>\n\n".
              "<pv_msgs>\n".
              $contenu.
              "</pv_msgs>\n";

              $fp = fopen($this->filename,"w");
              fputs($fp,$buf);
              fclose($fp);
              if($IS_SUEXEC) chmod($this->filename,0600);
              else chmod($this->filename,0777);
       }
}

class xml_base {
       var $filename;
       var $last_post_id;

       function addpost($poster_id,$post_time,$text,$title=""){
             $allposts = $this->readfile();

             if($this->topic_locked) return false;
             if($title)
                $this->topic_title = $title;

             $post_id = $this->last_post_id + 1;


             $text = htmlspecialchars($text);
             $badcars = array("","","","","","�","","","","","","�","","","","","","","","","�","","","","","","","");
             $text = str_replace($badcars,"�",$text);

             $toadd = $this->make_entitie($post_id,$poster_id,$post_time,$text);

             $towrite = $allposts.$toadd;

             $this->write_file($towrite);

             return TRUE;
       }

       function parse(){
              clearstatcache();
              if(!$fp = @fopen($this->filename,"r")) return false;
              $buffer = fread($fp, filesize($this->filename));
              fclose($fp);

              $my_xml = new xml_parser();
              $xml_parse = $my_xml->goparse($buffer);
              $this->last_post_id = $xml_parse[last_post_id];

              return $xml_parse;
       }

}

class xml_parser {
       var $topic;
       var $post_id;
       var $gettext;
       var $parsetype;

       function TraiterDebutBalise($analyseur_xml, $balise, $attributs) {
              if($balise=="TEXT"){
                    $this->gettext=1;
              }elseif($balise=="POST"){
                    $this->parsetype="POSTS";
                    $this->post_id = $attributs[POST_ID];
                    $this->topic[POSTS][$this->post_id] = $attributs;
                    $this->topic[POSTERS_ID][$attributs[POSTER_ID]] = 1;
              }elseif($balise=="MSG"){
                    $this->parsetype="MSGS";
                    $this->post_id = $attributs[MSG_ID];
                    $this->topic[MSGS][$this->post_id] = $attributs;
                    $this->topic[POSTERS_ID][$attributs[POSTER_ID]] = 1;
              }elseif($balise=="TOPIC"){
                    $this->topic[TITLE] = $attributs[TITLE];
                    if($attributs[LOCKED])
                         $this->topic[LOCKED] = $attributs[LOCKED];
              }

       }

       function TraiterFinBalise($analyseur_xml, $balise) {
              if($balise=="TEXT") $this->gettext=0;
       }

       function TraiterDonnee($analyseur_xml, $donnee) {
              if($this->gettext==1){
                 $this->topic[$this->parsetype][$this->post_id][TEXT] .= $donnee;
              }
       }

       function goparse($buffer){
                 $this->analyseur_xml = xml_parser_create();
                 xml_set_object($this->analyseur_xml,&$this);
                 // Ev�nements affect� sur une balise
                 xml_set_element_handler($this->analyseur_xml, TraiterDebutBalise, TraiterFinBalise);
                 // Ev�nement affect� sur une donn�e
                 xml_set_character_data_handler($this->analyseur_xml, TraiterDonnee);

                 if (!@xml_parse($this->analyseur_xml, $buffer)) {
                       // Traitement des erreurs
                       die(sprintf("Erreur XML '%s' � la ligne %d\n",
                           xml_error_string(xml_get_error_code($this->analyseur_xml)),
                           xml_get_current_line_number($this->analyseur_xml)));
                 }

                 //destruction de l'entite xml
                 xml_parser_free($this->analyseur_xml);

                 //if($this->parse_type!="view")
                 $this->topic[last_post_id] = $this->post_id;
                 return $this->topic;
       }
}



 //tableau de smiley dans reply et newtopic, avec appel au javascript "smiley()"
function bbcode_javascript(){
         $html = "<input type=button class=button value=' B ' onclick=\"javascript:addBB(' [b] [/b]')\">&nbsp;".
                 "<input type=button class=button value=' I ' onclick=\"javascript:addBB(' [i] [/i]')\">&nbsp;".
                 "<input type=button class=button value='Url' onclick=\"javascript:addBB(' [url] [/url]')\"><br><br>".
                 "<input type=button class=button value='Img' onclick=\"javascript:addBB(' [img] [/img]')\">&nbsp;".
                 "<input type=button class=button value='Code' onclick=\"javascript:addBB(' [code] [/code]')\">";

         return $html;
}
function smiley_javascript($nbcols_smiley,$url_smiles,$db){
         $query = "SELECT smile_url, code FROM smiles";
         if(!$result = mysql_query($query,$db)) return false;

         $html = "<table width=1% align=center>\n";
         $i=0;
         while($row = @mysql_fetch_array($result)){
             if($old_url!=$row[smile_url]){
                $html .= (($i+1)%$nbcols_smiley==1)? "\t</tr>\n" : "" ;
                $html .= ($i%$nbcols_smiley==0)? "\t<tr>\n" : "" ;
                $html .= "\t\t<td><a href=\"javascript:addBB(' $row[code] ');\"><img src=\"$url_smiles/$row[smile_url]\" border=0></a></td>\n";
                $i++;
                $old_url = $row[smile_url];
             }
         }
         $html .= "</table>\n";

         return $html;
}

function error_die($msg,$titre="Erreur"){
     global $theme, $START_TIME;
       ?>
<table width=50% align=center class=texte bgcolor=#<?=$theme[table_liserai]?> cellspacing="<?=$theme[cellspacing]?>" cellpadding="<?=$theme[cellpadding]?>">
   <tr>
     <td class=titrecadre><?=$titre?></td>
   </tr>
   <tr>
     <td class=texte align=center bgcolor=#<?=$theme[color1]?>>
        <?=$msg?>
     </td>
   </tr>
</table>
       <?
                $END_TIME = explode(" ",microtime());
                $END_TIME = $END_TIME[0] + $END_TIME[1];
                $TIME = $END_TIME-$START_TIME;
                echo "<font color=black>$TIME</font>";

        exit();
}


function censor_string($texte){
           global $config;
           while(list($key,$val)=@each($config[censor_words])){
                $texte = str_replace($key,$val,$texte);
           }

           return $texte;
}

function is_modo($forum,$user_id){
      global $config;

      if(@in_array($user_id,$config[forum_mods][$forum])) return true;
      return false;
}

//################################################################################################################
//################################################################################################################
//################################################################################################################
//################################################################################################################
//################################################################################################################
//################################################################################################################
//################################################################################################################
//################################################################################################################
//################################################################################################################
//################################################################################################################
//################################################################################################################
//################################################################################################################
//################################################################################################################
//################################################################################################################
//################################################################################################################
//################################################################################################################
//###################### fonctions phpBB pour etre compatible avec les anciens messages (helas) ##################
//################################################################################################################
//################################################################################################################
//################################################################################################################
//################################################################################################################
//################################################################################################################
//################################################################################################################
//################################################################################################################
//##################################################||||##########################################################
//##################################################||||##########################################################
//##################################################||||##########################################################
//##################################################||||##########################################################
//##################################################||||##########################################################
//##################################################||||##########################################################
//##################################################||||##########################################################
//##################################################||||##########################################################
//##################################################||||##########################################################
//##################################################||||##########################################################
//##################################################||||##########################################################
//##################################################||||##########################################################
//###########################################||||###||||###||||###################################################
//#############################################||||#||||#||||#####################################################
//################################################||||||||########################################################
//##################################################||||##########################################################
//################################################################################################################

function smile($message) {
   global $db, $config;

   // Pad it with a space so the regexp can match.
   $message = ' ' . $message;

   if ($getsmiles = mysql_query("SELECT *, length(code) as length FROM smiles ORDER BY length DESC"))
   {
      while ($smiles = mysql_fetch_array($getsmiles))
      {
                        $smile_code = preg_quote($smiles[code]);
                        $smile_code = str_replace('/', '//', $smile_code);
                        $message = preg_replace("/([\n\\ \\.])$smile_code/si", '\1<IMG SRC="' . $config[smiles_url] . '/' . $smiles[smile_url] . '">', $message);
      }
   }

   // Remove padding, return the new string.
   $message = substr($message, 1);
   return($message);
}

function make_clickable($text) {

        $ret = " " . $text;

        $ret = preg_replace("#([\n ])([a-z]+?)://([^, \n\r]+)#i", "\\1<!-- BBCode auto-link start --><a href=\"\\2://\\3\" target=\"_blank\" class=texte>\\2://\\3</a><!-- BBCode auto-link end -->", $ret);

        $ret = preg_replace("#([\n ])www\.([a-z0-9\-]+)\.([a-z0-9\-.\~]+)((?:/[^, \n\r]*)?)#i", "\\1<!-- BBCode auto-link start --><a href=\"http://www.\\2.\\3\\4\" target=\"_blank\" class=texte>www.\\2.\\3\\4</a><!-- BBCode auto-link end -->", $ret);

        $ret = preg_replace("#([\n ])([a-z0-9\-_.]+?)@([^, \n\r]+)#i", "\\1<!-- BBcode auto-mailto start --><a href=\"mailto:\\2@\\3\" class=texte>\\2@\\3</a><!-- BBCode auto-mailto end -->", $ret);

        // Remove our padding..
        $ret = substr($ret, 1);

        return($ret);
}

function desmile($message) {
   // Ick Ick Global variables...remind me to fix these! - theFinn
   global $db, $config;

   if ($getsmiles = mysql_query("SELECT * FROM smiles")){
      while ($smiles = mysql_fetch_array($getsmiles)) {
         $message = str_replace("<IMG SRC=\"$config[smiles_url]/$smiles[smile_url]\">", $smiles[code], $message);
      }
   }
   return($message);
}

function bbencode($message) {

        // pad it with a space so we can distinguish between FALSE and matching the 1st char (index 0).
        // This is important; bbencode_quote(), bbencode_list(), and bbencode_code() all depend on it.
        $message = " " . $message;

        // First: If there isn't a "[" and a "]" in the message, don't bother.
        if (! (strpos($message, "[") && strpos($message, "]")) )
        {
                // Remove padding, return.
                $message = substr($message, 1);
                return $message;
        }

        // [CODE] and [/CODE] for posting code (HTML, PHP, C etc etc) in your posts.
        $message = bbencode_code($message);

        // [QUOTE] and [/QUOTE] for posting replies with quote, or just for quoting stuff.
        $message = bbencode_quote($message);

        // [list] and [list=x] for (un)ordered lists.
        $message = bbencode_list($message);

        // [b] and [/b] for bolding text.
        $message = preg_replace("/\[b\](.*?)\[\/b\]/si", "<!-- BBCode Start --><B>\\1</B><!-- BBCode End -->", $message);

        // [i] and [/i] for italicizing text.
        $message = preg_replace("/\[i\](.*?)\[\/i\]/si", "<!-- BBCode Start --><I>\\1</I><!-- BBCode End -->", $message);

        // [img]image_url_here[/img] code..
        $message = preg_replace("/\[img\](.*?)\[\/img\]/si", "<!-- BBCode Start --><IMG SRC=\"\\1\" BORDER=\"0\"><!-- BBCode End -->", $message);

        // Patterns and replacements for URL and email tags..
        $patterns = array();
        $replacements = array();

        // [url]xxxx://www.phpbb.com[/url] code..
        $patterns[0] = "#\[url\]([a-z]+?://){1}(.*?)\[/url\]#si";
        $replacements[0] = '<!-- BBCode u1 Start --><A HREF="\1\2" TARGET="_blank" class=texte>\1\2</A><!-- BBCode u1 End -->';

        // [url]www.phpbb.com[/url] code.. (no xxxx:// prefix).
        $patterns[1] = "#\[url\](.*?)\[/url\]#si";
        $replacements[1] = '<!-- BBCode u1 Start --><A HREF="http://\1" TARGET="_blank" class=texte>\1</A><!-- BBCode u1 End -->';

        // [url=xxxx://www.phpbb.com]phpBB[/url] code..
        $patterns[2] = "#\[url=([a-z]+?://){1}(.*?)\](.*?)\[/url\]#si";
        $replacements[2] = '<!-- BBCode u2 Start --><A HREF="\1\2" TARGET="_blank" class=texte>\3</A><!-- BBCode u2 End -->';

        // [url=www.phpbb.com]phpBB[/url] code.. (no xxxx:// prefix).
        $patterns[3] = "#\[url=(.*?)\](.*?)\[/url\]#si";
        $replacements[3] = '<!-- BBCode u2 Start --><A HREF="http://\1" TARGET="_blank" class=texte>\2</A><!-- BBCode u2 End -->';

        // [email]user@domain.tld[/email] code..
        $patterns[4] = "#\[email\](.*?)\[/email\]#si";
        $replacements[4] = '<!-- BBCode Start --><A HREF="mailto:\1" class=texte>\1</A><!-- BBCode End -->';

        $message = preg_replace($patterns, $replacements, $message);

        // Remove our padding from the string..
        $message = substr($message, 1);
        return $message;

} // bbencode()



function bbdecode($message) {

                // Undo [code]
                $code_start_html = "<!-- BBCode Start --><TABLE BORDER=0 ALIGN=CENTER WIDTH=85%><TR><TD><font size=-1>Code:</font><HR></TD></TR><TR><TD><FONT SIZE=-1><PRE>";
                $code_end_html = "</PRE></FONT></TD></TR><TR><TD><HR></TD></TR></TABLE><!-- BBCode End -->";
                $message = str_replace($code_start_html, "[code]", $message);
                $message = str_replace($code_end_html, "[/code]", $message);

                // Undo [quote]
                $quote_start_html = "<!-- BBCode Quote Start --><TABLE BORDER=0 ALIGN=CENTER WIDTH=85%><TR><TD><font size=-1>Quote:</font><HR></TD></TR><TR><TD><FONT SIZE=-1><BLOCKQUOTE>";
                $quote_end_html = "</BLOCKQUOTE></FONT></TD></TR><TR><TD><HR></TD></TR></TABLE><!-- BBCode Quote End -->";
                $message = str_replace($quote_start_html, "[quote]", $message);
                $message = str_replace($quote_end_html, "[/quote]", $message);

                // Undo [b] and [i]
                $message = preg_replace("#<!-- BBCode Start --><B>(.*?)</B><!-- BBCode End -->#s", "[b]\\1[/b]", $message);
                $message = preg_replace("#<!-- BBCode Start --><I>(.*?)</I><!-- BBCode End -->#s", "[i]\\1[/i]", $message);

                // Undo [url] (long form)
                $message = preg_replace("#<!-- BBCode u2 Start --><A HREF=\"([a-z]+?://)(.*?)\" TARGET=\"_blank\" class=texte>(.*?)</A><!-- BBCode u2 End -->#s", "[url=\\1\\2]\\3[/url]", $message);

                // Undo [url] (short form)
                $message = preg_replace("#<!-- BBCode u1 Start --><A HREF=\"([a-z]+?://)(.*?)\" TARGET=\"_blank\" class=texte>(.*?)</A><!-- BBCode u1 End -->#s", "[url]\\3[/url]", $message);

                // Undo [url] (short form)
                $message = preg_replace("#<!-- BBCode auto-link start --><a href=\"([a-z]+?://)(.*?)\" target=\"_blank\" class=texte>(.*?)</a><!-- BBCode auto-link end -->#s", "[url]\\3[/url]", $message);

                // Undo [email]
                $message = preg_replace("#<!-- BBCode Start --><A HREF=\"mailto:(.*?)\" class=texte>(.*?)</A><!-- BBCode End -->#s", "[email]\\1[/email]", $message);

                // Undo [img]
                $message = preg_replace("#<!-- BBCode Start --><IMG SRC=\"(.*?)\" BORDER=\"0\"><!-- BBCode End -->#s", "[img]\\1[/img]", $message);

                // Undo lists (unordered/ordered)

                // <li> tags:
                $message = str_replace("<!-- BBCode --><LI>", "[*]", $message);

                // [list] tags:
                $message = str_replace("<!-- BBCode ulist Start --><UL>", "[list]", $message);

                // [list=x] tags:
                $message = preg_replace("#<!-- BBCode olist Start --><OL TYPE=([A1])>#si", "[list=\\1]", $message);

                // [/list] tags:
                $message = str_replace("</UL><!-- BBCode ulist End -->", "[/list]", $message);
                $message = str_replace("</OL><!-- BBCode olist End -->", "[/list]", $message);

                return($message);
}
/**
 * Nathan Codding - Jan. 12, 2001.
 * Performs [quote][/quote] bbencoding on the given string, and returns the results.
 * Any unmatched "[quote]" or "[/quote]" token will just be left alone.
 * This works fine with both having more than one quote in a message, and with nested quotes.
 * Since that is not a regular language, this is actually a PDA and uses a stack. Great fun.
 *
 * Note: This function assumes the first character of $message is a space, which is added by
 * bbencode().
 */
function bbencode_quote($message)
{
        // First things first: If there aren't any "[quote]" strings in the message, we don't
        // need to process it at all.

        if (!strpos(strtolower($message), "[quote]"))
        {
                return $message;
        }

        $stack = Array();
        $curr_pos = 1;
        while ($curr_pos && ($curr_pos < strlen($message)))
        {
                $curr_pos = strpos($message, "[", $curr_pos);

                // If not found, $curr_pos will be 0, and the loop will end.
                if ($curr_pos)
                {
                        // We found a [. It starts at $curr_pos.
                        // check if it's a starting or ending quote tag.
                        $possible_start = substr($message, $curr_pos, 7);
                        $possible_end = substr($message, $curr_pos, 8);
                        if (strcasecmp("[quote]", $possible_start) == 0)
                        {
                                // We have a starting quote tag.
                                // Push its position on to the stack, and then keep going to the right.
                                //bbcode_array_push($stack, $curr_pos);
                                array_push($stack, $curr_pos);
                                ++$curr_pos;
                        }
                        else if (strcasecmp("[/quote]", $possible_end) == 0)
                        {
                                // We have an ending quote tag.
                                // Check if we've already found a matching starting tag.
                                if (sizeof($stack) > 0)
                                {
                                        // There exists a starting tag.
                                        // We need to do 2 replacements now.
                                        //$start_index = bbcode_array_pop($stack);
                                        $start_index = array_pop($stack);

                                        // everything before the [quote] tag.
                                        $before_start_tag = substr($message, 0, $start_index);

                                        // everything after the [quote] tag, but before the [/quote] tag.
                                        $between_tags = substr($message, $start_index + 7, $curr_pos - $start_index - 7);

                                        // everything after the [/quote] tag.
                                        $after_end_tag = substr($message, $curr_pos + 8);

                                        $message = $before_start_tag . "<!-- BBCode Quote Start --><TABLE BORDER=0 ALIGN=CENTER WIDTH=85%><TR><TD><font size=-1>Quote:</font><HR></TD></TR><TR><TD><FONT SIZE=-1><BLOCKQUOTE>";
                                        $message .= $between_tags . "</BLOCKQUOTE></FONT></TD></TR><TR><TD><HR></TD></TR></TABLE><!-- BBCode Quote End -->";
                                        $message .= $after_end_tag;

                                        // Now.. we've screwed up the indices by changing the length of the string.
                                        // So, if there's anything in the stack, we want to resume searching just after it.
                                        // otherwise, we go back to the start.
                                        if (sizeof($stack) > 0)
                                        {
                                                //$curr_pos = bbcode_array_pop($stack);
                                                $curr_pos = array_pop($stack);
                                                //bbcode_array_push($stack, $curr_pos);
                                                array_push($stack, $curr_pos);
                                                ++$curr_pos;
                                        }
                                        else
                                        {
                                                $curr_pos = 1;
                                        }
                                }
                                else
                                {
                                        // No matching start tag found. Increment pos, keep going.
                                        ++$curr_pos;
                                }
                        }
                        else
                        {
                                // No starting tag or ending tag.. Increment pos, keep looping.,
                                ++$curr_pos;
                        }
                }
        } // while

        return $message;

} // bbencode_quote()


/**
 * Nathan Codding - Jan. 12, 2001.
 * Performs [code][/code] bbencoding on the given string, and returns the results.
 * Any unmatched "[code]" or "[/code]" token will just be left alone.
 * This works fine with both having more than one code block in a message, and with nested code blocks.
 * Since that is not a regular language, this is actually a PDA and uses a stack. Great fun.
 *
 * Note: This function assumes the first character of $message is a space, which is added by
 * bbencode().
 */
function bbencode_code($message)
{
        $message = preg_replace("/\[code\](.*?)\[\/code\]/si", "<!-- BBCode Start --><TABLE BORDER=0 ALIGN=CENTER WIDTH=85><TR><TD><font size=-1>Code:</font><HR></TD></TR><TR><TD><PRE>\\1</PRE></TD></TR><TR><TD><HR></TD></TR></TABLE><!-- BBCode End -->", $message);
        return $message;

} // bbencode_code()


/**
 * Nathan Codding - Jan. 12, 2001.
 * Performs [list][/list] and [list=?][/list] bbencoding on the given string, and returns the results.
 * Any unmatched "[list]" or "[/list]" token will just be left alone.
 * This works fine with both having more than one list in a message, and with nested lists.
 * Since that is not a regular language, this is actually a PDA and uses a stack. Great fun.
 *
 * Note: This function assumes the first character of $message is a space, which is added by
 * bbencode().
 */
function bbencode_list($message)
{
        $start_length = Array();
        $start_length[ordered] = 8;
        $start_length[unordered] = 6;

        // First things first: If there aren't any "[list" strings in the message, we don't
        // need to process it at all.

        if (!strpos(strtolower($message), "[list"))
        {
                return $message;
        }

        $stack = Array();
        $curr_pos = 1;
        while ($curr_pos && ($curr_pos < strlen($message)))
        {
                $curr_pos = strpos($message, "[", $curr_pos);

                // If not found, $curr_pos will be 0, and the loop will end.
                if ($curr_pos)
                {
                        // We found a [. It starts at $curr_pos.
                        // check if it's a starting or ending list tag.
                        $possible_ordered_start = substr($message, $curr_pos, $start_length[ordered]);
                        $possible_unordered_start = substr($message, $curr_pos, $start_length[unordered]);
                        $possible_end = substr($message, $curr_pos, 7);
                        if (strcasecmp("[list]", $possible_unordered_start) == 0)
                        {
                                // We have a starting unordered list tag.
                                // Push its position on to the stack, and then keep going to the right.
                                //bbcode_array_push($stack, array($curr_pos, ""));
                                array_push($stack, array($curr_pos, ""));
                                ++$curr_pos;
                        }
                        else if (preg_match("/\[list=([a1])\]/si", $possible_ordered_start, $matches))
                        {
                                // We have a starting ordered list tag.
                                // Push its position on to the stack, and the starting char onto the start
                                // char stack, the keep going to the right.
                                //bbcode_array_push($stack, array($curr_pos, $matches[1]));
                                array_push($stack, array($curr_pos, $matches[1]));
                                ++$curr_pos;
                        }
                        else if (strcasecmp("[/list]", $possible_end) == 0)
                        {
                                // We have an ending list tag.
                                // Check if we've already found a matching starting tag.
                                if (sizeof($stack) > 0)
                                {
                                        // There exists a starting tag.
                                        // We need to do 2 replacements now.
                                        //$start = bbcode_array_pop($stack);
                                        $start = array_pop($stack);
                                        $start_index = $start[0];
                                        $start_char = $start[1];
                                        $is_ordered = ($start_char != "");
                                        $start_tag_length = ($is_ordered) ? $start_length[ordered] : $start_length[unordered];

                                        // everything before the [list] tag.
                                        $before_start_tag = substr($message, 0, $start_index);

                                        // everything after the [list] tag, but before the [/list] tag.
                                        $between_tags = substr($message, $start_index + $start_tag_length, $curr_pos - $start_index - $start_tag_length);
                                        // Need to replace [*] with <LI> inside the list.
                                        $between_tags = str_replace("[*]", "<!-- BBCode --><LI>", $between_tags);

                                        // everything after the [/list] tag.
                                        $after_end_tag = substr($message, $curr_pos + 7);

                                        if ($is_ordered)
                                        {
                                                $message = $before_start_tag . "<!-- BBCode olist Start --><OL TYPE=" . $start_char . ">";
                                                $message .= $between_tags . "</OL><!-- BBCode olist End -->";
                                        }
                                        else
                                        {
                                                $message = $before_start_tag . "<!-- BBCode ulist Start --><UL>";
                                                $message .= $between_tags . "</UL><!-- BBCode ulist End -->";
                                        }

                                        $message .= $after_end_tag;

                                        // Now.. we've screwed up the indices by changing the length of the string.
                                        // So, if there's anything in the stack, we want to resume searching just after it.
                                        // otherwise, we go back to the start.
                                        if (sizeof($stack) > 0)
                                        {
                                                //$a = bbcode_array_pop($stack);
                                                $a = array_pop($stack);
                                                $curr_pos = $a[0];
                                                //bbcode_array_push($stack, $a);
                                                array_push($stack, $a);
                                                ++$curr_pos;
                                        }
                                        else
                                        {
                                                $curr_pos = 1;
                                        }
                                }
                                else
                                {
                                        // No matching start tag found. Increment pos, keep going.
                                        ++$curr_pos;
                                }
                        }
                        else
                        {
                                // No starting tag or ending tag.. Increment pos, keep looping.,
                                ++$curr_pos;
                        }
                }
        } // while

        return $message;

} // bbencode_list()

function undo_make_clickable($text) {

        $text = preg_replace("#<!-- BBCode auto-link start --><a href=\"(.*?)\" target=\"_blank\" class=texte>.*?</a><!-- BBCode auto-link end -->#i", "\\1", $text);
        $text = preg_replace("#<!-- BBcode auto-mailto start --><a href=\"mailto:(.*?)\" class=texte>.*?</a><!-- BBCode auto-mailto end -->#i", "\\1", $text);

        return $text;

}
?>
