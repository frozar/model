<?
/***************************************************************************
                                viewtopic.php
                             -------------------
    last modification    : 21/11/2002
    email                : stick@newffr.org

 ***************************************************************************/

/***************************************************************************
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 ***************************************************************************/
include("fonctions.php");
include("conf/auth.php");
include("header.php");

settype($forum,"integer");
settype($topic,"integer");
if(!$forum) error_die("forum inconnu");
if(!$topic) error_die("topic inconnu");



$query = "SELECT forum_name, forum_id, forum_type FROM forums WHERE forum_id=$forum";
if(!$result = mysql_query($query,$db)) error_die("recup des infos du forum impossible");
$forum_infos = mysql_fetch_array($result);
if($forum_infos[forum_type]>0) header("Location: http://www.newffr.org\n");



$Topic = new Topics($forum,$topic);
$topic_entitie = $Topic->viewtopic();

if(!$topic_users = $topic_entitie[POSTERS_ID]) error_die("Topic inexistant");
$topic_entitie[POSTERS_ID] = "";

//recup des infos sur les users du topic
$query = "SELECT * FROM users WHERE user_id=";
$topic_users = array_keys($topic_users);
$topic_users = implode(" OR user_id=",$topic_users);
$query .= $topic_users;
unset($topic_users);

if(!$result = mysql_query($query, $db))
  error_die("recup des infos impossible");
while($row=mysql_fetch_array($result)){
     $posterdata[$row[user_id]] = $row;
}

$topic_total = $topic_entitie[last_post_id];

?>
<table width=95% align=center class=texte bgcolor=#<?=$theme[table_liserai]?> cellspacing="<?=$theme[cellspacing]?>" cellpadding="<?=$theme[cellpadding]?>">
   <tr>
      <td colspan=2>
         <table width=100% class=titrecadre>
            <tr>
              <td nowrap><b>
               <a href=viewforum.php?<?=$sess_link?>&forum=<?=$forum?> class=titrecadre><?=$forum_infos[forum_name]?></a>
                >> <?=stripslashes($topic_entitie[TITLE])?></b> </td>
              <td nowrap align=right>
                 <a href=newtopic.php?<?=$sess_link?>&forum=<?=$forum?> class=texte><b>Newtopic</b></a> |
                 <?
                 if($topic_entitie[LOCKED])
                      echo "<b>Topic Locked</b>";
                 else
                     echo "<a href=reply.php?$sess_link&forum=$forum&topic=$topic class=texte><b>Reply</b></a>";

                    ?>
              </td>
            </tr>
         </table>
      </td>
   </tr>
   <tr bgcolor=#<?=$theme[table_titre]?> class=titre>
      <td >poster</td>
      <td>txt</td>
   </tr>
<?
$i=0;
while(list($key,$thispost)=each($topic_entitie[POSTS])){
        //affiche l'interval de post voulu
        if($i < $start){
           $i++;
           continue;
        }elseif($i>=$start+$config[post_par_page]) break;

        $thispost[POST_TIME] = date("d-m-Y H:i",$thispost[POST_TIME]);
        $thispost[TEXT] = str_replace("[addsig]","\n<br>_________________________<br>\n".$posterdata[$thispost[POSTER_ID]][user_sig],$thispost[TEXT]);
        ?>
        <tr bgcolor=#<?=($i%2==0)? $theme[color1] : $theme[color2] ?>>
           <td valign=top nowrap width=1%>
              <!----- affichage du poster + info reduites ------->
              <a href=profil.php?<?=$sess_link?>&mode=voir&user_id=<?=$thispost[POSTER_ID]?> class=texte><?=stripslashes($posterdata[$thispost[POSTER_ID]][username])?></a><br>
              <span class=minitexte>Inscrit le <?=date("d-m-Y",$posterdata[$thispost[POSTER_ID]][user_timestamp])?></span>
              <br>
              <?
              if($posterdata[$thispost[POSTER_ID]][user_avatar])
                 echo "<img src='".$posterdata[$thispost[POSTER_ID]][user_avatar]."' border=0>";
              ?>
           </td>
           <td>
              <span class=minitexte>Post� le <?=$thispost[POST_TIME]?></span><hr>
              <?=stripslashes($thispost[TEXT])?>
              <hr>
              <!--- tous les lien style edit, profil, mail etc... ----->
              <a href=profil.php?<?=$sess_link?>&mode=voir&user_id=<?=$thispost[POSTER_ID]?> class=texte>profil</a>
              <?
              if($posterdata[$thispost[POSTER_ID]][user_viewemail])
                 echo "<a href='mailto:".$posterdata[$thispost[POSTER_ID]][user_email]."' target=_blank class=texte>mail</a> ";
              if($posterdata[$thispost[POSTER_ID]][user_website])
                 echo "<a href='".$posterdata[$thispost[POSTER_ID]][user_website]."' target=_blank class=texte>Website</a>";
              ?> |
              <?
              if($posterdata[$thispost[POSTER_ID]][user_aim])
                 echo "<a href='aim:goim?screenname=".$posterdata[$thispost[POSTER_ID]][user_aim]."&message=Salut!' target=_blank class=texte>AIM</a> ";
              if($posterdata[$thispost[POSTER_ID]][user_icq])
                 echo "<a href='http://wwp.icq.com/".$posterdata[$thispost[POSTER_ID]][user_icq]."#pager' target=_blank class=texte>ICQ</a> ";
              if($posterdata[$thispost[POSTER_ID]][user_yim])
                 echo "<a href='http://edit.yahoo.com/config/send_webmesg?.target=".$posterdata[$thispost[POSTER_ID]][user_yim]."&.src=pg' target=_blank class=texte>Yahoo</a> ";
              if($posterdata[$thispost[POSTER_ID]][user_msnm])
                 echo "<a href='profil.php?mode=voir&user_id=$thispost[POSTER_ID]' target=_blank class=texte>MSN</a> ";
              ?>
              |
              <a href=edit.php?<?=$sess_link?>&forum=<?=$forum?>&topic=<?=$topic?>&post=<?=$thispost[POST_ID]?> class=texte>edit</a>
              <a href=reply.php?<?=$sess_link?>&forum=<?=$forum?>&topic=<?=$topic?>&quote=<?=$thispost[POST_ID]?> class=texte>quote</a>
           </td>
        </tr>
        <?
        $i++;
}

//creation de la navigation
if($topic_total>$config[post_par_page]){
    $nbpage = ceil($topic_total/$config[post_par_page]) ;
    $navigation = "<span class=minitexte>";
    for($z=0;$z<$nbpage;$z++){
       $navigation .= ($config[post_par_page]*$z!=$start)? "<a href='viewtopic.php?$sess_link&forum=$forum&topic=$topic&start=".($config[post_par_page]*$z)."' class=minitexte>" : "" ;
       $navigation .= $z+1;
       $navigation .= ($config[post_par_page]*$z!=$start)? "</a> | " : " | ";
    }
    $navigation .= ($start+$config[post_par_page]<$topic_total)? "<a href='viewtopic.php?$sess_link&forum=$forum&topic=$topic&start=".($start+$config[post_par_page])."' class=minitexte>Page suivante</a>" : "" ;
    $navigation .= "</span>\n";
}

?>
   <tr>
      <td colspan=2>
         <table width=100% class=titrecadre>
            <tr>
              <td width=25%>
                 <a href=newtopic.php?<?=$sess_link?>&forum=<?=$forum?> class=texte><b>Newtopic</b></a> |
                 <?
                 if($topic_entitie[LOCKED])
                      echo "<b>Topic Locked</b>";
                 else
                     echo "<a href=reply.php?$sess_link&forum=$forum&topic=$topic class=texte><b>Reply</b></a>";

                    ?>
              </td>
              <td align=right>
                 <?=$navigation?>
              </td>
            </tr>
         </table>
      </td>
   </tr>
</table>
<?
$query = "UPDATE topics SET topic_views=topic_views+1 WHERE topic_id=$topic";
mysql_query($query,$db);



if($userdata[user_level]>1){
      ?>
      <br><br>
      <center>
      <a href=moderate.php?<?=$sess_link?>&mode=lock&forum=<?=$forum?>&topic=<?=$topic?> class=texte>Locker/Delocker</a> -
      <a href=moderate.php?<?=$sess_link?>&mode=del&forum=<?=$forum?>&topic=<?=$topic?> class=texte>Supprimer</a> -
      <a href=moderate.php?<?=$sess_link?>&mode=move&forum=<?=$forum?>&topic=<?=$topic?> class=texte>D�placer</a> -
      <a href=moderate.php?<?=$sess_link?>&mode=an&forum=<?=$forum?>&topic=<?=$topic?> class=texte>Annonce/Unannonce</a>
      </center>
      <?
}

include("tail.php");
?>
