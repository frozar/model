# phpMyAdmin MySQL-Dump
# version 2.2.3-rc1
# http://phpwizard.net/phpMyAdmin/
# http://phpmyadmin.sourceforge.net/ (download page)
#
# Serveur: localhost
# G�n�r� le : Samedi 30 Novembre 2002 � 16:08
# Version du serveur: 3.23.47
# Version de PHP: 4.2.3
# Base de donn�es: `newffr`
# --------------------------------------------------------

#
# Structure de la table `forums`
#

CREATE TABLE `forums` (
  `forum_id` int(10) NOT NULL auto_increment,
  `forum_name` varchar(150) default NULL,
  `forum_desc` text,
  `forum_topics` int(10) NOT NULL default '0',
  `forum_posts` int(10) NOT NULL default '0',
  `forum_last_poster` varchar(50) NOT NULL default '0',
  `forum_last_post_time` int(11) NOT NULL default '0',
  `cat_id` int(10) default NULL,
  `forum_type` int(10) default '0',
  PRIMARY KEY  (`forum_id`),
  KEY `cat_id` (`cat_id`)
) TYPE=MyISAM;
# --------------------------------------------------------

#
# Structure de la table `smiles`
#

CREATE TABLE `smiles` (
  `id` int(10) NOT NULL auto_increment,
  `code` varchar(50) default NULL,
  `smile_url` varchar(100) default NULL,
  `emotion` varchar(75) default NULL,
  PRIMARY KEY  (`id`),
  FULLTEXT KEY `smile_url` (`smile_url`)
) TYPE=MyISAM;
# --------------------------------------------------------

#
# Structure de la table `sondages`
#

CREATE TABLE `sondages` (
  `ID` tinyint(4) NOT NULL auto_increment,
  `Valide` tinyint(4) default '0',
  `Subject` varchar(50) NOT NULL default '',
  `Titre` longtext NOT NULL,
  `rep_text` longtext NOT NULL,
  `nb_rep` tinytext NOT NULL,
  `Date` bigint(20) NOT NULL default '0',
  `duree` int(11) NOT NULL default '0',
  `forum_id` smallint(6) NOT NULL default '0',
  `topic_id` int(11) NOT NULL default '0',
  `poster_id` text NOT NULL,
  PRIMARY KEY  (`ID`),
  KEY `id_2` (`ID`)
) TYPE=MyISAM;
# --------------------------------------------------------

#
# Structure de la table `topics`
#

CREATE TABLE `topics` (
  `topic_id` int(10) NOT NULL auto_increment,
  `topic_title` varchar(100) default NULL,
  `topic_poster` int(10) default NULL,
  `topic_last_post_time` bigint(20) default NULL,
  `topic_views` int(10) NOT NULL default '0',
  `topic_replies` int(10) NOT NULL default '0',
  `topic_last_poster` varchar(40) NOT NULL default '',
  `forum_id` int(10) NOT NULL default '0',
  `topic_status` int(10) NOT NULL default '0',
  `topic_notify` int(2) default '0',
  `topic_sticky` tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (`topic_id`),
  KEY `forum_id` (`forum_id`)
) TYPE=MyISAM;
# --------------------------------------------------------

#
# Structure de la table `users`
#

CREATE TABLE `users` (
  `user_id` int(10) NOT NULL auto_increment,
  `username` varchar(40) NOT NULL default '',
  `user_timestamp` bigint(20) NOT NULL default '0',
  `user_password` varchar(32) NOT NULL default '',
  `user_email` varchar(50) default NULL,
  `user_icq` varchar(15) default NULL,
  `user_website` varchar(100) default NULL,
  `user_occ` varchar(100) default NULL,
  `user_from` varchar(100) default NULL,
  `user_intrest` varchar(150) default NULL,
  `user_sig` varchar(255) default NULL,
  `user_viewemail` tinyint(2) default NULL,
  `user_aim` varchar(35) default NULL,
  `user_yim` varchar(35) default NULL,
  `user_msnm` varchar(35) default NULL,
  `user_attachsig` int(2) default '0',
  `user_level` int(10) default '1',
  `user_pvsound` tinyint(2) default '0',
  `user_avatar` varchar(100) default NULL,
  `user_newpv` tinyint(4) NOT NULL default '0',
  PRIMARY KEY  (`user_id`)
) TYPE=MyISAM;
# --------------------------------------------------------
INTO `users` (`user_id`, `username`, `user_timestamp`, `user_password`, `user_email`, `user_icq`, `user_website`, `user_occ`, `user_from`, `user_intrest`, `user_sig`, `user_viewemail`, `user_aim`, `user_yim`, `user_msnm`, `user_attachsig`, `user_level`, `user_pvsound`, `user_avatar`, `user_newpv`) VALUES (1, 'admin', 1037881988, '21232f297a57a5a743894a0e4a801fc3', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 4, 0, NULL, 0);

#
# Structure de la table `whosonline`
#

CREATE TABLE `whosonline` (
  `username` varchar(50) NOT NULL default '',
  `user_id` int(11) NOT NULL default '0',
  `sess_id` varchar(32) NOT NULL default '',
  `ip` varchar(16) NOT NULL default '',
  `timestamp` int(11) NOT NULL default '0'
) TYPE=MyISAM;

