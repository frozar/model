<?
/***************************************************************************
                                reply.php
                             -------------------
    last modification    : 21/11/2002
    email                : stick@newffr.org

 ***************************************************************************/

/***************************************************************************
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 ***************************************************************************/

include("fonctions.php");
include("conf/auth.php");
include("header.php");

settype($forum,"integer");
settype($topic,"integer");
settype($quote,"integer");
if(!$forum) error_die("forum inconnu");
if(!$topic) error_die("topic inconnu");
$quote = ($quote)? $quote : "" ;

if(!$user_logged_in) error_die("Veuillez vous logger");

$query = "SELECT forum_name, forum_id, forum_type FROM forums WHERE forum_id=$forum";
if(!$result = mysql_query($query,$db)) error_die("recup des infos du forum impossible");
$forum_infos = mysql_fetch_array($result);


?>
<table width=95% align=center class=texte bgcolor=#<?=$theme[table_liserai]?> cellspacing="<?=$theme[cellspacing]?>" cellpadding="<?=$theme[cellpadding]?>">
<?



if($submit){

      $post_text = trim($post_text);
      if(!$post_text) error_die("�crivez qql chose putain !!");

      //filtrage
      settype($bbcode,"integer");
      $time = mktime();
      $username = addslashes($userdata[username]);

      //formatage du texte
      $post_text = censor_string($post_text);
      if(!$bbcode){
          $post_text = bbencode($post_text);
          $post_text = smile($post_text,$db);
      }
      $post_text = make_clickable($post_text);
      $post_text = str_replace("\n","<BR>",$post_text);
      if($signature)
          $post_text .= "\n[addsig]";

      $Topic = new Topics($forum,$topic);
      if(!$Topic->addpost($userdata[user_id],mktime(),$post_text)) error_die("Impossible de poster une r�ponse � ce topic");

      $query = "UPDATE topics SET topic_replies=topic_replies+1, topic_last_post_time=$time, topic_last_poster='$username' WHERE topic_id=$topic";
      mysql_query($query,$db);
      $query = "UPDATE forums SET forum_posts=forum_posts+1, forum_last_post_time=$time, forum_last_poster='$username' WHERE forum_id=$forum";
      mysql_query($query,$db);

      $pv_ = ($forum_infos[forum_type])? "pv_" : "";
      echo "<script>window.location='$config[site_host]$config[site_url]/$pv_"."viewtopic.php?$sess_link&topic=$topic&forum=$forum'</script>";
      exit();
}else{

      $Topic = new Topics_admin($forum,$topic);
      if($quote){
             $topic_entitie = $Topic->viewpost($quote);

             $sql = "SELECT username FROM users WHERE user_id=$topic_entitie[POSTER_ID]";
             if(!$r = mysql_query($sql, $db)) error_die("recup du username impossible");

             $postername = mysql_result($r,0);

             $topic_entitie[POST_TIME] = date("d-m-Y H:i",$topic_entitie[POST_TIME]);
             $text = desmile($topic_entitie[TEXT]);
             $text = str_replace("<BR>", "", $text);
             $text = stripslashes($text);
             $text = bbdecode($text);
             $text = undo_make_clickable($text);
             $text = str_replace("[addsig]", "", $text);

             $quote = "[quote]\n".
                      "Le $topic_entitie[POST_TIME], $postername a �crit :\n".
                      "___________________________________________________\n".
                      $text.
                      "\n[/quote]\n";
      }else
             $topic_entitie = $Topic->viewtopic();
?>
   <form name=form_reply method=post>
   <input type="hidden" name="sess_id" value="<?=$sess_id?>">
   <input type=hidden name=forum value=<?=$forum?>>
   <input type=hidden name=topic value=<?=$topic?>>
   <tr>
      <td colspan=2 class=texte><b><?=$forum_infos[forum_name]?> >> <?=$topic_entitie[TITLE]?></b></td>
   </tr>
   <tr>
      <td bgcolor=#<?=$theme[color1]?> class=texte><b>Nom</b></td>
      <td bgcolor=#<?=$theme[color2]?> class=texte><?=$userdata[username]?></td>
   </tr>
   <tr>
      <td bgcolor=#<?=$theme[color1]?> valign=top class=texte>
         <b>Texte</b><br>
         <br><br><br><br><br>
         <?=bbcode_javascript()/* affichage des bouton BBcode */?>
      </td>
      <td bgcolor=#<?=$theme[color2]?>>
         <table width=100%>
            <tr>
               <td><TEXTAREA NAME="post_text" ROWS=18 COLS=60 WRAP="VIRTUAL"><?=$quote?></TEXTAREA></td>
               <td><?=smiley_javascript(5,$config[smiles_url],$db)?></td>
            </tr>
         </table>
      </td>
   </tr>
   <tr>
      <td bgcolor=#<?=$theme[color1]?>></td>
      <td bgcolor=#<?=$theme[color2]?> class=texte>
          <input type=checkbox name=bbcode> D�sactiver bbcode/smile <br>
          <input type=checkbox name=signature <?=($userdata[user_attachsig])? "checked" : ""?>> Inclure la signature <br>
      </td>
   </tr>
   <tr>
      <td bgcolor=#<?=$theme[color1]?> colspan=2 align=center><input type=submit name=submit value="         Envoyer la r�ponse         " class=button></td>
   </tr>
   </form>
<?

}
?>
</table>
<?
include("tail.php");

?>
