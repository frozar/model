function fenetre_popup(url, nom)
{
    window.open(url, nom, 'status=no,location=no,toolbar=no,directories=no,menubar=no,scrollbars=yes,resizable=yes,width=760,height=500,top=' + (screen.height-500)/2 + ',left=' + (screen.width-760)/2)
}