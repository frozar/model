<?
//read variables from the request
if (isset($_GET["url"])) $url = $_GET["url"];

//--------------------------------------------

define("MODPATH","wopen_modules/");

$ini = @file(MODPATH."wopen.ini");
$module_list=array();
foreach($ini as $line) {
    if (preg_match("/^;/",$line)) continue;
    unset($array, $file, $class, $comment);
    preg_match("/^(\S+)\s(\S+)\s(.+)/i", $line, $array);
    list($dummy, $file, $class, $comment) = $array;
    //$modules[]=array('comment'=>$comment,'class'=>$class,'file'=>file);
    $module_list[]=compact('comment','class','file');
}


if (isset($url)) {
  set_time_limit(60);
  include_once("module.inc");
       
  if (!preg_match("~^http://~i",$url)) $url = "http://".$url;
  
  print("Analysis of  <b><a href=\"$url\">$url</a></b> ...<br>\n");
  $target = new CTarget($url);
  $exploits = 0;
  $modules = 0;
  if ($ini!=false) {
    foreach ($module_list as $module) {
        extract($module);
        
        $file = MODPATH.$file;
        if (isset($comment) && isset($class) && isset($file)) {
          if (file_exists($file)) {
            include_once($file);
            ++$modules;
            if (class_exists($class)) {
              $obj = new $class;
              if (is_subclass_of($obj, "CModule")) {
                if ($obj->CheckTarget($target)) {
                  print("\n<hr>$file (<b>$comment</b>)<br>");
                  $obj->ExploitTarget($target);
                  ++$exploits;
                }
                //else echo "\n<br>false<br>";
              } else {
                print("\n<br>Class $class must extend CModule");  
              }
            } else {
              print("\n<br>Class $class not defined in $file");
            }
          } else {
            print("\n<br>Cannot include $file");
          }
        } else {
          print("\n<br>Cannot parse line $line from configuration file");
        }
    }
    if (!$exploits) { //hmm, nobody did anything? - Check why.
      if (!$modules)
        echo "\n<br>The ini file is empty, doesn't contain any valid modules, or all entries are commented.";
      else if (!$target->CanGetSource()) 
        echo "\n<br>The specified target URL ($target->sUrl) is not accessible";
      else 
        echo "\n<br>None of the modules could exploit this URL";
    }
  } else {
    echo "\n<br>Cannot open the wopen.ini file";
  }
  echo "\n<hr><br>Again: ";
}

?>
<form>
<input name="url" size="80">
<input type="submit">
</FORM>

type the url of a page you want to process through the wand of opening in the box above and submit the form.<BR>
The page will be checked against the following :
<ul>
<?php foreach($module_list as $module) echo('<li>'.$module['class'].' : '.$module['comment'].'<br>');?>
</UL>
You can learn more about this wand by reading Mordred and loki's <A href="wopen.htm">essay</a> on the subject.

