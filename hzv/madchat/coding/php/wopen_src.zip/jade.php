<? 
/*
jade.php is a web interface to jad.exe (or with a slight mod, any other java decompiler)
The results of the decompilation along with the class files are cached in the CLASS_FOLDER folder,
in subfolders named in the pattern <binary>.<crc32> so you always have a right copy of the 
right decompiled applet.

For the near future, I may add support for .jar files, and more decompilers (possibly for UNIXoid OSes too)

Oh, and this will work on a win32 machine with jad.exe in the same folder as jade.php, which
in most cases means you can only use it from your local machine. 

*/

	include_once("durl.inc");
	define("CLASS_FOLDER","jaded_classes");

function ShowForm(){
?>
	<form><input size=80 name=url value="<?if (isset($_GET["url"])) echo $_GET["url"];?>"><input type=submit></form>
<?
}

	if (isset($_GET["url"])) $url = $_GET["url"];
	if (isset($url)) {
		if (!is_dir(CLASS_FOLDER)) {
			$res = @mkdir(CLASS_FOLDER, 0x775);
			if (!$res) echo "Cannot create dir ".CLASS_FOLDER;
		}

		$durl = new CDUrl($url);
		if (isset($durl->sDocument)) {
			$bClass = preg_match("~\.class$~i", $durl->sDocument);
			$bJar   = preg_match("~\.jar$~i  ", $durl->sDocument);
$bJar = false; //no jar support yet!
			if ($bClass || $bJar) {
				echo "Getting file...";
				$fp = @fopen($url, "rb");
				if ($fp) {
					set_magic_quotes_runtime(0); //to make it binary-safe, at least the ppl say so
					$target = fread($fp, 1000000); //no more than 1M applets, okay :)
					fclose($fp);
				} else {
					echo "Cannot open url $url";
					ShowForm();
					return;
				}
				echo "done! <br>";
				if ($target <> "") {
					$crc = crc32($target);
					$dirname = CLASS_FOLDER."/".$durl->sDocument .".". $crc."/";
					if (is_dir($dirname) && file_exists($dirname."/index.html")) { //already decompiled, serve the results from there
						//echo "<head><META HTTP-EQUIV=\"Refresh\" CONTENT=\"1; URL=$dirname\"></head><body><a href=\"$dirname\">Click here if the redirect isn't working</a>";
						//echo "<a href=\"$dirname\">View the results</a>";
						echo "Already decompiled!\n<br>";
						//list types
						preg_match("~(.+?)\.class~i", $durl->sDocument, $arr);
						$jadname = $arr[1].".jad";
								
						$jadfile = @(join('',file($dirname.$jadname)));
						$jadfile = htmlentities($jadfile);
						$jadfile = preg_replace("~\r\n~","\n",$jadfile);
						//guess new types
						preg_match_all("~\Wnew\W(\w+)\(~",$jadfile,$matches); //$matches[1] are the types

						echo "<a href=\"$dirname\" target=_blank>See results (new window)</a><br> or try to (may be standard type or in a jar) jade one of these types: <ul>";
						$root = $durl->sDirectory;
						foreach(array_unique($matches[1]) as $sType)
							echo "<li> <a href=\"jade.php?url=".GetAbsoluteURL($url, "$sType.class")."\">$sType.class</a>";
						echo "</ul>";

					} else {
						@mkdir($dirname);
						$filename = $dirname.$durl->sDocument; 
						$fp = @fopen($filename, "wb");
						if ($fp) {
							$res = fwrite($fp, $target);
							if ($res==-1) {
								echo "Cannot write to file $filename";
								//ShowForm();
							}
							fclose($fp);
						} else {
							echo "Cannot create file $filename";
							//ShowForm();
						}
						if ($bClass) {
							echo "Decompiling $filename ($durl->sDocument) ...";

							//realpath has a bug, so we have to do this BEFORE the chdir
							$cmd = 	"\"".dirname(realpath("jade.php"))."\\jad.exe\" -o -space -t4 ".$durl->sDocument;
							chdir($dirname);
							exec($cmd);

							echo " Done <br>";

							preg_match("~(.+?)\.class~i", $durl->sDocument, $arr);
							$jadname = $arr[1].".jad";

							$fp = @fopen("index.html", "wt");
							if ($fp) {
								$beginning =  "<html><body>"
											 ."<a href=\"..\">Index of all decompiled classes</a><br>"
											 ."<a href=\"$durl->sDocument\">Get the class file</a><br>"
											 ."<a href=\"$jadname\">Get the jad file</a>"
											 /*
											 ."<form><input name=edit value=\"\">"
											 ."<script language=\"javascript\">"
											 ."edit.value = document.referrer;"
											 ."</script>"*/
											 ;


								fputs($fp, $beginning);


								$jadfile = @(join('',file($jadname)));
								$jadfile = htmlentities($jadfile);
								$jadfile = preg_replace("~\r\n~","\n",$jadfile);

								//guess new types
								preg_match_all("~\Wnew\W(\w+)\(~",$jadfile,$matches); //$matches[1] are the types


								//Pseudo syntax highlighting:

								/*//make vertain keywords bold
								$boldify = array("class", "public", "extends", "import", "for", "while", "if",
												 "switch", "null", "new", "return", "true", "false",
												 "integer", "boolean", "String");
								foreach ($boldify as $item) 
									$jadfile = preg_replace("~($item)~","<b>\\1</b>",$jadfile);
								*/

								//make types blue + null, true and false
								$blueify = array("null", "true", "false", "void", "int", "byte" , "boolean", "Integer", "String", "Object", "AppletContext");
								$blueify = array_unique(array_merge($blueify, $matches[1]));
								foreach ($blueify as $item) 
									$jadfile = preg_replace("~(\W)($item)(\W)~","\\1<font color=blue>\\2</font>\\3",$jadfile);

								//make strings green
								$jadfile = preg_replace("~&quot;(.+?)&quot;~","&quot;<font color=green>\\1</font>&quot;",$jadfile);

								//make numbers blue
								$jadfile = preg_replace("~(\W)(\d+)(\W)~","\\1<font color=blue>\\2</font>\\3",$jadfile);
								//function calls - purple
								$jadfile = preg_replace("~(\w+)\(~","<font color=purple>\\1</font>(",$jadfile);

								//"new" of a class
								$jadfile = preg_replace("~(\W)(new)\s(<font color=blue>\w+</font>)~","\\1<b>\\2 \\3</b>",$jadfile);

								//mm, some INTERESTING functions :)
								$jadfile = preg_replace("~(getParameter)~"    ,"<b>\\1</b>",$jadfile);
								$jadfile = preg_replace("~(showDocument)~"    ,"<b>\\1</b>",$jadfile);
								$jadfile = preg_replace("~(getCodeBase)~"     ,"<b>\\1</b>",$jadfile);
								$jadfile = preg_replace("~(getDocumentBase)~" ,"<b>\\1</b>",$jadfile);

								
								
								/**/								

								fputs($fp, "<hr><br><pre>\n$jadfile");

								fputs($fp, "</pre></body></html>");
								fclose($fp);
								//echo "<head><META HTTP-EQUIV=\"Refresh\" CONTENT=\"1; URL=$dirname\"></head><body>
								echo "<a href=\"$dirname\" target=_blank>See results (new window)</a><br> or try to (may be standard type or in a jar) jade one of these types: <ul>";
								$root = $durl->sDirectory;
								foreach(array_unique($matches[1]) as $sType)
									echo "<li> <a href=\"jade.php?url=".GetAbsoluteURL($url, "$sType.class")."\">$sType.class</a>";
								echo "</ul>";
							} else {
								echo "Cannot create index.html";
							}

							
						} else { //it's a jar
							echo "JAR support is not ready yet";
							//ShowForm();
						}
					}

				} else {
					echo "Cannot open for write file <a href=\"$url\">$url</a>";
					//ShowForm();
				}
			} else {
				echo "This is not a .class or .jar file! Or I still haven't writ the jar support :)";
				//ShowForm();
			}
		} else {
			//ShowForm();
		}


	}else {
		//ShowForm();
	}
	ShowForm();
?>

<br>
