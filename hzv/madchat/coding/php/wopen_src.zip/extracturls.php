Fish urls from a SE query and run the wand
<?
if (isset($url)) {
	include_once("durl.inc");

	$source = @join('',file($url));
	if ($source != "") {
		if (preg_match_all('~http://.*?\s~is',strip_tags($source), $result)) {
			echo "\n<ul>";
			foreach ($result[0] as $target) {
				echo "\n<li><a href=\"$target\">$target</a> , <a href=\"wopen.php?url=$target\">Run through wand</a>";
			}
			echo "\n</ul>";

		} else echo "\n<br>No absolute urls here";
	} else echo "\n<br>Cannot download $url";

	echo "\n<hr><br>Again: ";
} 
?>

<form>
<input name="url" size="80">
<input type="submit">
