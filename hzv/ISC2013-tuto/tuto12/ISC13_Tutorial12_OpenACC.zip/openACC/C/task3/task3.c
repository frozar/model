#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <omp.h>

void update_u(double* const u, const double* const v, const int nx, const int ny, const double dt) __attribute__((noinline));

void update_v(double* const u, const double* const v, const int nx, const int ny, const double dt, const double dx2, const double dy2) __attribute__((noinline));

void calc_bc(double* const u, const int nx, const int ny, const int t) __attribute__((noinline));

double max_value( const double* const v, const int n ) __attribute__((noinline));

int main()
{
	const int nx = 3000;
	const int ny = 3000;
	const int nt = 1000;
	double* u;
	double* v;
	double dx2, dy2, dt;
	double startTime, stopTime;

	u = (double*) malloc( nx * ny * sizeof(double) );
	v = (double*) malloc( nx * ny * sizeof(double) );



	for (int y=0; y<ny; ++y)
	{
		for (int x=0; x<nx; ++x)
		{
			u[y*nx+x] = 0.0;
			v[y*nx+x] = 0.0;
		}
	}

	dt = 0.01;
	dx2 = 1.0;
	dy2 = 1.0;

	startTime = omp_get_wtime();


	for ( int t=1; t <= nt; ++t )
	{
		update_u( u, v, nx, ny, dt );

		update_v( v, u, nx, ny, dt, dx2, dy2 );

		calc_bc(u,nx,ny,t);

		if ( t%100 == 0 )
		{
			printf("%d:\t max(v) = %f\n",t, max_value(v,nx*ny) );
			printf("\t max(u) = %f\n", max_value(u,nx*ny) );
		}
	}

	stopTime = omp_get_wtime();
	const double runtime = stopTime-startTime;
	printf("u(nx/64,ny/64) = %f, v(nx/64,ny/64) = %f\n", u[(ny/64)*nx+(nx/64)], v[(ny/64)*nx+(nx/64)] );
	printf("time = %f s\n", runtime);
	const long long numCellUpdates = (long long)nx*ny*nt; //count all cells although update_v is not called on for boundary cells
	const int bytesPerCell = 10*8;								  //bytes loaded and stored ignoring caches and boundary condition
	const int flopsPerCell = 13; 								  //ignoring boundary condition

	printf("Cell updates (GCells/s) = %.1f \n", numCellUpdates/(1E9*runtime) );
	printf("Memory BW (GB/s) = %.1f \n", numCellUpdates*bytesPerCell/(1024*1024*1024*runtime) );
	printf("Performance (GFlops/s) = %.1f \n", numCellUpdates*flopsPerCell/(1E9*runtime) );
	free(u);
	free(v);
	return 0;
}

void update_u(double*restrict const u, const double*restrict const v, const int nx, const int ny, const double dt)
{
 int x, y;

#pragma acc parallel loop copy(u[0:nx*ny], v[0:nx*ny])
	for ( y=0; y<ny; ++y)
	{
		for ( x=0; x<nx; ++x)
		{
			u[y*nx+x] = u[y*nx+x] + dt * v[y*nx+x];
		}
	}
}

void update_v(double *restrict const v, const double *restrict const u, const int nx, const int ny, const double dt, const double dx2, const double dy2)
{

#pragma acc parallel loop copy(u[0:nx*ny], v[0:nx*ny])
	for (int y=1; y<(ny-1); ++y)
	{
		for (int x=1; x<(nx-1); ++x)
		{
			v[y*nx+x] = v[y*nx+x] + dt * 100.0 * (
					(u[(y+1)*nx+ x   ] - 2.0*u[y*nx+x] + u[(y-1)*nx+ x   ])/dy2 +
					(u[ y   *nx+(x+1)] - 2.0*u[y*nx+x] + u[ y   *nx+(x-1)])/dx2 );

		}
	}
}

void calc_bc(double* const u, const int nx, const int ny, const int t)
{

	for (int y=0; y<2; ++y)
	{
		for (int x=0; x<(nx/4); ++x)
		{
			u[y*nx+x] = sin(6.28*t + x/6.28) * cos(6.28*t+y/6.28);

		}
	}


	for (int y=0; y<(ny/4); ++y)
	{
		for (int x=0; x<2; ++x)
		{
			u[y*nx+x] = sin(6.28*t + x/6.28) * cos(6.28*t+y/6.28);
		}
	}
}

double max_value( const double* const v, const int n )
{
	double max = v[0];
	for ( int i=0; i<n; ++i)
	{
		max = fabs(v[i]) > max ? fabs(v[i]) : max;
	}
	return max;
}

