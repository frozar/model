void saxpy(int n, float a, float *x, float *restrict y)
{
 int i;

#pragma acc parallel loop
 for(i=0; i< n; ++i)
  y[i] = a*x[i] + y[i];

}

#define N 3000

int main(){

  float x[N], y[N];
  int i;
  
  for(i=0; i < N; ++i)
  {
    x[i] = 1.0;
    y[i] = (float)i;
  }

 saxpy(N, 3.0, x, y);

 printf("%f\n", y[N/2]);
 
}

