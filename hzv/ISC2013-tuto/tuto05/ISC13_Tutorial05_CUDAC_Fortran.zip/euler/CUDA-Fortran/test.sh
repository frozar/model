#!/bin/bash

for dir in `ls -d *.solution`; do
	cd $dir
	pwd
	make && ./euler && make clean
	cd ..
done
