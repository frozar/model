mkdir -p obj-intel64
make PIN_ROOT=/home/cienlux/task/pin-3.0-76991-gcc-linux obj-intel64/champsim_tracer.so
