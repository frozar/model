#!/bin/bash          
#./GLSLHacker /demofile=\"./Samples/demo_hello_world.xml\"
#./GLSLHacker /demofile=\"./Samples/GLSL_Tessellation_Shaders_OpenGL_40/demo_gl4_tessellation.xml\"
./GLSLHacker /demofile=\"Samples/GLSL_Simple_OpenGL_21/demo_gl2.xml\"
#./GLSLHacker /demofile=\"Samples/Python_Tests/test2.xml\"
#./GLSLHacker /demofile=\"Samples/OpenCL_Lua_Python/opencl_01_platform_queries_lua.xml\"
#./GLSLHacker /demofile=\"Samples/OpenCL_Lua_Python/opencl_01_platform_queries_python.xml\"
#./GLSLHacker
