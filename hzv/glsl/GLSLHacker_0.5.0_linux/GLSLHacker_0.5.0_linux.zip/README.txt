GLSL Hacker - Pixel Hacking with GLSL, Lua and Python
Copyright (c) 2013 Geeks3D, All rights reserved.
http://www.glslhacker.com

***************************************************
THIS SOFTWARE IS PROVIDED 'AS-IS', WITHOUT ANY 
EXPRESS OR IMPLIED WARRANTY. IN NO EVENT WILL 
THE AUTHOR BE HELD LIABLE FOR ANY DAMAGES ARISING 
FROM THE USE OF THIS SOFTWARE.
***************************************************

More information, tutorials, downloads, and code samples 
are available at http://www.glslhacker.com

How to quickly start with GLSL Hacker?

1 - Download the code samples pack available at 
    http://downloads.glslhacker.com
2 - Unzip the pack where you wish.
3 - Edit the start_glslhacker_demo.sh file in GLSL Hacker folder and change
    the value of the /demofile parameter. Once /demofile points to the correct
    XML scene file, open a terminal in GLSL Hacker folder and run this .sh file:
    $ sh ./start_glslhacker_demo.sh

A XML scene file contains the code source (GLSL programs + 
Lua / Python scripts) of a demo. You can modify it and 
reload it or you can use live coding tools to do live 
programming (live coding tools are available in the LiveUpdaters_Wine/
folder).
