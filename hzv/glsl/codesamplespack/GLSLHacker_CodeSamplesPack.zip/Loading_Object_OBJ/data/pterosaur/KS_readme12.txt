Freebie: Pterosaur
Creators: Kokopelli Studios
Date: November 2003
URL: http://www.kokopelli.org.uk

Files:
models in 3ds, opb, pp2 and obj format, texture and template and readme.

COPYRIGHT & DISTRIBUTION:
By using these downloaded files, User agrees to abide by the following conditions of this agreement:
AT NO TIME are these models/textures to be re-distributed or sold without written notification from the copyright holders.

We would like to see any pictures you create with our models/textures and you can always send us your work for the guestgallery!

Contact information:
m_daniel@netvision.net.il
or 
http://www.kokopelli.org.uk

Have fun with it!

