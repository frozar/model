
skybox_05:
  http://www.humus.name/Textures/Teide.zip

