
Orignal GLSL code for normal mapping:
- http://www.thetenthplanet.de/archives/1180

Related article on Geeks3D: 
- http://www.geeks3d.com/20130122/normal-mapping-without-precomputed-tangent-space-vectors/


Textures: http://filterforge.com/filters/
