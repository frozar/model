GLSL Hacker Code Samples Pack
-----------------------------
(C) 2013 Geeks3D
http://www.glslhacker.com


===================================
Changelog
===================================

v1.5.0 - 2013.05.24
-------------------
+ Added GLSL_Raymarching/ 

v1.4.0 - 2013.05.16
-------------------
+ Added angels.xml to GLSL_ShaderToy/
+ Added insect.xml to GLSL_ShaderToy/
+ Added truchet_tentacles.xml to GLSL_ShaderToy/
+ Added apollonian.xml to GLSL_ShaderToy/
+ Added audrey.xml to GLSL_ShaderToy/
+ Added effect_chromatic.xml  to GLSL_ShaderToy/ 
+ Added cells.xml to GLSL_ShaderToy/
+ Added ordered_dithering.xml to GLSL_ShaderToy/
+ Added more_spheres.xml to GLSL_ShaderToy/
+ Added perlin_noise_sphere.xml to GLSL_ShaderToy/
+ Added sad_robot.xml to GLSL_ShaderToy/
+ Added haunted_forest.xml to GLSL_ShaderToy/

v1.3.0 - 2013.04.30
-------------------
+ Added Vertex_Pool_Compute_Shader/
+ Updated GLSL_Compute_Shader_OpenGL_43/ sample with layout qualifier r32f.
+ Added new samples: GLSL_ShaderToy/
+ Added new samples: OpenCL_Lua_Python/
+ Added demo_6254_0_gl2.xml, demo_2902_4_gl2.xml and demo_2945_1_gl2.xml to GLSL_Sandbox/
+ Added new sample: Python_Tests/
+ Added new sample: Skybox/
+ Added new sample: GLSL_Texture_1D/
+ Added new sample: Polyline/
+ Added new sample: GLSL_Live_Coding/
+ Added new sample: Bitmap_fonts/
+ Added new sample: Camera_Ortho/
+ Added new sample: Loading_Object_3DS/
+ Added new sample: GLSL_VertexID/
+ Added new sample: GLSL_Tessellation_GS_Wireframe_OpenGL_40/
+ Added new sample: LuaGL/
+ Added new sample: Lua_filesystem/
+ Added new sample: Vertex_Pool_grid_deformer/
+ Added new sample: GLSL_OpenGL_32_Interpolation/
+ Added demo_gl3_multitexturing.xml sample in GLSL_Textured_Quad_OpenGL_21_32/

v1.2.0 - 2013.01.28
-------------------
+ Added new sample: GLSL_Tessellation_Spacing/


v1.1.0 - 2013.01.22
-------------------
+ Added new sample: GLSL_Normal_Mapping/


v1.0.0 - 2013.01.22
-------------------
. First release with GLSL Hacker 0.4.0.
